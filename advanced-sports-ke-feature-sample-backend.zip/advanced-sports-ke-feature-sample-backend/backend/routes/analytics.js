import express from 'express';
import UserSession from '../models/UserSession.js';

const router = express.Router();

// GET /api/analytics/sessions - Get session analytics overview
router.get('/sessions', async (req, res) => {
  try {
    const { 
      startDate, 
      endDate, 
      page = 1, 
      limit = 50,
      device,
      browser,
      os 
    } = req.query;

    // Build filter query
    const filter = {};
    
    if (startDate && endDate) {
      filter.startTime = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    } else {
      // Default to last 7 days
      const lastWeek = new Date();
      lastWeek.setDate(lastWeek.getDate() - 7);
      filter.startTime = { $gte: lastWeek };
    }
    
    if (device) filter.device = device;
    if (browser) filter['browser.name'] = browser;
    if (os) filter['os.name'] = os;

    // Get paginated sessions
    const sessions = await UserSession.find(filter)
      .sort({ startTime: -1 })
      .limit(parseInt(limit) * 1)
      .skip((parseInt(page) - 1) * parseInt(limit))
      .select('-pagesVisited'); // Exclude detailed page visits for overview

    const totalSessions = await UserSession.countDocuments(filter);

    // Get summary statistics
    const stats = await UserSession.aggregate([
      { $match: filter },
      {
        $group: {
          _id: null,
          totalSessions: { $sum: 1 },
          totalPageViews: { $sum: '$totalPages' },
          avgPagesPerSession: { $avg: '$totalPages' },
          avgSessionDuration: { $avg: '$duration' },
          bounceRate: {
            $avg: {
              $cond: [{ $lte: ['$totalPages', 1] }, 1, 0]
            }
          },
          uniqueVisitors: { $addToSet: '$ipAddress' }
        }
      },
      {
        $addFields: {
          uniqueVisitors: { $size: '$uniqueVisitors' },
          bounceRate: { $multiply: ['$bounceRate', 100] } // Convert to percentage
        }
      }
    ]);

    res.json({
      success: true,
      data: {
        sessions,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(totalSessions / parseInt(limit)),
          totalSessions,
          limit: parseInt(limit)
        },
        stats: stats[0] || {
          totalSessions: 0,
          totalPageViews: 0,
          avgPagesPerSession: 0,
          avgSessionDuration: 0,
          bounceRate: 0,
          uniqueVisitors: 0
        }
      }
    });
  } catch (error) {
    console.error('Error fetching session analytics:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching session analytics',
      error: error.message
    });
  }
});

// GET /api/analytics/sessions/:sessionId - Get detailed session data
router.get('/sessions/:sessionId', async (req, res) => {
  try {
    const session = await UserSession.findOne({ 
      sessionId: req.params.sessionId 
    });

    if (!session) {
      return res.status(404).json({
        success: false,
        message: 'Session not found'
      });
    }

    res.json({
      success: true,
      data: session
    });
  } catch (error) {
    console.error('Error fetching session details:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching session details',
      error: error.message
    });
  }
});

// GET /api/analytics/active-sessions - Get currently active sessions
router.get('/active-sessions', async (req, res) => {
  try {
    const activeSessions = await UserSession.getActiveSessions();

    res.json({
      success: true,
      data: {
        count: activeSessions.length,
        sessions: activeSessions
      }
    });
  } catch (error) {
    console.error('Error fetching active sessions:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching active sessions',
      error: error.message
    });
  }
});

// GET /api/analytics/popular-pages - Get most popular pages
router.get('/popular-pages', async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    const popularPages = await UserSession.getPopularPages(parseInt(limit));

    res.json({
      success: true,
      data: popularPages
    });
  } catch (error) {
    console.error('Error fetching popular pages:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching popular pages',
      error: error.message
    });
  }
});

// GET /api/analytics/devices - Get device breakdown
router.get('/devices', async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    const filter = {};
    if (startDate && endDate) {
      filter.startTime = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    } else {
      const lastWeek = new Date();
      lastWeek.setDate(lastWeek.getDate() - 7);
      filter.startTime = { $gte: lastWeek };
    }

    const deviceStats = await UserSession.aggregate([
      { $match: filter },
      {
        $group: {
          _id: '$device',
          count: { $sum: 1 },
          avgDuration: { $avg: '$duration' },
          avgPages: { $avg: '$totalPages' }
        }
      },
      { $sort: { count: -1 } }
    ]);

    const browserStats = await UserSession.aggregate([
      { $match: filter },
      {
        $group: {
          _id: '$browser.name',
          count: { $sum: 1 },
          versions: { $addToSet: '$browser.version' }
        }
      },
      { $sort: { count: -1 } }
    ]);

    const osStats = await UserSession.aggregate([
      { $match: filter },
      {
        $group: {
          _id: '$os.name',
          count: { $sum: 1 },
          versions: { $addToSet: '$os.version' }
        }
      },
      { $sort: { count: -1 } }
    ]);

    res.json({
      success: true,
      data: {
        devices: deviceStats,
        browsers: browserStats,
        operatingSystems: osStats
      }
    });
  } catch (error) {
    console.error('Error fetching device analytics:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching device analytics',
      error: error.message
    });
  }
});

// GET /api/analytics/traffic - Get traffic over time
router.get('/traffic', async (req, res) => {
  try {
    const { 
      startDate, 
      endDate, 
      interval = 'day' // day, hour, week
    } = req.query;

    const filter = {};
    if (startDate && endDate) {
      filter.startTime = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    } else {
      const lastWeek = new Date();
      lastWeek.setDate(lastWeek.getDate() - 7);
      filter.startTime = { $gte: lastWeek };
    }

    let groupBy = {};
    switch (interval) {
      case 'hour':
        groupBy = {
          year: { $year: '$startTime' },
          month: { $month: '$startTime' },
          day: { $dayOfMonth: '$startTime' },
          hour: { $hour: '$startTime' }
        };
        break;
      case 'week':
        groupBy = {
          year: { $year: '$startTime' },
          week: { $week: '$startTime' }
        };
        break;
      default: // day
        groupBy = {
          year: { $year: '$startTime' },
          month: { $month: '$startTime' },
          day: { $dayOfMonth: '$startTime' }
        };
    }

    const trafficData = await UserSession.aggregate([
      { $match: filter },
      {
        $group: {
          _id: groupBy,
          sessions: { $sum: 1 },
          pageViews: { $sum: '$totalPages' },
          uniqueVisitors: { $addToSet: '$ipAddress' },
          avgDuration: { $avg: '$duration' }
        }
      },
      {
        $addFields: {
          uniqueVisitors: { $size: '$uniqueVisitors' }
        }
      },
      { $sort: { '_id': 1 } }
    ]);

    res.json({
      success: true,
      data: trafficData
    });
  } catch (error) {
    console.error('Error fetching traffic analytics:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching traffic analytics',
      error: error.message
    });
  }
});

// POST /api/analytics/cleanup - Manually trigger session cleanup (admin only)
router.post('/cleanup', async (req, res) => {
  try {
    const { cleanupSessions } = await import('../middleware/sessionTracking.js');
    const result = await cleanupSessions();

    res.json({
      success: true,
      message: 'Session cleanup completed',
      data: {
        cleanedSessions: result.modifiedCount
      }
    });
  } catch (error) {
    console.error('Error during session cleanup:', error);
    res.status(500).json({
      success: false,
      message: 'Error during session cleanup',
      error: error.message
    });
  }
});

export default router;