import { BiCheck, BiX, BiTrash, BiEdit } from 'react-icons/bi';

const CoachNotificationModal = ({ 
  isOpen, 
  onClose, 
  type, // 'success', 'error', 'delete', 'update'
  coachName,
  operation, // 'created', 'updated', 'deleted'
  message,
  confirmAction,
  isConfirmModal = false
}) => {
  if (!isOpen) return null;

  const getModalConfig = () => {
    switch (type) {
      case 'success':
        return {
          bgColor: 'bg-green-500/10 border-green-500/20',
          iconBg: 'bg-green-500/20',
          iconColor: 'text-green-400',
          icon: <BiCheck size={24} />,
          title: `Coach ${operation === 'created' ? 'Created' : operation === 'updated' ? 'Updated' : 'Action Completed'}`,
          titleColor: 'text-green-400'
        };
      case 'error':
        return {
          bgColor: 'bg-red-500/10 border-red-500/20',
          iconBg: 'bg-red-500/20',
          iconColor: 'text-red-400',
          icon: <BiX size={24} />,
          title: 'Error',
          titleColor: 'text-red-400'
        };
      case 'delete':
        return {
          bgColor: 'bg-red-500/10 border-red-500/20',
          iconBg: 'bg-red-500/20',
          iconColor: 'text-red-400',
          icon: <BiTrash size={24} />,
          title: 'Delete Coach',
          titleColor: 'text-red-400'
        };
      case 'update':
        return {
          bgColor: 'bg-blue-500/10 border-blue-500/20',
          iconBg: 'bg-blue-500/20',
          iconColor: 'text-blue-400',
          icon: <BiEdit size={24} />,
          title: 'Update Coach',
          titleColor: 'text-blue-400'
        };
      default:
        return {
          bgColor: 'bg-gray-500/10 border-gray-500/20',
          iconBg: 'bg-gray-500/20',
          iconColor: 'text-gray-400',
          icon: <BiCheck size={24} />,
          title: 'Notification',
          titleColor: 'text-gray-400'
        };
    }
  };

  const config = getModalConfig();

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-lg border border-gray-700 max-w-md w-full mx-auto shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${config.iconBg}`}>
              <span className={config.iconColor}>
                {config.icon}
              </span>
            </div>
            <h3 className={`text-lg font-semibold ${config.titleColor}`}>
              {config.title}
            </h3>
          </div>
          
          {!isConfirmModal && (
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <BiX size={20} />
            </button>
          )}
        </div>

        {/* Content */}
        <div className={`p-6 border-2 rounded-b-lg ${config.bgColor}`}>
          {coachName && (
            <div className="mb-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-sm font-medium text-orange-400">Coach:</span>
                <span className="text-white font-semibold">{coachName}</span>
              </div>
            </div>
          )}

          {operation && !isConfirmModal && (
            <div className="mb-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-sm font-medium text-orange-400">Operation:</span>
                <span className="text-white capitalize">{operation}</span>
              </div>
            </div>
          )}

          <div className="text-gray-300">
            {message || (isConfirmModal 
              ? `Are you sure you want to delete "${coachName}"? This action cannot be undone.`
              : `Coach "${coachName}" has been ${operation} successfully!`
            )}
          </div>

          {type === 'success' && !isConfirmModal && (
            <div className="mt-4 p-3 bg-green-500/5 border border-green-500/20 rounded-lg">
              <div className="flex items-center gap-2 text-sm">
                <BiCheck className="text-green-400" size={16} />
                <span className="text-green-400">
                  The changes have been saved and are now active.
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 p-6 border-t border-gray-700">
          {isConfirmModal ? (
            <>
              <button
                onClick={onClose}
                className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={confirmAction}
                className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors flex items-center gap-2"
              >
                <BiTrash size={16} />
                Delete Coach
              </button>
            </>
          ) : (
            <button
              onClick={onClose}
              className={`px-6 py-2 rounded-lg transition-colors ${
                type === 'success' 
                  ? 'bg-green-500 hover:bg-green-600 text-white'
                  : type === 'error'
                  ? 'bg-red-500 hover:bg-red-600 text-white'
                  : 'bg-gray-600 hover:bg-gray-700 text-white'
              }`}
            >
              {type === 'success' ? 'Great!' : type === 'error' ? 'Got it' : 'OK'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default CoachNotificationModal;