import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router';
import DateTimePicker from '../components/DateTimePicker';

const Booking = () => {
  const navigate = useNavigate();
  const [selectedSport, setSelectedSport] = useState('');
  const [selectedDateTime, setSelectedDateTime] = useState({
    date: '',
    time: '',
    datetime: null
  });
  const [tennisExtras, setTennisExtras] = useState({
    rackets: 0,
    courts: 0
  });
  const [selectedCoach, setSelectedCoach] = useState('');
  const [isBooking, setIsBooking] = useState(false);
  const [tennisCoaches, setTennisCoaches] = useState([]);
  const [loadingCoaches, setLoadingCoaches] = useState(false);
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    email: '',
    phone: ''
  });

  // LocalStorage functions
  const saveBookingToStorage = (bookingData) => {
    try {
      localStorage.setItem('sportsBookingData', JSON.stringify(bookingData));
    } catch (error) {
      console.error('Error saving booking data to localStorage:', error);
    }
  };

  const loadBookingFromStorage = () => {
    try {
      const savedData = localStorage.getItem('sportsBookingData');
      return savedData ? JSON.parse(savedData) : null;
    } catch (error) {
      console.error('Error loading booking data from localStorage:', error);
      return null;
    }
  };

  const clearBookingStorage = () => {
    try {
      localStorage.removeItem('sportsBookingData');
    } catch (error) {
      console.error('Error clearing booking data from localStorage:', error);
    }
  };

  // Save to localStorage whenever booking data changes
  useEffect(() => {
    if (selectedSport || selectedDateTime.date || selectedDateTime.time || selectedCoach || tennisExtras.rackets > 0 || tennisExtras.courts > 0) {
      // Create booking data object
      const bookingData = {
        sport: selectedSport,
        dateTime: selectedDateTime,
        timestamp: new Date().toISOString(),
        sessionId: `booking_${Date.now()}`,
      };

      // Add tennis-specific data if tennis is selected
      if (selectedSport === 'tennis') {
        bookingData.tennis = {
          coach: selectedCoach ? tennisCoaches.find(c => c._id === selectedCoach) : null,
          extras: tennisExtras,
          totalExtrasCost: (tennisExtras.rackets * 5) + (tennisExtras.courts * 15)
        };
      }

      saveBookingToStorage(bookingData);
    }
  }, [selectedSport, selectedDateTime, selectedCoach, tennisExtras, tennisCoaches]);

  // Fetch tennis coaches from API (memoized to prevent unnecessary re-renders)
  const fetchTennisCoaches = useCallback(async () => {
    setLoadingCoaches(true);
    try {
      const response = await fetch('http://localhost:5000/api/coaches/sport/tennis');
      if (response.ok) {
        const result = await response.json();
        setTennisCoaches(result.data || []);
      } else {
        console.error('Failed to fetch coaches');
        setTennisCoaches([]);
      }
    } catch (error) {
      console.error('Error fetching coaches:', error);
      setTennisCoaches([]);
    } finally {
      setLoadingCoaches(false);
    }
  }, []);

  // Effect to handle sport selection changes
  useEffect(() => {
    if (selectedSport === 'tennis') {
      // Only fetch coaches if we don't have them already
      if (tennisCoaches.length === 0) {
        fetchTennisCoaches();
      }
    } else if (selectedSport && selectedSport !== 'tennis') {
      // Reset tennis-specific data when other sports are selected
      setSelectedCoach('');
      setTennisExtras({ rackets: 0, courts: 0 });
      setTennisCoaches([]);
    }
  }, [selectedSport, tennisCoaches.length, fetchTennisCoaches]);

  // Effect to handle sport-specific configurations and data loading
  useEffect(() => {
    const handleSportSpecificSetup = async () => {
      switch (selectedSport) {
        case 'tennis':
          // Tennis-specific setup is handled in the previous useEffect
          break;
        case 'football':
          // Future: Load football-specific data (coaches, equipment, etc.)
          break;
        case 'basketball':
          // Future: Load basketball-specific data
          break;
        case 'swimming':
          // Future: Load swimming-specific data
          break;
        default:
          // Reset all sport-specific data when no sport is selected
          setSelectedCoach('');
          setTennisExtras({ rackets: 0, courts: 0 });
          setTennisCoaches([]);
          break;
      }
    };

    if (selectedSport) {
      handleSportSpecificSetup();
    }
  }, [selectedSport]);

  // Effect to reset form when component mounts
  useEffect(() => {
    // Clear any existing localStorage data on initial load
    const savedBooking = loadBookingFromStorage();
    if (savedBooking) {
      setSelectedSport(savedBooking.sport || '');
      setSelectedDateTime(savedBooking.dateTime || { date: '', time: '', datetime: null });
      
      if (savedBooking.tennis) {
        setSelectedCoach(savedBooking.tennis.coach?.id || '');
        setTennisExtras(savedBooking.tennis.extras || { rackets: 0, courts: 0 });
      }
    }
  }, []);
  const handleSportChange = (e) => {
    setSelectedSport(e.target.value);
  };

  const handleCoachChange = (e) => {
    setSelectedCoach(e.target.value);
  };

  const handleDateTimeChange = (dateTimeData) => {
    setSelectedDateTime(dateTimeData);
  };

  const handleCustomerInfoChange = (e) => {
    const { name, value } = e.target;
    setCustomerInfo(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const updateTennisExtras = (type, increment) => {
    setTennisExtras(prev => ({
      ...prev,
      [type]: Math.max(0, prev[type] + increment)
    }));
  };

  const clearBookingForm = () => {
    setSelectedSport('');
    setSelectedDateTime({ date: '', time: '', datetime: null });
    setSelectedCoach('');
    setTennisExtras({ rackets: 0, courts: 0 });
    setTennisCoaches([]);
    setCustomerInfo({ name: '', email: '', phone: '' });
  };



  return (
    <div className='min-h-screen bg-black text-white flex pt-24'>
      {/* Left Panel */}
      <div className='w-1/3 bg-gray-900 p-6 border-r border-gray-700 max-h-[calc(100vh-6rem)] overflow-y-auto'>
        <div className='mb-8'>
          <h2 className='text-2xl font-bold mb-4 text-orange-500'>Sports Categories</h2>
          <select 
            value={selectedSport}
            onChange={handleSportChange}
            className='w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white text-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 cursor-pointer'
          >
            <option value="">Select a sport...</option>
            <option value="football">Football</option>
            <option value="basketball">Basketball</option>
            <option value="tennis">Tennis</option>
            <option value="swimming">Swimming</option>
          </select>
          {selectedSport && (
            <div className="mt-4 p-3 bg-gray-800 rounded-lg border border-orange-500">
              <p className="text-orange-500 font-semibold">Selected: {selectedSport.charAt(0).toUpperCase() + selectedSport.slice(1)}</p>
            </div>
          )}
        </div>
        
        <div className='mb-8'>
          <h3 className='text-xl font-semibold mb-4 text-orange-500'>Quick Info</h3>
          <div className='space-y-2 text-sm'>
            {selectedSport ? (
              <>
                <p className='text-gray-300'>🏆 Sport: <span className="text-orange-400 font-semibold">{selectedSport.charAt(0).toUpperCase() + selectedSport.slice(1)}</span></p>
                {selectedDateTime.date && (
                  <p className='text-gray-300'>📅 Date: <span className="text-orange-400 font-semibold">
                    {new Date(selectedDateTime.date).toLocaleDateString('en-US', {
                      weekday: 'short',
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric'
                    })}
                  </span></p>
                )}
                {selectedDateTime.time && (
                  <p className='text-gray-300'>⏰ Time: <span className="text-orange-400 font-semibold">
                    {new Date(`2000-01-01T${selectedDateTime.time}`).toLocaleTimeString('en-US', {
                      hour: '2-digit',
                      minute: '2-digit',
                      hour12: true
                    })}
                  </span></p>
                )}
                {selectedSport === 'tennis' && selectedCoach && (
                  <div className="border-t border-gray-600 pt-2 mt-2">
                    <p className="text-gray-300 font-semibold mb-1">Tennis Coach:</p>
                    <p className='text-gray-300'>👨‍🏫 Coach: <span className="text-orange-400 font-semibold">
                      {tennisCoaches.find(c => c._id === selectedCoach)?.name || selectedCoach}
                    </span></p>
                  </div>
                )}
                {selectedSport === 'tennis' && (tennisExtras.rackets > 0 || tennisExtras.courts > 0) && (
                  <div className="border-t border-gray-600 pt-2 mt-2">
                    <p className="text-gray-300 font-semibold mb-1">Tennis Extras:</p>
                    {tennisExtras.rackets > 0 && (
                      <p className='text-gray-300'>🎾 Rackets: <span className="text-orange-400 font-semibold">{tennisExtras.rackets}</span></p>
                    )}
                    {tennisExtras.courts > 0 && (
                      <p className='text-gray-300'>🏟️ Courts: <span className="text-orange-400 font-semibold">{tennisExtras.courts}</span></p>
                    )}
                  </div>
                )}
                <div className="border-t border-gray-600 pt-2 mt-3">
                  <p className='text-gray-300'>💰 Starting from $20/hour</p>
                  <p className='text-gray-300'>🏆 Professional facilities</p>
                </div>
              </>
            ) : (
              <>
                <p className='text-gray-300'>📅 Available 7 days a week</p>
                <p className='text-gray-300'>⏰ 6:00 AM - 10:00 PM</p>
                <p className='text-gray-300'>💰 Starting from $20/hour</p>
                <p className='text-gray-300'>🏆 Professional facilities</p>
              </>
            )}
          </div>
        </div>

        <div>
          <h3 className='text-xl font-semibold mb-4 text-orange-500'>Contact</h3>
          <div className='space-y-2 text-sm'>
            <p className='text-gray-300'>📞 +1 (555) 123-4567</p>
            <p className='text-gray-300'>📧 booking@advancedsports.ke</p>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className='flex-1 flex items-start justify-center p-6 max-h-[calc(100vh-6rem)] overflow-y-auto'>
        <div className='w-full max-w-2xl'>
          <div className='text-center mb-8'>
            <h1 className='text-4xl font-bold mb-4 text-orange-500'>Book Your Session</h1>
            <p className='text-xl text-gray-300'>
              {selectedSport 
                ? `Schedule your ${selectedSport} session` 
                : 'Select a sport category to get started'
              }
            </p>
          </div>
          
          {selectedSport && (
            <div className='bg-gray-900 p-6 rounded-lg border border-gray-700'>
              {selectedSport === 'tennis' && (
                <div className="mb-6 pb-6 border-b border-gray-600">
                  <h3 className="text-xl font-semibold text-orange-500 mb-4">Select Your Tennis Coach</h3>
                  <select 
                    value={selectedCoach}
                    onChange={handleCoachChange}
                    disabled={loadingCoaches}
                    className='w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white text-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed'
                  >
                    <option value="">
                      {loadingCoaches ? 'Loading coaches...' : 'Choose a coach...'}
                    </option>
                    {tennisCoaches
                      .filter(coach => coach && coach._id && coach.name && coach.isActive)
                      .map(coach => (
                        <option key={coach._id} value={coach._id}>
                          {coach.name} - {coach.specialty} ({coach.rate})
                        </option>
                      ))}
                  </select>
                  {selectedCoach && (
                    <div className="mt-3 p-3 bg-gray-800 rounded-lg border border-orange-500">
                      {(() => {
                        const coach = tennisCoaches.find(c => c._id === selectedCoach);
                        return coach ? (
                          <div className="text-sm">
                            <p className="text-orange-500 font-semibold">{coach.name}</p>
                            <p className="text-gray-300">{coach.specialty}</p>
                            <p className="text-gray-400">{coach.rate}</p>
                          </div>
                        ) : null;
                      })()}
                    </div>
                  )}
                </div>
              )}

              {/* Customer Information Form */}
              <div className="mb-6 pb-6 border-b border-gray-600">
                <h3 className="text-xl font-semibold text-orange-500 mb-4">Your Information</h3>
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={customerInfo.name}
                      onChange={handleCustomerInfoChange}
                      required
                      className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                      placeholder="Enter your full name"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={customerInfo.email}
                        onChange={handleCustomerInfoChange}
                        required
                        className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                        placeholder="your@email.com"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={customerInfo.phone}
                        onChange={handleCustomerInfoChange}
                        required
                        className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                        placeholder="+254700123456"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {selectedSport === 'tennis' && !selectedCoach && (
                <div className="mb-6 p-4 bg-blue-900/30 border border-blue-500/50 rounded-lg">
                  <p className="text-blue-400 text-sm">
                    💡 <strong>Tip:</strong> Select a tennis coach above to see their specific availability times for booking.
                  </p>
                </div>
              )}
              
              <DateTimePicker 
                onDateTimeChange={handleDateTimeChange}
                label="Schedule Your Session"
                className="mb-6"
                selectedCoach={selectedCoach ? tennisCoaches.find(c => c._id === selectedCoach) : null}
                coachAvailability={selectedCoach ? tennisCoaches.find(c => c._id === selectedCoach)?.availability : null}
              />

              {selectedSport === 'tennis' && (
                <div className="mt-6 pt-6 border-t border-gray-600">
                  <h3 className="text-xl font-semibold text-orange-500 mb-4">Tennis Equipment & Facilities</h3>
                  
                  {/* Racket Hire */}
                  <div className="mb-4 p-4 bg-gray-800 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h4 className="text-lg font-medium text-white">Tennis Racket Hire</h4>
                        <p className="text-sm text-gray-400">$5 per racket per session</p>
                      </div>
                      <div className="flex items-center space-x-3">
                        <button 
                          onClick={() => updateTennisExtras('rackets', -1)}
                          disabled={tennisExtras.rackets === 0}
                          className="w-8 h-8 bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-full flex items-center justify-center transition-colors"
                        >
                          -
                        </button>
                        <span className="text-lg font-semibold text-orange-500 min-w-[2rem] text-center">
                          {tennisExtras.rackets}
                        </span>
                        <button 
                          onClick={() => updateTennisExtras('rackets', 1)}
                          className="w-8 h-8 bg-orange-500 hover:bg-orange-600 text-white rounded-full flex items-center justify-center transition-colors"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Court Hire */}
                  <div className="mb-4 p-4 bg-gray-800 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h4 className="text-lg font-medium text-white">Tennis Court Hire</h4>
                        <p className="text-sm text-gray-400">$15 per court per hour</p>
                      </div>
                      <div className="flex items-center space-x-3">
                        <button 
                          onClick={() => updateTennisExtras('courts', -1)}
                          disabled={tennisExtras.courts === 0}
                          className="w-8 h-8 bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-full flex items-center justify-center transition-colors"
                        >
                          -
                        </button>
                        <span className="text-lg font-semibold text-orange-500 min-w-[2rem] text-center">
                          {tennisExtras.courts}
                        </span>
                        <button 
                          onClick={() => updateTennisExtras('courts', 1)}
                          className="w-8 h-8 bg-orange-500 hover:bg-orange-600 text-white rounded-full flex items-center justify-center transition-colors"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Cost Summary for Tennis */}
                  {(tennisExtras.rackets > 0 || tennisExtras.courts > 0) && (
                    <div className="mt-4 p-3 bg-gray-700 rounded-lg">
                      <h5 className="text-sm font-semibold text-orange-500 mb-2">Additional Costs:</h5>
                      <div className="text-sm text-gray-300 space-y-1">
                        {tennisExtras.rackets > 0 && (
                          <p>• Rackets: {tennisExtras.rackets} × $5 = ${tennisExtras.rackets * 5}</p>
                        )}
                        {tennisExtras.courts > 0 && (
                          <p>• Courts: {tennisExtras.courts} × $15 = ${tennisExtras.courts * 15}</p>
                        )}
                        <div className="border-t border-gray-600 pt-2 mt-2">
                          <p className="font-semibold text-orange-400">
                            Extras Total: ${(tennisExtras.rackets * 5) + (tennisExtras.courts * 15)}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
              
              {selectedDateTime.datetime && (
                <div className="mt-6 pt-6 border-t border-gray-600">
                  <button 
                    onClick={async () => {
                      // Validate customer information
                      if (!customerInfo.name.trim() || !customerInfo.email.trim() || !customerInfo.phone.trim()) {
                        alert('Please fill in all required fields (Name, Email, Phone)');
                        return;
                      }

                      // Basic email validation
                      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                      if (!emailRegex.test(customerInfo.email)) {
                        alert('Please enter a valid email address');
                        return;
                      }

                      // Basic phone validation (remove spaces and hyphens for API)
                      const cleanPhone = customerInfo.phone.replace(/[\s-]/g, '');
                      if (cleanPhone.length < 10) {
                        alert('Please enter a valid phone number');
                        return;
                      }

                      setIsBooking(true);
                      try {
                        // Create the booking payload for the backend according to validation schema
                        const bookingData = {
                          sport: selectedSport,
                          dateTime: {
                            date: selectedDateTime.date,
                            time: selectedDateTime.time,
                            datetime: new Date(`${selectedDateTime.date}T${selectedDateTime.time}`)
                          },
                          status: 'pending',
                          sessionId: `booking_${Date.now()}`,
                          userInfo: {
                            name: customerInfo.name.trim(),
                            email: customerInfo.email.trim(),
                            phone: cleanPhone
                          },
                          ...(selectedSport === 'tennis' && {
                            tennis: {
                              ...(selectedCoach && {
                                coach: {
                                  id: selectedCoach,
                                  name: tennisCoaches.find(c => c._id === selectedCoach)?.name || selectedCoach,
                                  specialty: tennisCoaches.find(c => c._id === selectedCoach)?.specialty || '',
                                  rate: tennisCoaches.find(c => c._id === selectedCoach)?.rate || ''
                                }
                              }),
                              extras: {
                                rackets: tennisExtras.rackets,
                                courts: tennisExtras.courts
                              },
                              totalExtrasCost: (tennisExtras.rackets * 5) + (tennisExtras.courts * 15)
                            }
                          }),
                          pricing: {
                            baseCost: 30,
                            extrasCost: selectedSport === 'tennis' ? (tennisExtras.rackets * 5) + (tennisExtras.courts * 15) + (selectedCoach ? 25 : 0) : 0,
                            totalCost: 30 + (selectedSport === 'tennis' ? (tennisExtras.rackets * 5) + (tennisExtras.courts * 15) + (selectedCoach ? 25 : 0) : 0)
                          },
                          notes: 'Booking created from frontend'
                        };

                        // Submit to backend API
                        const response = await fetch('http://localhost:5000/api/bookings', {
                          method: 'POST',
                          headers: {
                            'Content-Type': 'application/json',
                          },
                          body: JSON.stringify(bookingData)
                        });

                        if (response.ok) {
                          const result = await response.json();
                          
                          // Store booking confirmation for display on home page
                          const bookingConfirmation = {
                            ...result.data,
                            customerInfo,
                            confirmedAt: new Date().toISOString(),
                            selectedCoachData: selectedCoach ? tennisCoaches.find(c => c._id === selectedCoach) : null
                          };
                          
                          localStorage.setItem('bookingConfirmation', JSON.stringify(bookingConfirmation));
                          localStorage.setItem('showBookingConfirmation', 'true');
                          
                          // Clear the form
                          clearBookingForm();
                          
                          // Navigate to home page
                          navigate('/');
                          
                        } else {
                          const error = await response.json();
                          console.error('Booking failed:', error);
                          alert(`Booking failed: ${error.message || 'Unknown error'}`);
                        }
                      } catch (error) {
                        console.error('Network error:', error);
                        alert('Network error. Please check your connection and try again.');
                      } finally {
                        setIsBooking(false);
                      }
                    }}
                    disabled={isBooking || !customerInfo.name.trim() || !customerInfo.email.trim() || !customerInfo.phone.trim()}
                    className="w-full bg-orange-500 hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-lg transition-colors duration-300 mb-3"
                  >
                    {isBooking ? 'Booking...' : 'Confirm Booking'}
                  </button>
                  <button 
                    onClick={() => {
                      clearBookingStorage();
                      clearBookingForm();
                      alert('Booking data cleared!');
                    }}
                    className="w-full bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition-colors duration-300"
                  >
                    Clear Booking
                  </button>
                  <p className="text-center text-gray-400 text-sm mt-3">
                    Review your selection and click to confirm
                  </p>
                </div>
              )}
            </div>
          )}

          {!selectedSport && (
            <div className='bg-gray-900 p-8 rounded-lg border border-gray-700 text-center'>
              <div className="text-6xl mb-4">🏆</div>
              <p className='text-gray-400 text-lg'>
                Choose your preferred sport from the left panel to begin booking your session
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Booking