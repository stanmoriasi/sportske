import logo from "../assets/logo.png";
import { useLocation, Link, useNavigate } from "react-router";
import { useState, useEffect } from "react";
import NavLink from "./NavLink";
import AuthForm from "./AuthForm";
import { useAuth } from "../contexts/AuthContext";
import { FaX } from "react-icons/fa6";
import { BiMenu, BiX, BiUser, BiLogOut } from "react-icons/bi";

const services = [
  {
    name: "Tennis",
    slug: "tennis",
  },
  {
    name: "Football",
    slug: "football",
  },
  {
    name: "Basketball",
    slug: "basketball",
  },
  {
    name: "Swimming ",
    slug: "swimming",
  },
];

const Header = () => {
  const location = useLocation();
  const { user, isAuthenticated, isAdmin, logout, login } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showAuthForm, setShowAuthForm] = useState(false);
  const currentPath = location.pathname.split("/").filter(Boolean).pop() || "/";
  const navigate = useNavigate();

  const isActive = (href) => {
    if (href === "/") return location.pathname === "/";
    
    if (href === "/services") {
      return location.pathname === "/services" || location.pathname.startsWith("/services/");
    }
    
    const hrefLast = href.split("/").filter(Boolean).pop();
    return currentPath === hrefLast;
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      if (isMobileMenuOpen) {
        closeMobileMenu();
      }
    };

    const handleClickOutside = (event) => {
      if (
        isMobileMenuOpen &&
        !event.target.closest(".mobile-menu") &&
        !event.target.closest(".mobile-menu-button")
      ) {
        closeMobileMenu();
      }
    };

    if (isMobileMenuOpen) {
      window.addEventListener("scroll", handleScroll);
      document.addEventListener("mousedown", handleClickOutside);
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }

    return () => {
      window.removeEventListener("scroll", handleScroll);
      document.removeEventListener("mousedown", handleClickOutside);
      document.body.style.overflow = "unset";
    };
  }, [isMobileMenuOpen]);

  return (
    <>
      <div className="flex justify-between items-center text-white px-4 sm:px-8 lg:px-[75px] py-4">
        <Link
          to="/"
          className="h-16 w-16 sm:w-20 sm:h-14 lg:w-24 lg:h-24 bg-cover bg-center"
          style={{ backgroundImage: `url(${logo})` }}
        />

        <div className="hidden lg:flex items-center gap-8">
          <ul className="flex gap-[40px]">
            <li>
              <NavLink
                href="/"
                active={isActive("/")}
                className="text-xl font-semibold"
              >
                Home
              </NavLink>
            </li>
            <li>
              <NavLink
                href="/about"
                active={isActive("/about")}
                className="text-xl font-semibold"
              >
                About Us
              </NavLink>
            </li>
            <li className="group relative">
              <NavLink
                href="/services"
                active={isActive("/services")}
                className="text-xl font-semibold"
              >
                Services
              </NavLink>
              <ul
            className={`absolute left-0 -mt-1 bg-black shadow-lg w-56 opacity-0 group-hover:opacity-100 group-hover:translate-y-1 pointer-events-none group-hover:pointer-events-auto`}
            style={{ zIndex: 1000 }}
          >
            {services.map((service) => (
              <li key={service.name}>
                <button
                  onClick={() => {
                    navigate(`/services/${service.slug}`);
                  }}
                  className="block px-4 py-2 hover:bg-white/20 w-full text-left"
                >
                  {service.name}
                </button>
              </li>
            ))}
          </ul>
            </li>
            <li>
              <NavLink
                href="/gallery"
                active={isActive("/gallery")}
                className="text-xl font-semibold"
              >
                Gallery
              </NavLink>
            </li>
            <li>
              <NavLink
                href="/contact"
                active={isActive("/contact")}
                className="text-xl font-semibold"
              >
                Contact
              </NavLink>
            </li>
            <li>
              <NavLink
                href="/booking"
                active={isActive("/booking")}
                className="text-xl font-semibold"
              >
                Booking
              </NavLink>
            </li>
            {isAuthenticated() && isAdmin() && (
              <>
                <li>
                  <NavLink
                    href="/admin/coaches"
                    active={isActive("/admin/coaches")}
                    className="text-xl font-semibold"
                  >
                    Coaches
                  </NavLink>
                </li>
                <li>
                  <NavLink
                    href="/admin/bookings"
                    active={isActive("/admin/bookings")}
                    className="text-xl font-semibold"
                  >
                    Bookings
                  </NavLink>
                </li>
                <li>
                  <NavLink
                    href="/admin/users"
                    active={isActive("/admin/users")}
                    className="text-xl font-semibold"
                  >
                    Users
                  </NavLink>
                </li>
                <li>
                  <NavLink
                    href="/admin/analytics"
                    active={isActive("/admin/analytics")}
                    className="text-xl font-semibold"
                  >
                    Analytics
                  </NavLink>
                </li>
              </>
            )}
          </ul>
          
          {/* Authentication Section */}
          <div className="flex items-center gap-3">
            {isAuthenticated() ? (
              <div className="flex items-center gap-3">
                <div className="hidden md:flex items-center gap-2 text-sm">
                  <BiUser className="text-orange-500" />
                  <span className="text-white">{user?.name || user?.email}</span>
                  {isAdmin() && (
                    <span className="px-2 py-1 bg-orange-500 text-white text-xs rounded">
                      Admin
                    </span>
                  )}
                </div>
                <button
                  onClick={async () => {
                    await logout();
                    navigate('/');
                  }}
                  className="flex items-center gap-1 text-gray-300 hover:text-white text-sm transition-colors"
                  title="Logout"
                >
                  <BiLogOut size={16} />
                  <span className="hidden md:inline">Logout</span>
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowAuthForm(true)}
                className="flex items-center gap-1 text-gray-300 hover:text-white text-sm transition-colors"
              >
                <BiUser size={16} />
                <span className="hidden md:inline">Admin Login</span>
              </button>
            )}
            
            <Link to="/booking" className="bg-primary text-white px-4 py-2 rounded hover:bg-primary/90 transition-colors duration-300">
              Book Now
            </Link>
          </div>
        </div>

        <button
          className="mobile-menu-button z-100 lg:hidden flex flex-col justify-center items-center space-y-1"
          onClick={toggleMobileMenu}
          aria-label="Toggle mobile menu"
        >
          {isMobileMenuOpen ? <BiX size={32} /> : <BiMenu size={32} />}
        </button>
      </div>

      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 lg:hidden"
          onClick={closeMobileMenu}
        ></div>
      )}

      <div
        className={`mobile-menu fixed top-0 left-0 w-[75vw] h-full bg-black z-100 transform transition-transform duration-300 ease-in-out lg:hidden ${
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full p-6 pt-20">
          <nav className="flex flex-col space-y-6">
            <Link
              to="/"
              className="text-lg font-semibold text-white border-b border-gray-800 pb-2"
              onClick={closeMobileMenu}
            >
              Home
            </Link>
            <Link
              to="/about"
              className="text-lg font-semibold text-white border-b border-gray-800 pb-2"
              onClick={closeMobileMenu}
            >
              About Us
            </Link>
            <Link
              to="/services"
              className="text-lg font-semibold text-white border-b border-gray-800 pb-2"
              onClick={closeMobileMenu}
            >
              Services
            </Link>
            {services.map((service) => (
              <Link
                key={service.name}
                to={`/services/${service.slug}`}
                className="text-md text-white/80 border-b border-gray-800 pb-2 pl-4"
                onClick={closeMobileMenu}
              >
                {service.name}
              </Link>
            ))}
            <Link
              to="/gallery"
              className="text-lg font-semibold text-white border-b border-gray-800 pb-2"
              onClick={closeMobileMenu}
            >
              Gallery
            </Link>
            <Link
              to="/contact"
              className="text-lg font-semibold text-white border-b border-gray-800 pb-2"
              onClick={closeMobileMenu}
            >
              Contact
            </Link>
            <Link
              to="/booking"
              className="text-lg font-semibold text-white border-b border-gray-800 pb-2"
              onClick={closeMobileMenu}
            >
              Booking
            </Link>
            {isAuthenticated() && isAdmin() && (
              <>
                <Link
                  to="/admin/coaches"
                  className="text-lg font-semibold text-orange-500 border-b border-gray-800 pb-2"
                  onClick={closeMobileMenu}
                >
                  Admin: Coaches
                </Link>
                <Link
                  to="/admin/bookings"
                  className="text-lg font-semibold text-orange-500 border-b border-gray-800 pb-2"
                  onClick={closeMobileMenu}
                >
                  Admin: Bookings
                </Link>
                <Link
                  to="/admin/users"
                  className="text-lg font-semibold text-orange-500 border-b border-gray-800 pb-2"
                  onClick={closeMobileMenu}
                >
                  Admin: Users
                </Link>
                <Link
                  to="/admin/analytics"
                  className="text-lg font-semibold text-orange-500 border-b border-gray-800 pb-2"
                  onClick={closeMobileMenu}
                >
                  Admin: Analytics
                </Link>
              </>
            )}
          </nav>

          <div className="mt-8">
            <Link
              to="/booking"
              className="bg-primary text-white px-6 py-3 rounded-lg w-full hover:bg-primary/90 transition-colors duration-300 text-center block"
              onClick={closeMobileMenu}
            >
              Book Now
            </Link>
          </div>
        </div>
      </div>
      
      {/* Authentication Modal */}
      {showAuthForm && (
        <AuthForm
          onAuthSuccess={(userData, token) => {
            login(userData, token);
            setShowAuthForm(false);
          }}
          onClose={() => setShowAuthForm(false)}
        />
      )}
    </>
  );
};

export default Header;
