import mongoose from 'mongoose';
import dotenv from 'dotenv';
import User from '../models/User.js';

// Load environment variables
dotenv.config();

const seedUsers = async () => {
  try {
    console.log('🚀 Starting user seeding process...');
    
    // Check MongoDB URI
    if (!process.env.MONGODB_URI) {
      console.error('❌ MONGODB_URI not found in environment variables');
      return;
    }
    
    console.log('📡 Connecting to MongoDB...');
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB for seeding users...');

    // Check if admin user already exists
    console.log('🔍 Checking for existing admin user...');
    const existingAdmin = await User.findByEmail('admin@advancedsports.ke');
    
    if (existingAdmin) {
      console.log('⚠️  Admin user already exists. Skipping admin creation...');
      console.log(`   Existing admin: ${existingAdmin.name} (${existingAdmin.email})`);
    } else {
      // Create admin user
      console.log('👤 Creating admin user...');
      const adminUser = await User.create({
        name: 'Admin User',
        email: 'admin@advancedsports.ke',
        password: 'admin123', // Will be hashed automatically
        role: 'admin',
        isAdmin: true
      });

      console.log('✅ Admin user created successfully:');
      console.log(`   Email: ${adminUser.email}`);
      console.log(`   Password: admin123`);
      console.log(`   Role: ${adminUser.role}`);
      console.log(`   ID: ${adminUser.id}`);
    }

    // Check if demo user already exists
    console.log('🔍 Checking for existing demo user...');
    const existingDemo = await User.findByEmail('user@test.com');
    
    if (existingDemo) {
      console.log('⚠️  Demo user already exists. Skipping demo creation...');
      console.log(`   Existing demo: ${existingDemo.name} (${existingDemo.email})`);
    } else {
      // Create a demo regular user
      console.log('👤 Creating demo user...');
      const demoUser = await User.create({
        name: 'Demo User',
        email: 'user@test.com',
        password: 'password123', // Will be hashed automatically
        role: 'user',
        isAdmin: false
      });

      console.log('✅ Demo user created successfully:');
      console.log(`   Email: ${demoUser.email}`);
      console.log(`   Password: password123`);
      console.log(`   Role: ${demoUser.role}`);
      console.log(`   ID: ${demoUser.id}`);
    }

  } catch (error) {
    console.error('Error seeding users:', error);
  } finally {
    await mongoose.disconnect();
    console.log('Disconnected from MongoDB');
  }
};

// Run the seeding
seedUsers().then(() => {
  console.log('🎉 User seeding completed successfully!');
  process.exit(0);
}).catch((error) => {
  console.error('💥 User seeding failed:', error);
  process.exit(1);
});

export default seedUsers;