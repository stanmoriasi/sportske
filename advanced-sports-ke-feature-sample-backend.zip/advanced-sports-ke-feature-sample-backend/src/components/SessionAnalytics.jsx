import React, { useState, useEffect, useCallback } from 'react';

const SessionAnalytics = () => {
  const [analytics, setAnalytics] = useState({
    sessions: [],
    stats: {
      totalSessions: 0,
      totalPageViews: 0,
      avgPagesPerSession: 0,
      avgSessionDuration: 0,
      bounceRate: 0,
      uniqueVisitors: 0
    },
    pagination: {
      currentPage: 1,
      totalPages: 1,
      totalSessions: 0,
      limit: 20
    }
  });
  const [activeSessions, setActiveSessions] = useState([]);
  const [popularPages, setPopularPages] = useState([]);
  const [deviceStats, setDeviceStats] = useState({
    devices: [],
    browsers: [],
    operatingSystems: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [dateRange, setDateRange] = useState({
    startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 7 days ago
    endDate: new Date().toISOString().split('T')[0] // today
  });

  const fetchAnalytics = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        startDate: dateRange.startDate,
        endDate: dateRange.endDate,
        page: analytics.pagination.currentPage,
        limit: analytics.pagination.limit
      });

      const response = await fetch(`http://localhost:5000/api/analytics/sessions?${params}`);
      const result = await response.json();

      if (result.success) {
        setAnalytics(result.data);
      } else {
        setError('Failed to fetch analytics data');
      }
    } catch (err) {
      setError('Network error while fetching analytics');
      console.error('Analytics fetch error:', err);
    }
  }, [dateRange, analytics.pagination.currentPage, analytics.pagination.limit]);

  const fetchActiveSessions = useCallback(async () => {
    try {
      const response = await fetch('http://localhost:5000/api/analytics/active-sessions');
      const result = await response.json();

      if (result.success) {
        setActiveSessions(result.data.sessions);
      }
    } catch (err) {
      console.error('Active sessions fetch error:', err);
    }
  }, []);

  const fetchPopularPages = useCallback(async () => {
    try {
      const response = await fetch('http://localhost:5000/api/analytics/popular-pages?limit=10');
      const result = await response.json();

      if (result.success) {
        setPopularPages(result.data);
      }
    } catch (err) {
      console.error('Popular pages fetch error:', err);
    }
  }, []);

  const fetchDeviceStats = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        startDate: dateRange.startDate,
        endDate: dateRange.endDate
      });

      const response = await fetch(`http://localhost:5000/api/analytics/devices?${params}`);
      const result = await response.json();

      if (result.success) {
        setDeviceStats(result.data);
        setLoading(false);
      }
    } catch (err) {
      console.error('Device stats fetch error:', err);
      setLoading(false);
    }
  }, [dateRange]);

  useEffect(() => {
    fetchAnalytics();
    fetchActiveSessions();
    fetchPopularPages();
    fetchDeviceStats();
  }, [fetchAnalytics, fetchActiveSessions, fetchPopularPages, fetchDeviceStats]);

  const formatDuration = (minutes) => {
    if (minutes < 60) {
      return `${Math.round(minutes)}m`;
    }
    const hours = Math.floor(minutes / 60);
    const mins = Math.round(minutes % 60);
    return `${hours}h ${mins}m`;
  };

  const handleDateRangeChange = (field, value) => {
    setDateRange(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p>Loading session analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6 pt-24">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-orange-500 mb-2">Session Analytics</h1>
          <p className="text-gray-300">Website traffic and user behavior insights</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-900/30 border border-red-600 rounded text-red-400">
            {error}
          </div>
        )}

        {/* Date Range Selector */}
        <div className="mb-6 bg-gray-800 p-4 rounded-lg">
          <div className="flex flex-wrap gap-4 items-end">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Start Date</label>
              <input
                type="date"
                value={dateRange.startDate}
                onChange={(e) => handleDateRangeChange('startDate', e.target.value)}
                className="bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">End Date</label>
              <input
                type="date"
                value={dateRange.endDate}
                onChange={(e) => handleDateRangeChange('endDate', e.target.value)}
                className="bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm"
              />
            </div>
          </div>
        </div>

        {/* Summary Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-8">
          <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
            <h3 className="text-sm font-medium text-gray-400 mb-1">Total Sessions</h3>
            <p className="text-2xl font-bold text-orange-500">{analytics.stats.totalSessions}</p>
          </div>
          
          <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
            <h3 className="text-sm font-medium text-gray-400 mb-1">Page Views</h3>
            <p className="text-2xl font-bold text-blue-500">{analytics.stats.totalPageViews}</p>
          </div>
          
          <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
            <h3 className="text-sm font-medium text-gray-400 mb-1">Unique Visitors</h3>
            <p className="text-2xl font-bold text-green-500">{analytics.stats.uniqueVisitors}</p>
          </div>
          
          <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
            <h3 className="text-sm font-medium text-gray-400 mb-1">Avg Pages/Session</h3>
            <p className="text-2xl font-bold text-purple-500">{analytics.stats.avgPagesPerSession?.toFixed(1)}</p>
          </div>
          
          <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
            <h3 className="text-sm font-medium text-gray-400 mb-1">Avg Duration</h3>
            <p className="text-2xl font-bold text-yellow-500">{formatDuration(analytics.stats.avgSessionDuration)}</p>
          </div>
          
          <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
            <h3 className="text-sm font-medium text-gray-400 mb-1">Bounce Rate</h3>
            <p className="text-2xl font-bold text-red-500">{analytics.stats.bounceRate?.toFixed(1)}%</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Active Sessions */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h2 className="text-xl font-semibold text-orange-500 mb-4">
              Active Sessions ({activeSessions.length})
            </h2>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {activeSessions.length === 0 ? (
                <p className="text-gray-400 text-center py-4">No active sessions</p>
              ) : (
                activeSessions.map((session) => (
                  <div key={session.sessionId} className="bg-gray-700 p-3 rounded border border-gray-600">
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-sm font-medium text-white">{session.ipAddress}</span>
                      <span className="text-xs text-gray-400">
                        {formatDuration((new Date() - new Date(session.startTime)) / (1000 * 60))}
                      </span>
                    </div>
                    <div className="text-xs text-gray-400">
                      <span>{session.device} • {session.browser?.name} • {session.totalPages} pages</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Popular Pages */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h2 className="text-xl font-semibold text-orange-500 mb-4">Popular Pages</h2>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {popularPages.map((page, index) => (
                <div key={page._id} className="flex items-center justify-between p-2 bg-gray-700 rounded">
                  <div className="flex items-center gap-3">
                    <span className="text-orange-500 font-semibold text-sm">#{index + 1}</span>
                    <span className="text-white text-sm">{page._id}</span>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-white">{page.visits} visits</div>
                    <div className="text-xs text-gray-400">{page.uniqueVisitors} unique</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Device Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Devices */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h2 className="text-xl font-semibold text-orange-500 mb-4">Devices</h2>
            <div className="space-y-2">
              {deviceStats.devices.map((device) => (
                <div key={device._id} className="flex justify-between items-center">
                  <span className="text-white capitalize">{device._id}</span>
                  <span className="text-gray-400">{device.count}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Browsers */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h2 className="text-xl font-semibold text-orange-500 mb-4">Browsers</h2>
            <div className="space-y-2">
              {deviceStats.browsers.map((browser) => (
                <div key={browser._id} className="flex justify-between items-center">
                  <span className="text-white">{browser._id}</span>
                  <span className="text-gray-400">{browser.count}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Operating Systems */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h2 className="text-xl font-semibold text-orange-500 mb-4">Operating Systems</h2>
            <div className="space-y-2">
              {deviceStats.operatingSystems.map((os) => (
                <div key={os._id} className="flex justify-between items-center">
                  <span className="text-white">{os._id}</span>
                  <span className="text-gray-400">{os.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent Sessions */}
        <div className="bg-gray-800 rounded-lg border border-gray-700">
          <div className="p-6 border-b border-gray-700">
            <h2 className="text-xl font-semibold text-orange-500">Recent Sessions</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-700">
                <tr>
                  <th className="px-4 py-3 text-left">IP Address</th>
                  <th className="px-4 py-3 text-left">Device</th>
                  <th className="px-4 py-3 text-left">Browser</th>
                  <th className="px-4 py-3 text-left">Pages</th>
                  <th className="px-4 py-3 text-left">Duration</th>
                  <th className="px-4 py-3 text-left">Start Time</th>
                  <th className="px-4 py-3 text-left">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {analytics.sessions.map((session) => (
                  <tr key={session.sessionId} className="hover:bg-gray-700/50">
                    <td className="px-4 py-3 font-mono text-xs">{session.ipAddress}</td>
                    <td className="px-4 py-3 capitalize">{session.device}</td>
                    <td className="px-4 py-3">{session.browser?.name} {session.browser?.version}</td>
                    <td className="px-4 py-3">{session.totalPages}</td>
                    <td className="px-4 py-3">{formatDuration(session.duration)}</td>
                    <td className="px-4 py-3">{new Date(session.startTime).toLocaleString()}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        session.isActive 
                          ? 'bg-green-900/30 text-green-400' 
                          : 'bg-gray-700 text-gray-300'
                      }`}>
                        {session.isActive ? 'Active' : 'Ended'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {analytics.sessions.length === 0 && (
            <div className="p-8 text-center text-gray-400">
              <div className="mx-auto text-4xl mb-4">📊</div>
              <p>No sessions found for the selected date range</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SessionAnalytics;