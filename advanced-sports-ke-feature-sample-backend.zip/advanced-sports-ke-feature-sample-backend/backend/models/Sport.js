import mongoose from 'mongoose';

const sportSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Sport name is required'],
    unique: true,
    lowercase: true,
    trim: true,
  },
  
  displayName: {
    type: String,
    required: [true, 'Display name is required'],
    trim: true,
  },
  
  description: {
    type: String,
    required: [true, 'Sport description is required'],
    maxlength: 1000,
  },
  
  basePrice: {
    type: Number,
    required: [true, 'Base price is required'],
    min: 0,
    default: 20,
  },
  
  duration: {
    type: Number, // in minutes
    required: true,
    default: 60,
  },
  
  maxParticipants: {
    type: Number,
    default: 1,
    min: 1,
  },
  
  equipment: [{
    name: String,
    price: Number,
    description: String,
    available: {
      type: Boolean,
      default: true,
    },
  }],
  
  facilities: [{
    name: String,
    price: Number,
    description: String,
    capacity: Number,
    available: {
      type: Boolean,
      default: true,
    },
  }],
  
  operatingHours: {
    weekdays: {
      start: {
        type: String,
        default: '06:00',
      },
      end: {
        type: String,
        default: '22:00',
      },
    },
    weekends: {
      start: {
        type: String,
        default: '07:00',
      },
      end: {
        type: String,
        default: '21:00',
      },
    },
  },
  
  rules: [{
    type: String,
  }],
  
  images: [{
    url: String,
    caption: String,
  }],
  
  isActive: {
    type: Boolean,
    default: true,
  },
  
  popularityScore: {
    type: Number,
    default: 0,
  },
  
  totalBookings: {
    type: Number,
    default: 0,
  },
  
  averageRating: {
    type: Number,
    default: 0,
    min: 0,
    max: 5,
  },
  
  createdAt: {
    type: Date,
    default: Date.now,
  },
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

// Indexes
sportSchema.index({ name: 1, isActive: 1 });
sportSchema.index({ popularityScore: -1 });
sportSchema.index({ averageRating: -1 });

// Virtual for formatted price
sportSchema.virtual('formattedPrice').get(function() {
  return `$${this.basePrice}/hour`;
});

// Virtual for availability status
sportSchema.virtual('isAvailable').get(function() {
  return this.isActive;
});

// Static method to find active sports
sportSchema.statics.findActive = function() {
  return this.find({ isActive: true }).sort({ popularityScore: -1, name: 1 });
};

// Static method to find popular sports
sportSchema.statics.findPopular = function(limit = 5) {
  return this.find({ isActive: true })
    .sort({ popularityScore: -1, totalBookings: -1 })
    .limit(limit);
};

// Instance method to increment booking count
sportSchema.methods.incrementBooking = function() {
  this.totalBookings += 1;
  this.popularityScore += 1;
  return this.save();
};

// Instance method to update rating
sportSchema.methods.updateRating = function(newRating) {
  // This would typically be calculated from all reviews/ratings
  // For now, we'll use a simple average update
  this.averageRating = ((this.averageRating * this.totalBookings) + newRating) / (this.totalBookings + 1);
  return this.save();
};

// Pre-save middleware
sportSchema.pre('save', function(next) {
  // Ensure display name is properly capitalized if not provided
  if (!this.displayName && this.name) {
    this.displayName = this.name.charAt(0).toUpperCase() + this.name.slice(1);
  }
  next();
});

const Sport = mongoose.model('Sport', sportSchema);

export default Sport;