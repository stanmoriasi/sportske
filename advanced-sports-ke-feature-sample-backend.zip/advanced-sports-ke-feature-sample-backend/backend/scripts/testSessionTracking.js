/**
 * Test script to verify session tracking functionality
 */

import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:5000';

async function testSessionTracking() {
  console.log('🧪 Testing Session Tracking System...\n');

  try {
    // Test 1: Make a request to trigger session creation
    console.log('📡 Test 1: Creating session...');
    const response1 = await fetch(`${BASE_URL}/health`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    const cookies = response1.headers.get('set-cookie');
    console.log('✅ Session cookie received:', cookies ? 'Yes' : 'No');

    // Extract session ID from cookie
    let sessionId = null;
    if (cookies) {
      const sessionCookie = cookies.split(';')[0];
      sessionId = sessionCookie.split('=')[1];
      console.log('🔑 Session ID:', sessionId);
    }

    // Test 2: Check analytics endpoints
    console.log('\n📊 Test 2: Checking analytics endpoints...');
    
    const analyticsResponse = await fetch(`${BASE_URL}/api/analytics/sessions`);
    if (analyticsResponse.ok) {
      const analyticsData = await analyticsResponse.json();
      console.log('✅ Analytics endpoint working');
      console.log('📈 Total sessions:', analyticsData.data.stats.totalSessions);
    } else {
      console.log('❌ Analytics endpoint failed');
    }

    // Test 3: Check active sessions
    console.log('\n👥 Test 3: Checking active sessions...');
    const activeResponse = await fetch(`${BASE_URL}/api/analytics/active-sessions`);
    if (activeResponse.ok) {
      const activeData = await activeResponse.json();
      console.log('✅ Active sessions endpoint working');
      console.log('🟢 Active sessions count:', activeData.data.count);
    } else {
      console.log('❌ Active sessions endpoint failed');
    }

    // Test 4: Make multiple requests to simulate user journey
    console.log('\n🎯 Test 4: Simulating user journey...');
    const pages = ['/api', '/health', '/api/coaches'];
    
    for (const page of pages) {
      const pageResponse = await fetch(`${BASE_URL}${page}`, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Cookie': cookies || ''
        }
      });
      console.log(`📄 Visited ${page}:`, pageResponse.ok ? '✅' : '❌');
    }

    // Test 5: Check session details if we have a session ID
    if (sessionId) {
      console.log('\n🔍 Test 5: Checking session details...');
      const sessionResponse = await fetch(`${BASE_URL}/api/analytics/sessions/${sessionId}`);
      if (sessionResponse.ok) {
        const sessionData = await sessionResponse.json();
        console.log('✅ Session details retrieved');
        console.log('📊 Pages visited:', sessionData.data.totalPages);
        console.log('🕒 Session duration:', sessionData.data.duration, 'minutes');
      } else {
        console.log('❌ Session details failed');
      }
    }

    // Test 6: Check popular pages
    console.log('\n🏆 Test 6: Checking popular pages...');
    const popularResponse = await fetch(`${BASE_URL}/api/analytics/popular-pages`);
    if (popularResponse.ok) {
      const popularData = await popularResponse.json();
      console.log('✅ Popular pages endpoint working');
      console.log('📋 Popular pages count:', popularData.data.length);
    } else {
      console.log('❌ Popular pages endpoint failed');
    }

    console.log('\n🎉 Session tracking test completed!');

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

// Run the test
if (import.meta.url === `file://${process.argv[1]}`) {
  testSessionTracking();
}