import { useState, useEffect, useRef } from "react";
import banner from "../assets/banner.png";
import banner2 from "../assets/banner2.jpg";
import banner3 from "../assets/banner3.jpg";
import banner4 from "../assets/banner4.png";
import banner5 from "../assets/banner5.png";
import banner6 from "../assets/banner6.jpg";
import banner7 from "../assets/banner7.jpg";
import banner8 from "../assets/banner8.jpg";
import banner9 from "../assets/banner9.png";
import banner10 from "../assets/banner10.jpg";
import { GoShieldCheck, GoArrowUpRight, GoArrowDown } from "react-icons/go";
import {
  BsBuildingCheck,
  BsPersonFillCheck,
  BsDot,
  BsPerson,
} from "react-icons/bs";
import { GrSchedules } from "react-icons/gr";
import { BiMinus, BiPlus } from "react-icons/bi";

const useIntersectionObserver = (options = {}) => {
  const [isIntersecting, setIsIntersecting] = useState(false);
  const [hasTriggered, setHasTriggered] = useState(false);
  const ref = useRef(null);
  const lastScrollY = useRef(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        const currentScrollY = window.scrollY;
        const isScrollingDown = currentScrollY > lastScrollY.current;

        if (entry.isIntersecting && isScrollingDown && !hasTriggered) {
          setIsIntersecting(true);
          setHasTriggered(true);
        }

        lastScrollY.current = currentScrollY;
      },
      { threshold: 0.1, ...options }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [hasTriggered]);

  return [ref, isIntersecting];
};

const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [faqExpanded, setFaqExpanded] = useState(null);
  const [showBookingConfirmation, setShowBookingConfirmation] = useState(false);
  const [bookingData, setBookingData] = useState(null);

  const [aboutRef, aboutInView] = useIntersectionObserver();
  const [benefitsRef, benefitsInView] = useIntersectionObserver();
  const [programsRef, programsInView] = useIntersectionObserver();
  const [testimonialsRef, testimonialsInView] = useIntersectionObserver();
  const [faqRef, faqInView] = useIntersectionObserver();
  const [ctaRef, ctaInView] = useIntersectionObserver();

  const homepageContent = [
    {
      image: banner,
      title: "From \n Zero to \n Hero",
      subtitle:
        "Get from beginner to pro with our expert training programs. Whether you're starting from scratch or looking to level up your skills, we've got you covered.",
    },
    {
      image: banner2,
      title: "Get \n Personalised \n Training",
      subtitle:
        "Professional coaching and state-of-the-art facilities at your fingertips. Take your training to the next level with our world-class resources.",
    },
    {
      image: banner3,
      title: "Join \n Our \n Community",
      subtitle:
        "Connect with athletes and achieve your goals with the support of our vibrant community. Share your journey, get inspired, and stay motivated every step of the way.",
    },
  ];

  const aboutUs = [
    {
      title: "Certified Trainers",
      description:
        "Our trainers are certified professionals with years of experience in the fitness industry. They are dedicated to helping you achieve your goals.",
      icon: GoShieldCheck,
    },
    {
      title: "State-of-the-Art Facilities",
      description:
        "We offer top-notch facilities equipped with the latest fitness technology to provide you with the best training experience.",
      icon: BsBuildingCheck,
    },
    {
      title: "Flexible Scheduling",
      description:
        "We understand that everyone has different commitments. That's why we offer flexible scheduling options to fit your busy lifestyle.",
      icon: GrSchedules,
    },
    {
      title: "Personalized Programs",
      description:
        "We create customized training programs tailored to your individual needs and goals, ensuring you get the most out of your workouts.",
      icon: BsPersonFillCheck,
    },
  ];

  const testimonials = [
    {
      name: "Stan Moriasi",
      game: "Tennis",
      feedback:
        "I've been training at this facility for six months and I've seen incredible results. The trainers are knowledgeable and supportive.",
    },
    {
      name: "Jack Miller",
      game: "Basketball",
      feedback:
        "The community here is amazing! I've met so many like-minded individuals who motivate me to push harder every day.",
    },
    {
      name: "Emily Wambui",
      game: "Tennis",
      feedback:
        "I've been a member for a year now, and the progress I've made is unbelievable. The trainers really care about your success.",
    },
  ];

  const faqs = [
    {
      question: "What types of training programs do you offer?",
      answer:
        "We offer a variety of training programs including personal training, group classes, and specialized workshops.",
    },
    {
      question: "How can I get started?",
      answer:
        "Getting started is easy! Simply sign up on our website and choose a training program that suits your needs.",
    },
    {
      question: "Do you offer online training?",
      answer:
        "Yes, we offer online training options for those who prefer to work out at home.",
    },
    {
      question: "What are your operating hours?",
      answer:
        "We are open from 5 AM to 11 PM on weekdays and 7 AM to 9 PM on weekends.",
    },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % homepageContent.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [homepageContent.length]);

  // Check for booking confirmation on component mount
  useEffect(() => {
    const shouldShowConfirmation = localStorage.getItem('showBookingConfirmation');
    const backendBooking = localStorage.getItem('bookingConfirmation');
    
    if (shouldShowConfirmation === 'true' || backendBooking) {
      let booking = null;
      
      // Try to get booking from backend confirmation first
      if (backendBooking) {
        try {
          booking = JSON.parse(backendBooking);
          setBookingData(booking);
          setShowBookingConfirmation(true);
          // Clear the backend booking confirmation
          localStorage.removeItem('bookingConfirmation');
        } catch (error) {
          console.error('Error parsing backend booking data:', error);
        }
      }
      // Fallback to old localStorage format if no backend booking
      else if (shouldShowConfirmation === 'true') {
        const savedBooking = localStorage.getItem('sportsBookingData');
        if (savedBooking) {
          try {
            booking = JSON.parse(savedBooking);
            setBookingData(booking);
            setShowBookingConfirmation(true);
          } catch (error) {
            console.error('Error parsing booking data:', error);
          }
        }
      }
      
      // Clear the flag so it doesn't show again on refresh
      localStorage.removeItem('showBookingConfirmation');
    }
  }, []);

  const closeBookingConfirmation = () => {
    setShowBookingConfirmation(false);
    setBookingData(null);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (timeString) => {
    const [hours, minutes] = timeString.split(':');
    const date = new Date();
    date.setHours(parseInt(hours), parseInt(minutes));
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <>
      {/* Booking Confirmation Modal */}
      {showBookingConfirmation && bookingData && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              {/* Success Header */}
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Booking Confirmed!</h2>
                <p className="text-gray-600">Your session has been successfully booked</p>
              </div>

              {/* Booking Details */}
              <div className="space-y-4 mb-6">
                {/* Customer Information */}
                {bookingData.customerInfo && (
                  <div className="bg-blue-50 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-3">Customer Information</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Name:</span>
                        <span className="font-medium text-gray-900">{bookingData.customerInfo.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Email:</span>
                        <span className="font-medium text-gray-900">{bookingData.customerInfo.email}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Phone:</span>
                        <span className="font-medium text-gray-900">{bookingData.customerInfo.phone}</span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">Booking Details</h3>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Confirmation ID:</span>
                      <span className="font-medium text-gray-900">{bookingData.confirmationId || 'N/A'}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-600">Sport:</span>
                      <span className="font-medium text-gray-900 capitalize">{bookingData.sport}</span>
                    </div>
                    
                    {(bookingData.dateTime?.date || bookingData.formattedDate) && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Date:</span>
                        <span className="font-medium text-gray-900">
                          {bookingData.formattedDate || formatDate(bookingData.dateTime.date)}
                        </span>
                      </div>
                    )}
                    
                    {(bookingData.dateTime?.time || bookingData.formattedTime) && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Time:</span>
                        <span className="font-medium text-gray-900">
                          {bookingData.formattedTime || formatTime(bookingData.dateTime.time)}
                        </span>
                      </div>
                    )}
                    
                    {bookingData.pricing?.totalCost && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Cost:</span>
                        <span className="font-medium text-gray-900 text-lg font-bold text-green-600">${bookingData.pricing.totalCost}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Tennis-specific details */}
                {bookingData.sport === 'tennis' && (bookingData.tennis || bookingData.selectedCoachData) && (
                  <div className="bg-orange-50 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-3">Tennis Details</h3>
                    
                    {(bookingData.tennis?.coach || bookingData.selectedCoachData) && (
                      <div className="mb-3">
                        <div className="flex justify-between items-start">
                          <span className="text-gray-600">Coach:</span>
                          <div className="text-right">
                            <div className="font-medium text-gray-900">
                              {bookingData.tennis?.coach?.name || bookingData.selectedCoachData?.name}
                            </div>
                            <div className="text-sm text-gray-500">
                              {bookingData.tennis?.coach?.specialty || bookingData.selectedCoachData?.specialty}
                            </div>
                            <div className="text-sm text-orange-600">
                              {bookingData.tennis?.coach?.rate || bookingData.selectedCoachData?.rate}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {(bookingData.tennis?.extras?.rackets > 0 || bookingData.tennis?.extras?.courts > 0) && (
                      <div>
                        <div className="text-gray-600 mb-2">Equipment & Facilities:</div>
                        <div className="space-y-1">
                          {bookingData.tennis.extras.rackets > 0 && (
                            <div className="flex justify-between text-sm">
                              <span>Tennis Rackets ({bookingData.tennis.extras.rackets})</span>
                              <span>${bookingData.tennis.extras.rackets * 5}</span>
                            </div>
                          )}
                          {bookingData.tennis.extras.courts > 0 && (
                            <div className="flex justify-between text-sm">
                              <span>Tennis Courts ({bookingData.tennis.extras.courts})</span>
                              <span>${bookingData.tennis.extras.courts * 15}</span>
                            </div>
                          )}
                          <div className="border-t pt-1 mt-2 flex justify-between font-medium">
                            <span>Extras Total:</span>
                            <span className="text-orange-600">${bookingData.tennis.totalExtrasCost}</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {(!bookingData.tennis?.extras?.rackets && !bookingData.tennis?.extras?.courts) && (
                      <div className="text-sm text-gray-500 italic">
                        No additional equipment or facilities selected
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={closeBookingConfirmation}
                  className="flex-1 bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-300"
                >
                  Continue
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <section className="w-full bg-black h-screen relative overflow-hidden">
        {homepageContent.map((slide, index) => {
          const isActive = index === currentSlide;
          return (
            <div
              key={index}
              className={`absolute border inset-0 bg-center bg-cover transition-opacity duration-700 ease-in-out ${
                isActive
                  ? "opacity-100 pointer-events-auto"
                  : "opacity-0 pointer-events-none"
              }`}
              style={{ backgroundImage: `url(${slide.image})` }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-black/90 via-black/50 to-black/40" />

              <div className="h-full mx-[75px] max-w-[90%] md:max-w-2xl text-white flex flex-col items-start justify-center text-left">
                <h1
                  className={`text-[40px] md:text-[60px] lg:text-[80px] leading-[0.9] h-[116px] lg:h-[216px] max-w-1/2 transition-all duration-700 text-lato-bold flex items-center origin-left ${
                    isActive
                      ? "opacity-100 translate-x-0"
                      : "opacity-0 -translate-x-8"
                  }`}
                >
                  {slide.title}
                </h1>
                <p
                  className={`mt-3 text-nunito md:mt-4 text-base md:text-xl leading-relaxed h-[72px] text-white/90 transition-all duration-700 delay-150 overflow-hidden origin-left ${
                    isActive
                      ? "opacity-100 translate-x-0"
                      : "opacity-0 -translate-x-8"
                  }`}
                >
                  {slide.subtitle}
                </p>

                <button className="mt-6 rounded-full z-1 text-white px-6 py-3 bg-[#d4af37] hover:bg-[#d4af37aa] transition-colors duration-300">
                  Explore Now
                  <span>
                    <GoArrowDown className="inline-block ml-2" size={20} />
                  </span>
                </button>

                <div className="mt-6 flex items-center gap-2 z-1">
                  {homepageContent.map((_, i) => {
                    const dotActive = i === currentSlide;
                    return (
                      <button
                        key={i*1.1}
                        aria-label={`Go to slide ${i + 1}`}
                        aria-current={dotActive}
                        onClick={() => setCurrentSlide(i)}
                        className={`h-1 rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-white/80 w-6 ${
                          dotActive ? "bg-[#d4af37]" : "bg-white/40"
                        }`}
                      />
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </section>
      <section
        ref={aboutRef}
        className="flex flex-col lg:flex-row px-4 sm:px-8 lg:px-[75px] py-12 gap-8 lg:gap-30"
      >
        <div
          className={`flex flex-col items-start justify-start transition-all duration-700 ${
            aboutInView
              ? "opacity-100 translate-x-0"
              : "opacity-0 -translate-x-8"
          }`}
        >
          <h2 className="text-[#d4af37] text-lato text-sm sm:text-base">
            <BsDot className="inline-block -mr-3" size={28} /> About Us
          </h2>
          <p className="text-2xl sm:text-3xl">
            <span className="text-quicksand">Our</span>{" "}
            <span className="text-quicksand-light">Legacy</span>{" "}
            <span className="text-quicksand">in</span>{" "}
            <span className="text-quicksand-light">Training</span>
          </p>
          <p className="text-gray-600 text-nunito max-w-full lg:max-w-[70vw] mt-4 text-sm sm:text-base">
            We help you become the best version of yourself. With tailored
            programs and expert guidance, you'll unlock your full potential. Our
            community is here to support you every step of the way. With over 10
            years of experience, we have the knowledge and expertise to help you
            succeed.
          </p>
          <button className="text mt-4 border rounded-full text-primary px-4 py-2 hover:bg-primary/90 transition-colors duration-300 text-sm sm:text-base">
            Read More
            <span>
              <GoArrowUpRight className="inline-block ml-2" size={20} />
            </span>
          </button>
        </div>
        <div
          className={`w-full hidden md:flex justify-center justify-start transition-all duration-700 delay-200 ${
            aboutInView
              ? "opacity-100 translate-x-0"
              : "opacity-0 translate-x-8"
          }`}
        >
          <div className="relative">
            <div
              className="w-[280px] sm:w-[320px] lg:w-[25vw] aspect-[1/1] bg-cover relative rounded-4xl"
              style={{ backgroundImage: `url('${banner7}')` }}
            >
              <div
                className="w-[180px] sm:w-[200px] lg:w-[16vw] aspect-[4/5] bg-cover rounded-4xl absolute bottom-0 -right-[120px] sm:-right-[140px] lg:-right-[9.5vw]"
                style={{ backgroundImage: `url('${banner6}')` }}
              />
            </div>
          </div>
        </div>
      </section>
      <section
        ref={benefitsRef}
        className="flex flex-col lg:flex-row px-4 sm:px-8 lg:px-[75px] gap-8 lg:gap-10 bg-[#d9d9d94d] py-12"
      >
        <div
          className={`grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 lg:mb-12 justify-center transition-all duration-700 ${
            benefitsInView
              ? "opacity-100 translate-y-0"
              : "opacity-0 translate-y-8"
          }`}
        >
          {aboutUs.map((service, index) => (
            <div
              key={index*1.2}
              className={`p-4 bg-[#d9d9d980] rounded-lg flex flex-col items-center justify-center transition-all duration-700 ${
                benefitsInView
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="bg-white w-10 h-10 text-primary bg-white rounded-full p-2 flex flex-col items-center justify-center mb-2">
                <service.icon className="w-12 h-12" />
              </div>

              <h3 className="text-sm sm:text-md font-semibold text-center">
                {service.title}
              </h3>
              <p className="text-gray-600 text-xs sm:text-sm lg:max-w-[20vw] text-center">
                {service.description}
              </p>
            </div>
          ))}
        </div>
        <div
          className={`flex flex-col items-start justify-start transition-all duration-700 delay-300 ${
            benefitsInView
              ? "opacity-100 translate-x-0"
              : "opacity-0 translate-x-8"
          }`}
        >
          <h2 className="text-[#d4af37] text-lato text-sm sm:text-base">
            <BsDot className="inline-block -mr-3" size={28} /> Benefits
          </h2>
          <p className="text-2xl sm:text-3xl">
            <span className="text-quicksand">Why</span>{" "}
            <span className="text-quicksand-light">Choose</span>{" "}
            <span className="text-quicksand">Us</span>{" "}
          </p>
          <p className="text-gray-600 text-nunito max-w-full lg:max-w-[70vw] mt-4 text-sm sm:text-base">
            We help you become the best version of yourself. With tailored
            programs and expert guidance, you'll unlock your full potential. Our
            community is here to support you every step of the way. With over 10
            years of experience, we have the knowledge and expertise to help you
            succeed.
          </p>
        </div>
      </section>
      <section ref={programsRef} className="px-4 sm:px-8 lg:px-[75px] py-12">
        <div
          className={`flex flex-col items-center justify-start pb-8 lg:pb-14 transition-all duration-700 ${
            programsInView
              ? "opacity-100 translate-y-0"
              : "opacity-0 -translate-y-8"
          }`}
        >
          <h2 className="text-[#d4af37] text-lato text-sm sm:text-base">
            <BsDot className="inline-block -mr-3" size={28} /> Programs
          </h2>
          <p className="text-2xl sm:text-3xl text-center">
            <span className="text-quicksand">Training</span>{" "}
            <span className="text-quicksand-light">Programs</span>{" "}
          </p>
          <p className="text-gray-600 text-nunito max-w-full lg:max-w-[70vw] mt-4 text-center text-sm sm:text-base">
            We offer a variety of training programs to suit your needs. From
            personalized coaching to group classes, we have something for
            everyone.
          </p>
        </div>
        <div className="flex flex-col lg:flex-row gap-6 lg:gap-10 justify-between py-6">
          <div
            className={`w-full lg:w-[30vw] transition-all duration-700 ${
              programsInView
                ? "opacity-100 translate-y-0"
                : "opacity-0 translate-y-8"
            }`}
          >
            <div
              className="rounded-xl aspect-[7/8] bg-cover"
              style={{ backgroundImage: `url('${banner8}')` }}
            />
            <div className="flex items-start pt-6">
              <div className="flex flex-col items-start gap-2 flex-1">
                <p className="text-quicksand-bold text-xl sm:text-2xl">
                  Beginners
                </p>
                <p className="text-nunito text-xs sm:text-sm">
                  This program is tailored for those who are just getting
                  started out.
                </p>
              </div>
              <button className="rounded-full bg-primary p-2 flex items-center justify-center ml-4">
                <GoArrowUpRight color="white" size={20} />
              </button>
            </div>
          </div>
          <div
            className={`w-full lg:w-[30vw] lg:pt-12 transition-all duration-700 delay-200 ${
              programsInView
                ? "opacity-100 translate-y-0"
                : "opacity-0 translate-y-8"
            }`}
          >
            <div
              className="rounded-xl aspect-[7/8] bg-cover"
              style={{ backgroundImage: `url('${banner9}')` }}
            />
            <div className="flex items-start pt-6">
              <div className="flex flex-col items-start gap-2 flex-1">
                <p className="text-quicksand-bold text-xl sm:text-2xl">
                  Intermediate
                </p>
                <p className="text-nunito text-xs sm:text-sm">
                  This program is tailored for those who are looking to take
                  their skills to the next level.
                </p>
              </div>
              <button className="rounded-full bg-primary p-2 flex items-center justify-center ml-4">
                <GoArrowUpRight color="white" size={20} />
              </button>
            </div>
          </div>
          <div
            className={`w-full lg:w-[30vw] transition-all duration-700 delay-400 ${
              programsInView
                ? "opacity-100 translate-y-0"
                : "opacity-0 translate-y-8"
            }`}
          >
            <div
              className="rounded-xl aspect-[7/8] bg-cover"
              style={{ backgroundImage: `url('${banner10}')` }}
            />
            <div className="flex items-start pt-6">
              <div className="flex flex-col items-start gap-2 flex-1">
                <p className="text-quicksand-bold text-xl sm:text-2xl">
                  Advanced
                </p>
                <p className="text-nunito text-xs sm:text-sm">
                  This program is tailored for those who are looking to take
                  their skills to the next level.
                </p>
              </div>
              <button className="rounded-full bg-primary p-2 flex items-center justify-center ml-4">
                <GoArrowUpRight color="white" size={20} />
              </button>
            </div>
          </div>
        </div>
      </section>
      <section
        ref={testimonialsRef}
        className="px-4 sm:px-8 lg:px-[75px] bg-[#d9d9d94d] py-12"
      >
        <div
          className={`flex flex-col items-center justify-start pb-8 lg:pb-14 transition-all duration-700 ${
            testimonialsInView
              ? "opacity-100 translate-y-0"
              : "opacity-0 -translate-y-8"
          }`}
        >
          <h2 className="text-[#d4af37] text-lato text-sm sm:text-base">
            <BsDot className="inline-block -mr-3" size={28} /> Testimonials
          </h2>
          <p className="text-2xl sm:text-3xl text-center">
            <span className="text-quicksand">What</span>{" "}
            <span className="text-quicksand-light">Our</span>{" "}
            <span className="text-quicksand">Clients</span>{" "}
            <span className="text-quicksand-light">Say</span>
          </p>
          <p className="text-gray-600 text-nunito max-w-full lg:max-w-[70vw] mt-4 text-center text-sm sm:text-base">
            Hear from our satisfied clients who have transformed their skills
            and achieved their goals with our training programs.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 mb-8 lg:mb-12 justify-center">
          {testimonials.map((testimonial, index) => (
            <div
              key={index * 1.3}
              className={`p-6 bg-[#d9d9d980] rounded-lg flex flex-col items-center justify-center transition-all duration-700 ${
                testimonialsInView
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <BsPerson className="w-10 h-10 text-primary bg-white rounded-full p-2 mb-2" />
              <h3 className="text-sm sm:text-md font-semibold text-center">
                {testimonial.name} - {testimonial.game}
              </h3>
              <p className="text-gray-600 text-xs sm:text-sm text-center mt-2">
                {testimonial.feedback}
              </p>
            </div>
          ))}
        </div>
      </section>
      <section ref={faqRef} className="px-4 sm:px-8 lg:px-[75px] py-12">
        <div
          className={`flex flex-col items-center justify-start pb-8 lg:pb-14 transition-all duration-700 ${
            faqInView ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-8"
          }`}
        >
          <h2 className="text-[#d4af37] text-lato text-sm sm:text-base">
            <BsDot className="inline-block -mr-3" size={28} /> FAQs
          </h2>
          <p className="text-2xl sm:text-3xl text-center">
            <span className="text-quicksand">Frequently</span>{" "}
            <span className="text-quicksand-light">Asked</span>{" "}
            <span className="text-quicksand">Questions</span>{" "}
          </p>
          <p className="text-gray-600 text-nunito max-w-full lg:max-w-[70vw] mt-4 text-center text-sm sm:text-base">
            Find answers to the most common questions about our training
            programs and services.
          </p>
        </div>
        <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
          <div
            className={`flex-shrink-0 w-full lg:w-auto transition-all duration-700 ${
              faqInView
                ? "opacity-100 translate-x-0"
                : "opacity-0 -translate-x-8"
            }`}
          >
            <div
              className="rounded-xl w-full lg:w-[400px] xl:w-[450px] 2xl:w-[500px] aspect-[4/5] lg:h-[380px] xl:h-[540px] 2xl:h-[450px] bg-cover bg-center"
              style={{ backgroundImage: `url('${banner5}')` }}
            />
          </div>
          <div
            className={`space-y-4 flex-1 min-w-0 transition-all duration-700 delay-200 ${
              faqInView
                ? "opacity-100 translate-x-0"
                : "opacity-0 translate-x-8"
            }`}
          >
            {faqs.map((faq, index) => (
              <div
                key={index * 1.4}
                role="button"
                className={`bg-[#d9d9d980] rounded-xl p-4 cursor-pointer transition-all duration-500 ease-in-out ${
                  faqInView
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-4"
                }`}
                style={{ transitionDelay: `${300 + index * 100}ms` }}
                onClick={() =>
                  setFaqExpanded(faqExpanded === index ? null : index)
                }
              >
                <div className="flex justify-between items-center">
                  <h3 className="cursor-pointer text-sm sm:text-base text-lato-bold">
                    {faq.question}
                  </h3>
                  <p className="text-[#d4af37] text-2xl sm:text-3xl text-quicksand-light flex-shrink-0">
                    {faqExpanded === index ? <BiMinus /> : <BiPlus />}
                  </p>
                </div>
                {faqExpanded === index && (
                  <p className="border-t mt-2 border-[#00000024] py-4 text-sm text-nunito sm:text-base animate-in slide-in-from-top duration-200">
                    {faq.answer}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
      <section
        ref={ctaRef}
        className={`relative flex flex-col items-center justify-center py-8 sm:py-12 my-8 sm:my-12 min-h-[40vh] sm:h-[50vh] mx-4 sm:mx-8 lg:mx-[75px] rounded-4xl text-white gap-2 sm:gap-4 transition-all duration-700 bg-cover bg-center ${
          ctaInView ? "opacity-100 scale-100" : "opacity-0 scale-95"
        }`}
        style={{ backgroundImage: `url('${banner4}')` }}
      >
        <div className="inset-0 z-0 absolute bg-[#00000099] rounded-4xl" />
        <p
          className={`text-xl sm:text-2xl lg:text-3xl z-1 text-center px-4 transition-all duration-700 delay-200 ${
            ctaInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
          }`}
        >
          <span className="text-quicksand">Every</span>{" "}
          <span className="text-quicksand-light">Champion</span>{" "}
          <span className="text-quicksand">Was</span>{" "}
          <span className="text-quicksand-light">Once</span>{" "}
          <span className="text-quicksand">a</span>{" "}
          <span className="text-quicksand-light">Beginner</span>
        </p>
        <p
          className={`text-nunito max-w-[90%] sm:max-w-[70%] lg:max-w-[50vw] mt-2 sm:mt-4 z-1 text-center text-sm sm:text-base px-4 transition-all duration-700 delay-400 ${
            ctaInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
          }`}
        >
          Embrace the journey, and remember that every expert was once a
          beginner. Keep pushing your limits! We will patiently work with you to
          unlock your full potential.
        </p>
        <button
          className={`rounded-full px-4 py-2 z-1 mt-4 sm:mt-6 bg-primary text-white hover:bg-[#d4af37b9] transition-all duration-300 text-sm sm:text-base ${
            ctaInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
          }`} 
        >
          <span>Get Started Today</span>
          <GoArrowUpRight
            color="white"
            className="inline-block ml-1 sm:ml-2"
            size={20}
          />
        </button>
      </section>
    </>
  );
};

export default Home;
