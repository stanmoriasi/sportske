import express from 'express';
import mongoose from 'mongoose';
import Booking from '../models/Booking.js';
import Sport from '../models/Sport.js';
import Coach from '../models/Coach.js';
import User from '../models/User.js';
import { authenticateToken, requireAdmin } from './auth.js';

const router = express.Router();

// Apply authentication and admin middleware to all admin routes
router.use(authenticateToken);
router.use(requireAdmin);

// GET /api/admin/dashboard - Get dashboard statistics
router.get('/dashboard', async (req, res) => {
  try {
    // Get booking statistics
    const bookingStats = await Booking.aggregate([
      {
        $group: {
          _id: null,
          totalBookings: { $sum: 1 },
          confirmedBookings: {
            $sum: { $cond: [{ $eq: ['$status', 'confirmed'] }, 1, 0] }
          },
          pendingBookings: {
            $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] }
          },
          cancelledBookings: {
            $sum: { $cond: [{ $eq: ['$status', 'cancelled'] }, 1, 0] }
          },
          totalRevenue: { $sum: '$pricing.totalCost' },
        }
      }
    ]);

    // Get recent bookings
    const recentBookings = await Booking.find()
      .sort({ createdAt: -1 })
      .limit(10)
      .lean();

    // Get sport popularity
    const sportPopularity = await Booking.aggregate([
      {
        $group: {
          _id: '$sport',
          count: { $sum: 1 },
          revenue: { $sum: '$pricing.totalCost' },
        }
      },
      { $sort: { count: -1 } }
    ]);

    // Get monthly booking trends (last 6 months)
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const monthlyTrends = await Booking.aggregate([
      {
        $match: {
          createdAt: { $gte: sixMonthsAgo }
        }
      },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' }
          },
          bookings: { $sum: 1 },
          revenue: { $sum: '$pricing.totalCost' }
        }
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } }
    ]);

    // Get coach performance
    const coachPerformance = await Booking.aggregate([
      {
        $match: {
          'tennis.coach.id': { $exists: true }
        }
      },
      {
        $group: {
          _id: '$tennis.coach.id',
          coachName: { $first: '$tennis.coach.name' },
          bookings: { $sum: 1 },
          revenue: { $sum: '$pricing.totalCost' }
        }
      },
      { $sort: { bookings: -1 } },
      { $limit: 10 }
    ]);

    res.json({
      success: true,
      data: {
        overview: bookingStats[0] || {
          totalBookings: 0,
          confirmedBookings: 0,
          pendingBookings: 0,
          cancelledBookings: 0,
          totalRevenue: 0,
        },
        recentBookings,
        sportPopularity,
        monthlyTrends,
        coachPerformance,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching dashboard data',
      error: error.message,
    });
  }
});

// GET /api/admin/reports/bookings - Get detailed booking reports
router.get('/reports/bookings', async (req, res) => {
  try {
    const {
      startDate,
      endDate,
      sport,
      status,
      format = 'json'
    } = req.query;

    // Build filter
    const filter = {};
    if (startDate || endDate) {
      filter['dateTime.datetime'] = {};
      if (startDate) filter['dateTime.datetime'].$gte = new Date(startDate);
      if (endDate) filter['dateTime.datetime'].$lte = new Date(endDate);
    }
    if (sport) filter.sport = sport;
    if (status) filter.status = status;

    const bookings = await Booking.find(filter)
      .sort({ 'dateTime.datetime': -1 })
      .lean();

    // Generate summary statistics
    const summary = {
      totalBookings: bookings.length,
      totalRevenue: bookings.reduce((sum, booking) => sum + (booking.pricing?.totalCost || 0), 0),
      averageBookingValue: bookings.length > 0 
        ? bookings.reduce((sum, booking) => sum + (booking.pricing?.totalCost || 0), 0) / bookings.length
        : 0,
      statusBreakdown: bookings.reduce((acc, booking) => {
        acc[booking.status] = (acc[booking.status] || 0) + 1;
        return acc;
      }, {}),
      sportBreakdown: bookings.reduce((acc, booking) => {
        acc[booking.sport] = (acc[booking.sport] || 0) + 1;
        return acc;
      }, {})
    };

    res.json({
      success: true,
      data: {
        summary,
        bookings,
        filters: { startDate, endDate, sport, status },
        generatedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error generating booking report',
      error: error.message,
    });
  }
});

// GET /api/admin/system/health - System health check
router.get('/system/health', async (req, res) => {
  try {
    // Check database connectivity
    const dbStats = await Promise.all([
      Booking.countDocuments(),
      Sport.countDocuments(),
      Coach.countDocuments(),
    ]);

    const systemHealth = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      database: {
        connected: true,
        collections: {
          bookings: dbStats[0],
          sports: dbStats[1],
          coaches: dbStats[2],
        }
      },
      memory: {
        used: process.memoryUsage().heapUsed / 1024 / 1024, // MB
        total: process.memoryUsage().heapTotal / 1024 / 1024, // MB
      },
      uptime: process.uptime(), // seconds
    };

    res.json({
      success: true,
      data: systemHealth,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'System health check failed',
      error: error.message,
    });
  }
});

// GET /api/admin/users - Get all users for admin management
router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 20, search, role, status } = req.query;
    
    // Build filter
    const filter = {};
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }
    if (role && role !== 'all') {
      filter.role = role;
    }
    if (status && status !== 'all') {
      filter.isActive = status === 'active';
    }

    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await User.countDocuments(filter);
    const totalPages = Math.ceil(total / parseInt(limit));

    // Fetch users with pagination
    const users = await User.find(filter)
      .select('-password') // Exclude password field
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    // Add formatted fields
    const formattedUsers = users.map(user => ({
      ...user,
      id: user._id,
      formattedCreatedAt: new Date(user.createdAt).toLocaleDateString(),
      formattedLastLogin: user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : 'Never',
      statusText: user.isActive ? 'Active' : 'Inactive',
      roleText: user.role === 'admin' ? 'Administrator' : 'User'
    }));

    res.json({
      success: true,
      data: formattedUsers,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        total,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1,
        limit: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching users',
      error: error.message
    });
  }
});

// GET /api/admin/users/:id - Get specific user details
router.get('/users/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      data: user.toJSON()
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching user',
      error: error.message
    });
  }
});

// PATCH /api/admin/users/:id/role - Update user role
router.patch('/users/:id/role', async (req, res) => {
  try {
    const { role } = req.body;
    
    // Validate role
    if (!role || !['user', 'admin'].includes(role)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid role. Must be "user" or "admin"'
      });
    }

    // Prevent self-demotion from admin
    if (req.user.userId === req.params.id && role === 'user') {
      return res.status(400).json({
        success: false,
        message: 'Cannot change your own admin role'
      });
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Update user role and isAdmin flag
    user.role = role;
    user.isAdmin = role === 'admin';
    user.updatedAt = new Date();
    
    await user.save();

    res.json({
      success: true,
      message: `User role updated to ${role}`,
      data: user.toJSON()
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating user role',
      error: error.message
    });
  }
});

// PATCH /api/admin/users/:id/status - Update user status (active/inactive)
router.patch('/users/:id/status', async (req, res) => {
  try {
    const { isActive } = req.body;
    
    if (typeof isActive !== 'boolean') {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Must be true or false'
      });
    }

    // Prevent self-deactivation
    if (req.user.userId === req.params.id && !isActive) {
      return res.status(400).json({
        success: false,
        message: 'Cannot deactivate your own account'
      });
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    user.isActive = isActive;
    user.updatedAt = new Date();
    await user.save();

    res.json({
      success: true,
      message: `User ${isActive ? 'activated' : 'deactivated'} successfully`,
      data: user.toJSON()
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating user status',
      error: error.message
    });
  }
});

// DELETE /api/admin/users/:id - Delete user (soft delete by deactivation)
router.delete('/users/:id', async (req, res) => {
  try {
    // Prevent self-deletion
    if (req.user.userId === req.params.id) {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete your own account'
      });
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Soft delete by deactivating the user
    user.isActive = false;
    user.updatedAt = new Date();
    await user.save();

    res.json({
      success: true,
      message: 'User deleted (deactivated) successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting user',
      error: error.message
    });
  }
});

// DELETE /api/admin/coaches/:id - Delete coach and clean up references
router.delete('/coaches/:id', async (req, res) => {
  try {
    const coachId = req.params.id;
    
    // Check if coach exists
    const coach = await Coach.findById(coachId);
    if (!coach) {
      return res.status(404).json({
        success: false,
        message: 'Coach not found'
      });
    }

    // Count bookings that reference this coach
    const bookingCount = await Booking.countDocuments({ coachId: coachId });
    
    // Remove coach references from bookings first
    const bookingUpdate = await Booking.updateMany(
      { coachId: coachId },
      { 
        $unset: { coachId: 1 },
        $set: { updatedAt: new Date() }
      }
    );

    // Delete the coach
    await Coach.findByIdAndDelete(coachId);

    res.json({
      success: true,
      message: `Coach deleted successfully. Cleaned up ${bookingUpdate.modifiedCount} booking references.`,
      data: {
        deletedCoach: coach.name,
        cleanedBookings: bookingUpdate.modifiedCount,
        totalBookingsFound: bookingCount
      }
    });

  } catch (error) {
    console.error('Error deleting coach:', error);
    res.status(500).json({
      success: false,
      message: 'Error deleting coach',
      error: error.message
    });
  }
});

// POST /api/admin/cleanup/orphaned-coaches - Clean up orphaned coach references
router.post('/cleanup/orphaned-coaches', async (req, res) => {
  try {
    // Find all bookings with coachId references
    const bookingsWithCoaches = await Booking.find({ 
      coachId: { $exists: true, $ne: null } 
    }).select('coachId _id');

    if (bookingsWithCoaches.length === 0) {
      return res.json({
        success: true,
        message: 'No bookings with coach references found',
        data: { cleaned: 0, total: 0 }
      });
    }

    // Get all unique coach IDs from bookings
    const coachIds = [...new Set(bookingsWithCoaches.map(b => b.coachId.toString()))];
    
    // Check which coaches still exist
    const existingCoaches = await Coach.find({ 
      _id: { $in: coachIds.map(id => new mongoose.Types.ObjectId(id)) } 
    }).select('_id');
    
    const existingCoachIds = existingCoaches.map(c => c._id.toString());
    
    // Find orphaned coach references (coaches that don't exist anymore)
    const orphanedCoachIds = coachIds.filter(id => !existingCoachIds.includes(id));
    
    if (orphanedCoachIds.length === 0) {
      return res.json({
        success: true,
        message: 'No orphaned coach references found',
        data: { cleaned: 0, total: bookingsWithCoaches.length }
      });
    }

    // Remove orphaned coach references
    const result = await Booking.updateMany(
      { coachId: { $in: orphanedCoachIds.map(id => new mongoose.Types.ObjectId(id)) } },
      { 
        $unset: { coachId: 1 },
        $set: { updatedAt: new Date() }
      }
    );

    res.json({
      success: true,
      message: `Cleaned up ${result.modifiedCount} orphaned coach references`,
      data: {
        cleaned: result.modifiedCount,
        total: bookingsWithCoaches.length,
        orphanedCoachIds: orphanedCoachIds
      }
    });

  } catch (error) {
    console.error('Error cleaning up orphaned coaches:', error);
    res.status(500).json({
      success: false,
      message: 'Error cleaning up orphaned coach references',
      error: error.message
    });
  }
});

export default router;