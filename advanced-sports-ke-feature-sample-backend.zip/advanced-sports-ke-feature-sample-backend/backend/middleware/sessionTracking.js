import { v4 as uuidv4 } from 'uuid';
import UserSession from '../models/UserSession.js';

// Helper function to parse user agent
function parseUserAgent(userAgent) {
  const browser = {
    name: 'unknown',
    version: 'unknown',
    major: 'unknown'
  };
  
  const os = {
    name: 'unknown',
    version: 'unknown'
  };
  
  let device = 'unknown';
  
  // Parse browser
  if (userAgent.includes('Chrome')) {
    browser.name = 'Chrome';
    const match = userAgent.match(/Chrome\/(\d+)\.(\d+)/);
    if (match) {
      browser.major = match[1];
      browser.version = `${match[1]}.${match[2]}`;
    }
  } else if (userAgent.includes('Firefox')) {
    browser.name = 'Firefox';
    const match = userAgent.match(/Firefox\/(\d+)\.(\d+)/);
    if (match) {
      browser.major = match[1];
      browser.version = `${match[1]}.${match[2]}`;
    }
  } else if (userAgent.includes('Safari') && !userAgent.includes('Chrome')) {
    browser.name = 'Safari';
    const match = userAgent.match(/Version\/(\d+)\.(\d+)/);
    if (match) {
      browser.major = match[1];
      browser.version = `${match[1]}.${match[2]}`;
    }
  } else if (userAgent.includes('Edge')) {
    browser.name = 'Edge';
    const match = userAgent.match(/Edge\/(\d+)\.(\d+)/);
    if (match) {
      browser.major = match[1];
      browser.version = `${match[1]}.${match[2]}`;
    }
  }
  
  // Parse OS
  if (userAgent.includes('Windows NT')) {
    os.name = 'Windows';
    const match = userAgent.match(/Windows NT (\d+)\.(\d+)/);
    if (match) {
      const version = `${match[1]}.${match[2]}`;
      os.version = version;
      // Map Windows NT versions to user-friendly names
      switch (version) {
        case '10.0': os.name = 'Windows 10/11'; break;
        case '6.3': os.name = 'Windows 8.1'; break;
        case '6.2': os.name = 'Windows 8'; break;
        case '6.1': os.name = 'Windows 7'; break;
        default: os.name = `Windows ${version}`;
      }
    }
  } else if (userAgent.includes('Mac OS X')) {
    os.name = 'macOS';
    const match = userAgent.match(/Mac OS X (\d+)[._](\d+)/);
    if (match) {
      os.version = `${match[1]}.${match[2]}`;
    }
  } else if (userAgent.includes('Linux')) {
    os.name = 'Linux';
  } else if (userAgent.includes('Android')) {
    os.name = 'Android';
    const match = userAgent.match(/Android (\d+)\.(\d+)/);
    if (match) {
      os.version = `${match[1]}.${match[2]}`;
    }
  } else if (userAgent.includes('iOS') || userAgent.includes('iPhone') || userAgent.includes('iPad')) {
    os.name = 'iOS';
    const match = userAgent.match(/OS (\d+)[._](\d+)/);
    if (match) {
      os.version = `${match[1]}.${match[2]}`;
    }
  }
  
  // Determine device type
  if (userAgent.includes('Mobile') || userAgent.includes('iPhone') || userAgent.includes('Android')) {
    device = 'mobile';
  } else if (userAgent.includes('iPad') || userAgent.includes('Tablet')) {
    device = 'tablet';
  } else {
    device = 'desktop';
  }
  
  return { browser, os, device };
}

// Helper function to extract UTM parameters
function extractUtmParams(url) {
  const urlObj = new URL(url, 'http://localhost');
  return {
    utmSource: urlObj.searchParams.get('utm_source') || undefined,
    utmMedium: urlObj.searchParams.get('utm_medium') || undefined,
    utmCampaign: urlObj.searchParams.get('utm_campaign') || undefined,
    utmTerm: urlObj.searchParams.get('utm_term') || undefined,
    utmContent: urlObj.searchParams.get('utm_content') || undefined,
  };
}

// Helper function to get client IP
function getClientIP(req) {
  return req.headers['x-forwarded-for'] ||
         req.headers['x-real-ip'] ||
         req.connection?.remoteAddress ||
         req.socket?.remoteAddress ||
         req.connection?.socket?.remoteAddress ||
         req.ip ||
         'unknown';
}

// Session tracking middleware
export const sessionTracker = async (req, res, next) => {
  try {
    // Skip tracking for certain paths
    const skipPaths = ['/favicon.ico', '/robots.txt', '/sitemap.xml', '/api/health'];
    if (skipPaths.some(path => req.path.startsWith(path))) {
      return next();
    }
    
    // Skip tracking for static assets
    if (req.path.match(/\.(css|js|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$/)) {
      return next();
    }
    
    const sessionId = req.cookies.sessionId || uuidv4();
    const ipAddress = getClientIP(req);
    const userAgent = req.headers['user-agent'] || 'unknown';
    const currentPath = req.path;
    const method = req.method;
    const referrer = req.headers.referer || '';
    
    // Parse user agent
    const { browser, os, device } = parseUserAgent(userAgent);
    
    // Extract UTM parameters
    const utmParams = extractUtmParams(req.url);
    
    // Set session cookie if not exists
    if (!req.cookies.sessionId) {
      res.cookie('sessionId', sessionId, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        sameSite: 'lax'
      });
    }
    
    // Find existing session or create new one
    let session = await UserSession.findOne({ sessionId });
    
    if (!session) {
      // Create new session
      session = new UserSession({
        sessionId,
        ipAddress,
        userAgent,
        browser,
        os,
        device,
        startTime: new Date(),
        lastActivity: new Date(),
        isActive: true,
        pagesVisited: [],
        totalPages: 0,
        uniquePages: 0,
        ...utmParams
      });
    }
    
    // Add current page visit
    await session.addPageVisit(currentPath, method, referrer);
    
    // Attach session to request for use in other middleware/routes
    req.userSession = session;
    
    next();
  } catch (error) {
    console.error('Session tracking error:', error);
    // Don't fail the request if session tracking fails
    next();
  }
};

// Middleware to associate user with session (after login)
export const associateUserWithSession = async (req, res, next) => {
  try {
    if (req.user && req.userSession) {
      req.userSession.userId = req.user._id;
      req.userSession.userEmail = req.user.email;
      await req.userSession.save();
    }
    next();
  } catch (error) {
    console.error('User session association error:', error);
    next();
  }
};

// Middleware to end session (on logout or session timeout)
export const endSession = async (req, res, next) => {
  try {
    if (req.userSession && req.userSession.isActive) {
      await req.userSession.endSession();
    }
    
    // Clear session cookie
    res.clearCookie('sessionId');
    
    next();
  } catch (error) {
    console.error('End session error:', error);
    next();
  }
};

// Cleanup function to run periodically (can be used in a cron job)
export const cleanupSessions = async () => {
  try {
    const result = await UserSession.cleanupOldSessions();
    console.log(`Cleaned up ${result.modifiedCount} inactive sessions`);
    return result;
  } catch (error) {
    console.error('Session cleanup error:', error);
    throw error;
  }
};

export default sessionTracker;