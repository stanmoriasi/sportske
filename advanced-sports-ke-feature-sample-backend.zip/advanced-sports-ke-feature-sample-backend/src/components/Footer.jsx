import React from "react";
import logo from "../assets/logo.png";
import { Link } from "react-router";
import { BsFacebook, BsInstagram, BsTiktok } from "react-icons/bs";

const Footer = () => {
  return (
    <footer className="bg-black text-white pt-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-10 xl:px-[75px] space-y-8">
        <div className="flex flex-col gap-10 md:flex-row md:items-start md:justify-between">
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <img src={logo} alt="Logo" className="h-16 w-16 lg:h-24 lg:w-24" />
            <p className="mt-3 text-sm max-w-sm">
              Sports training you've never experienced before.
            </p>
            <ul className="flex gap-4 mt-4">
              <li>
                <a href="#" aria-label="Facebook">
                  <BsFacebook
                    size={24}
                    className="mt-1 text-primary hover:text-white cursor-pointer"
                  />
                </a>
              </li>
              <li>
                <a href="#" aria-label="Instagram">
                  <BsInstagram
                    size={24}
                    className="mt-1 text-primary hover:text-white cursor-pointer"
                  />
                </a>
              </li>
              <li>
                <a href="#" aria-label="TikTok">
                  <BsTiktok
                    size={24}
                    className="mt-1 text-primary hover:text-white cursor-pointer"
                  />
                </a>
              </li>
            </ul>
          </div>

          <div className="flex justify-center md:flex-1">
            <div className="flex flex-col space-y-2 items-center md:items-start text-center md:text-left">
              <h4 className="font-semibold mb-2">Quick Links</h4>
              <Link to="/about" className="text-sm hover:text-[#d4af37]">
                About Us
              </Link>
              <Link to="/careers" className="text-sm hover:text-[#d4af37]">
                Careers
              </Link>
              <Link to="/contact" className="text-sm hover:text-[#d4af37]">
                Contact
              </Link>
            </div>
          </div>

          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <h3 className="font-semibold">Contact</h3>
            <div className="flex flex-col space-y-1 mt-2">
              <p className="text-sm">
                Email:{" "}
                <a
                  href="mailto:advancedsports@gmail.com"
                  className="hover:text-[#d4af37]"
                >
                  advancedsports@gmail.com
                </a>
              </p>
              <p className="text-sm">
                Phone:{" "}
                <a href="tel:+254123456789" className="hover:text-[#d4af37]">
                  +254 123 456 789
                </a>
              </p>
              <p className="text-sm">
                Address: <span>UoN, Kenya Science, Ngong Rd</span>
              </p>
            </div>
          </div>
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-10 xl:px-[75px] text-center border-t border-white/10 py-6">
          <p className="text-xs sm:text-sm">
            &copy; {new Date().getFullYear()}{" "}
            <a href="http://boutechsolutions.com" rel="noopener noreferrer">
              Boutech Solutions
            </a>
            . All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
