# Advanced Sports Kenya - Backend API

A comprehensive backend service for managing sports facility bookings, built with Node.js, Express, and MongoDB.

## Features

- **Sports Management**: Multiple sports with facilities, equipment, and pricing
- **Booking System**: Complete booking workflow with validation and confirmations
- **Coach Management**: Tennis coaches with availability, ratings, and specializations
- **User Authentication**: JWT-based authentication with secure password handling
- **Email Notifications**: Automated booking confirmations and updates
- **Admin Panel**: Administrative functions for managing bookings and data
- **Rate Limiting**: API protection against abuse
- **Data Validation**: Comprehensive input validation using Joi
- **Security**: Helmet, CORS, and security best practices

## Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: JWT (JSON Web Tokens)
- **Validation**: Joi
- **Email**: Nodemailer
- **Security**: Helmet, CORS, express-rate-limit
- **Development**: Nodemon, ESLint
- **Testing**: Jest

## Project Structure

```
backend/
├── server.js                 # Main server entry point
├── package.json             # Dependencies and scripts
├── .env.example            # Environment variables template
├── models/                 # MongoDB schemas
│   ├── Booking.js         # Booking model
│   ├── Coach.js           # Coach model
│   ├── Sport.js           # Sport model
│   └── User.js            # User model
├── routes/                # API routes
│   ├── bookings.js        # Booking endpoints
│   ├── sports.js          # Sports endpoints
│   ├── coaches.js         # Coach endpoints
│   ├── users.js           # User endpoints
│   └── admin.js           # Admin endpoints
├── middleware/            # Custom middleware
│   ├── auth.js           # Authentication middleware
│   ├── validation.js     # Request validation
│   └── errorHandler.js   # Error handling
├── utils/                # Utility functions
│   ├── emailService.js   # Email functionality
│   └── logger.js         # Logging service
└── scripts/              # Database scripts
    └── seedDatabase.js   # Database seeding
```

## Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd advanced-sports-ke/backend
```

2. **Install dependencies**
```bash
npm install
```

3. **Environment Setup**
Create a `.env` file in the backend directory:
```env
# Database
MONGODB_URI=mongodb://localhost:27017/advanced-sports-ke

# JWT
JWT_SECRET=your-super-secret-jwt-key-here
JWT_EXPIRE=7d

# Email Configuration (Gmail example)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password

# Server
PORT=5000
NODE_ENV=development

# Admin
ADMIN_EMAIL=admin@advancedsports.ke
```

4. **Database Setup**
Make sure MongoDB is running, then seed the database:
```bash
npm run seed
```

5. **Start the server**
```bash
# Development
npm run dev

# Production
npm start
```

## API Endpoints

### Sports
- `GET /api/sports` - Get all sports
- `GET /api/sports/:id` - Get sport by ID
- `POST /api/sports` - Create new sport (Admin)
- `PUT /api/sports/:id` - Update sport (Admin)
- `DELETE /api/sports/:id` - Delete sport (Admin)

### Bookings
- `GET /api/bookings` - Get all bookings (Admin)
- `GET /api/bookings/user/:userId` - Get user bookings
- `GET /api/bookings/:id` - Get booking by ID
- `POST /api/bookings` - Create new booking
- `PUT /api/bookings/:id` - Update booking
- `DELETE /api/bookings/:id` - Cancel booking

### Coaches
- `GET /api/coaches` - Get all coaches
- `GET /api/coaches/sport/:sport` - Get coaches by sport
- `GET /api/coaches/:id` - Get coach by ID
- `POST /api/coaches` - Create new coach (Admin)
- `PUT /api/coaches/:id` - Update coach (Admin)
- `DELETE /api/coaches/:id` - Delete coach (Admin)

### Users
- `POST /api/users/register` - Register new user
- `POST /api/users/login` - User login
- `GET /api/users/profile` - Get user profile (Auth)
- `PUT /api/users/profile` - Update user profile (Auth)

### Admin
- `GET /api/admin/stats` - Get booking statistics
- `GET /api/admin/bookings` - Get all bookings with filters
- `PUT /api/admin/bookings/:id/status` - Update booking status

## Data Models

### Sport Model
```javascript
{
  name: String,           // Unique identifier
  displayName: String,    // Display name
  description: String,    // Description
  basePrice: Number,      // Base price
  duration: Number,       // Duration in minutes
  maxParticipants: Number,// Maximum participants
  equipment: [{           // Available equipment
    name: String,
    price: Number,
    description: String,
    available: Boolean
  }],
  facilities: [{          // Available facilities
    name: String,
    price: Number,
    description: String,
    capacity: Number,
    available: Boolean
  }],
  operatingHours: {       // Operating hours
    weekdays: { start: String, end: String },
    weekends: { start: String, end: String }
  },
  rules: [String],        // Sport-specific rules
  isActive: Boolean,      // Active status
  popularityScore: Number // Popularity ranking
}
```

### Booking Model
```javascript
{
  bookingId: String,      // Unique booking ID
  userId: String,         // User identifier
  customerInfo: {         // Customer details
    firstName: String,
    lastName: String,
    email: String,
    phone: String
  },
  sport: String,          // Sport name
  date: Date,            // Booking date
  time: String,          // Booking time
  duration: Number,      // Duration in minutes
  participants: Number,  // Number of participants
  coach: {               // Coach selection
    id: String,
    name: String,
    rate: Number
  },
  equipment: [{          // Equipment rentals
    name: String,
    quantity: Number,
    price: Number
  }],
  facilities: [{         // Facility bookings
    name: String,
    price: Number
  }],
  pricing: {             // Price breakdown
    basePrice: Number,
    coachFee: Number,
    equipmentFee: Number,
    facilityFee: Number,
    totalPrice: Number
  },
  status: String,        // Booking status
  paymentStatus: String, // Payment status
  specialRequests: String,// Special requests
  createdAt: Date,       // Creation date
  updatedAt: Date        // Last update
}
```

### Coach Model
```javascript
{
  id: String,            // Unique coach ID
  name: String,          // Coach name
  specialty: String,     // Specialty area
  rate: String,          // Display rate
  hourlyRate: Number,    // Numeric rate
  sport: String,         // Sport specialty
  bio: String,           // Biography
  experience: Number,    // Years of experience
  certifications: [{     // Certifications
    name: String,
    issuedBy: String,
    dateIssued: Date,
    expiryDate: Date
  }],
  availability: {        // Weekly availability
    monday: [String],    // Available time slots
    tuesday: [String],
    // ... other days
  },
  contact: {             // Contact information
    email: String,
    phone: String
  },
  rating: {              // Rating system
    average: Number,
    totalReviews: Number
  },
  isActive: Boolean      // Active status
}
```

## Authentication

The API uses JWT tokens for authentication. Include the token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

### Protected Routes
- All `/api/users/profile` routes require authentication
- Admin routes require admin privileges
- Booking creation and updates require authentication

## Email Notifications

The system sends automated emails for:
- Booking confirmations
- Booking updates
- Booking cancellations
- Payment confirmations

Configure email settings in the `.env` file using your email provider's SMTP settings.

## Error Handling

The API returns consistent error responses:

```javascript
{
  "error": {
    "message": "Error description",
    "status": 400,
    "code": "ERROR_CODE"
  }
}
```

Common HTTP status codes:
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `500` - Internal Server Error

## Development

### Running Tests
```bash
npm test
```

### Code Linting
```bash
npm run lint
```

### Database Seeding
```bash
npm run seed
```

### Available Scripts
- `npm start` - Start production server
- `npm run dev` - Start development server with nodemon
- `npm run seed` - Seed database with sample data
- `npm test` - Run tests
- `npm run lint` - Run ESLint

## Deployment

### Production Environment Variables
Ensure all environment variables are set:
- `MONGODB_URI` - Production MongoDB connection string
- `JWT_SECRET` - Strong JWT secret key
- `EMAIL_*` - Email service configuration
- `NODE_ENV=production`

### Database Indexes
The application creates necessary indexes automatically. For production, consider adding:
- Compound indexes for frequent queries
- Text indexes for search functionality
- TTL indexes for temporary data

### Security Considerations
- Use strong JWT secrets
- Enable HTTPS in production
- Configure CORS for your domain
- Set up proper MongoDB authentication
- Use environment variables for secrets
- Enable request rate limiting

## Monitoring

Consider implementing:
- Application performance monitoring (APM)
- Error tracking (e.g., Sentry)
- Database monitoring
- API analytics
- Health checks

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Run linting and tests
6. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@advancedsports.ke or create an issue in the repository.