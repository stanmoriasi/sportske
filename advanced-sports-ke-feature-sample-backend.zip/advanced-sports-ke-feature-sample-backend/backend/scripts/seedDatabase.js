import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Sport from '../models/Sport.js';
import Coach from '../models/Coach.js';

dotenv.config();

const seedDatabase = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');

    // Clear existing data
    await Sport.deleteMany({});
    await Coach.deleteMany({});
    console.log('Cleared existing data');

    // Seed Sports
    const sports = [
      {
        name: 'football',
        displayName: 'Football',
        description: 'Professional football training and matches on our premium grass fields. Perfect for team building and skill development.',
        basePrice: 25,
        duration: 90,
        maxParticipants: 22,
        equipment: [
          { name: 'Football', price: 5, description: 'Official size football', available: true },
          { name: 'Cones', price: 3, description: 'Training cones set', available: true },
          { name: 'Bibs', price: 10, description: 'Team training bibs (set of 20)', available: true }
        ],
        facilities: [
          { name: 'Full Pitch', price: 50, description: 'Full-size football pitch', capacity: 22, available: true },
          { name: 'Half Pitch', price: 30, description: 'Half-size football pitch', capacity: 12, available: true }
        ],
        operatingHours: {
          weekdays: { start: '06:00', end: '22:00' },
          weekends: { start: '07:00', end: '21:00' }
        },
        rules: [
          'Appropriate football boots required',
          'No metal studs on artificial pitches', 
          'Maximum 90 minutes per booking',
          'Bookings must be made 24 hours in advance'
        ],
        isActive: true,
        popularityScore: 85
      },
      {
        name: 'basketball',
        displayName: 'Basketball',
        description: 'Indoor basketball courts with professional hoops and flooring. Great for casual games or serious training.',
        basePrice: 20,
        duration: 60,
        maxParticipants: 10,
        equipment: [
          { name: 'Basketball', price: 3, description: 'Official size basketball', available: true },
          { name: 'Training Cones', price: 5, description: 'Agility training cones', available: true }
        ],
        facilities: [
          { name: 'Full Court', price: 40, description: 'Full basketball court', capacity: 10, available: true },
          { name: 'Half Court', price: 25, description: 'Half basketball court', capacity: 6, available: true }
        ],
        operatingHours: {
          weekdays: { start: '06:00', end: '22:00' },
          weekends: { start: '08:00', end: '20:00' }
        },
        rules: [
          'Non-marking sports shoes required',
          'No food or drinks on court',
          'Maximum 60 minutes per booking',
          'Clean up after use'
        ],
        isActive: true,
        popularityScore: 70
      },
      {
        name: 'tennis',
        displayName: 'Tennis',
        description: 'Premium tennis courts with professional surfaces. Individual coaching available with certified instructors.',
        basePrice: 30,
        duration: 60,
        maxParticipants: 4,
        equipment: [
          { name: 'Tennis Racket', price: 5, description: 'Professional tennis racket', available: true },
          { name: 'Tennis Balls', price: 8, description: 'Set of 4 tennis balls', available: true }
        ],
        facilities: [
          { name: 'Clay Court', price: 15, description: 'Professional clay tennis court', capacity: 4, available: true },
          { name: 'Hard Court', price: 12, description: 'Hard surface tennis court', capacity: 4, available: true },
          { name: 'Grass Court', price: 20, description: 'Premium grass tennis court', capacity: 4, available: true }
        ],
        operatingHours: {
          weekdays: { start: '06:00', end: '22:00' },
          weekends: { start: '07:00', end: '21:00' }
        },
        rules: [
          'Appropriate tennis shoes required',
          'No black soles on courts',
          'Book coaching sessions in advance',
          'Respect court reservation times'
        ],
        isActive: true,
        popularityScore: 90
      },
      {
        name: 'swimming',
        displayName: 'Swimming',
        description: 'Olympic-size swimming pool with lane availability. Professional lifeguards on duty at all times.',
        basePrice: 15,
        duration: 45,
        maxParticipants: 8,
        equipment: [
          { name: 'Kickboard', price: 3, description: 'Swimming kickboard', available: true },
          { name: 'Pull Buoy', price: 3, description: 'Swimming pull buoy', available: true },
          { name: 'Goggles', price: 8, description: 'Swimming goggles', available: true }
        ],
        facilities: [
          { name: 'Olympic Pool', price: 0, description: 'Olympic-size swimming pool', capacity: 8, available: true },
          { name: 'Training Pool', price: 0, description: 'Smaller training pool', capacity: 4, available: true }
        ],
        operatingHours: {
          weekdays: { start: '06:00', end: '21:00' },
          weekends: { start: '08:00', end: '20:00' }
        },
        rules: [
          'Shower before entering pool',
          'Swimming attire mandatory',
          'No diving in shallow areas',
          'Follow lifeguard instructions'
        ],
        isActive: true,
        popularityScore: 65
      }
    ];

    const savedSports = await Sport.insertMany(sports);
    console.log(`Seeded ${savedSports.length} sports`);

    // Seed Tennis Coaches
    const coaches = [
      {
        name: 'John Smith',
        specialty: 'Professional Coach',
        rate: '+$25/hour',
        hourlyRate: 25,
        sport: 'tennis',
        bio: 'Former professional tennis player with 15 years of coaching experience. Specialized in advanced techniques and competitive play.',
        experience: 15,
        certifications: [
          {
            name: 'Professional Tennis Registry (PTR)',
            issuedBy: 'PTR',
            dateIssued: new Date('2010-03-15'),
            expiryDate: new Date('2025-03-15')
          }
        ],
        availability: {
          monday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
          tuesday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
          wednesday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
          thursday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
          friday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
          saturday: ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00'],
          sunday: ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00']
        },
        contact: {
          email: 'john.smith@advancedsports.ke',
          phone: '+254-700-123-456'
        },
        rating: {
          average: 4.8,
          totalReviews: 127
        },
        isActive: true
      },
      {
        name: 'Maria Lopez',
        specialty: 'Beginner Specialist',
        rate: '+$20/hour',
        hourlyRate: 20,
        sport: 'tennis',
        bio: 'Patient and encouraging coach who specializes in teaching beginners and junior players. Focus on building strong fundamentals.',
        experience: 8,
        certifications: [
          {
            name: 'Tennis Industry Association (TIA)',
            issuedBy: 'TIA',
            dateIssued: new Date('2016-06-20'),
            expiryDate: new Date('2026-06-20')
          }
        ],
        availability: {
          monday: ['10:00', '11:00', '15:00', '16:00', '17:00'],
          tuesday: ['10:00', '11:00', '15:00', '16:00', '17:00'],
          wednesday: ['10:00', '11:00', '15:00', '16:00', '17:00'],
          thursday: ['10:00', '11:00', '15:00', '16:00', '17:00'],
          friday: ['10:00', '11:00', '15:00', '16:00', '17:00'],
          saturday: ['09:00', '10:00', '11:00', '14:00', '15:00'],
          sunday: ['09:00', '10:00', '11:00', '14:00', '15:00']
        },
        contact: {
          email: 'maria.lopez@advancedsports.ke',
          phone: '+254-700-123-457'
        },
        rating: {
          average: 4.9,
          totalReviews: 89
        },
        isActive: true
      },
      {
        name: 'David Wilson',
        specialty: 'Advanced Training',
        rate: '+$30/hour',
        hourlyRate: 30,
        sport: 'tennis',
        bio: 'High-performance coach working with competitive players. Specialized in match strategy, mental toughness, and advanced techniques.',
        experience: 12,
        certifications: [
          {
            name: 'International Tennis Federation (ITF)',
            issuedBy: 'ITF',
            dateIssued: new Date('2012-09-10'),
            expiryDate: new Date('2027-09-10')
          }
        ],
        availability: {
          monday: ['07:00', '08:00', '17:00', '18:00', '19:00'],
          tuesday: ['07:00', '08:00', '17:00', '18:00', '19:00'],
          wednesday: ['07:00', '08:00', '17:00', '18:00', '19:00'],
          thursday: ['07:00', '08:00', '17:00', '18:00', '19:00'],
          friday: ['07:00', '08:00', '17:00', '18:00', '19:00'],
          saturday: ['07:00', '08:00', '16:00', '17:00', '18:00'],
          sunday: ['07:00', '08:00', '16:00', '17:00', '18:00']
        },
        contact: {
          email: 'david.wilson@advancedsports.ke',
          phone: '+254-700-123-458'
        },
        rating: {
          average: 4.7,
          totalReviews: 156
        },
        isActive: true
      },
      {
        name: 'Sarah Chen',
        specialty: 'Youth Coach',
        rate: '+$22/hour',
        hourlyRate: 22,
        sport: 'tennis',
        bio: 'Energetic coach specializing in youth development (ages 6-16). Creates fun, engaging lessons that build skills and confidence.',
        experience: 6,
        certifications: [
          {
            name: 'Youth Tennis Development',
            issuedBy: 'Tennis Australia',
            dateIssued: new Date('2018-04-05'),
            expiryDate: new Date('2028-04-05')
          }
        ],
        availability: {
          monday: ['16:00', '17:00', '18:00'],
          tuesday: ['16:00', '17:00', '18:00'],
          wednesday: ['16:00', '17:00', '18:00'],
          thursday: ['16:00', '17:00', '18:00'],
          friday: ['16:00', '17:00', '18:00'],
          saturday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
          sunday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00']
        },
        contact: {
          email: 'sarah.chen@advancedsports.ke',
          phone: '+254-700-123-459'
        },
        rating: {
          average: 4.9,
          totalReviews: 74
        },
        isActive: true
      }
    ];

    const savedCoaches = await Coach.insertMany(coaches);
    console.log(`Seeded ${savedCoaches.length} coaches`);

    console.log('Database seeding completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
};

seedDatabase();