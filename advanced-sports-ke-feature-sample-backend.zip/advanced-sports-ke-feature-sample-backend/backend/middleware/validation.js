import Joi from 'joi';

// Booking validation schema
const bookingSchema = Joi.object({
  sport: Joi.string()
    .valid('football', 'basketball', 'tennis', 'swimming')
    .required()
    .messages({
      'string.base': 'Sport must be a string',
      'any.only': 'Sport must be one of: football, basketball, tennis, swimming',
      'any.required': 'Sport is required'
    }),

  dateTime: Joi.object({
    date: Joi.string().required().messages({
      'string.base': 'Date must be a string',
      'any.required': 'Date is required'
    }),
    time: Joi.string().required().messages({
      'string.base': 'Time must be a string', 
      'any.required': 'Time is required'
    }),
    datetime: Joi.date().required().messages({
      'date.base': 'Datetime must be a valid date',
      'any.required': 'Datetime is required'
    })
  }).required().messages({
    'object.base': 'DateTime must be an object',
    'any.required': 'DateTime is required'
  }),

  status: Joi.string()
    .valid('pending', 'confirmed', 'cancelled', 'completed')
    .default('pending'),

  confirmationId: Joi.string(),
  sessionId: Joi.string(),

  userInfo: Joi.object({
    name: Joi.string().min(2).max(100),
    email: Joi.string().email(),
    phone: Joi.string().pattern(/^[\+]?[1-9][\d]{0,15}$/)
  }).optional(),

  tennis: Joi.object({
    coach: Joi.object({
      id: Joi.string(),
      name: Joi.string(),
      specialty: Joi.string(),
      rate: Joi.string()
    }).optional(),
    extras: Joi.object({
      rackets: Joi.number().integer().min(0).default(0),
      courts: Joi.number().integer().min(0).default(0)
    }).default({ rackets: 0, courts: 0 }),
    totalExtrasCost: Joi.number().min(0).default(0)
  }).when('sport', {
    is: 'tennis',
    then: Joi.optional(),
    otherwise: Joi.forbidden()
  }),

  pricing: Joi.object({
    baseCost: Joi.number().min(0).default(20),
    extrasCost: Joi.number().min(0).default(0),
    totalCost: Joi.number().min(0).required()
  }).optional(),

  notes: Joi.string().max(500).optional(),

  createdAt: Joi.date().optional(),
  updatedAt: Joi.date().optional(),
  confirmedAt: Joi.date().optional(),
  cancelledAt: Joi.date().optional()
});

// Coach validation schema
const coachSchema = Joi.object({
  id: Joi.string().required().messages({
    'string.base': 'Coach ID must be a string',
    'any.required': 'Coach ID is required'
  }),
  
  name: Joi.string().min(2).max(100).required().messages({
    'string.base': 'Coach name must be a string',
    'string.min': 'Coach name must be at least 2 characters',
    'string.max': 'Coach name must be less than 100 characters',
    'any.required': 'Coach name is required'
  }),
  
  specialty: Joi.string().min(2).max(200).required().messages({
    'string.base': 'Specialty must be a string',
    'string.min': 'Specialty must be at least 2 characters',
    'string.max': 'Specialty must be less than 200 characters',
    'any.required': 'Specialty is required'
  }),
  
  rate: Joi.string().required().messages({
    'string.base': 'Rate must be a string',
    'any.required': 'Rate is required'
  }),
  
  hourlyRate: Joi.number().min(0).required().messages({
    'number.base': 'Hourly rate must be a number',
    'number.min': 'Hourly rate must be 0 or greater',
    'any.required': 'Hourly rate is required'
  }),
  
  sport: Joi.string()
    .valid('tennis', 'football', 'basketball', 'swimming')
    .required()
    .messages({
      'string.base': 'Sport must be a string',
      'any.only': 'Sport must be one of: tennis, football, basketball, swimming',
      'any.required': 'Sport is required'
    }),
  
  bio: Joi.string().max(1000).optional(),
  experience: Joi.number().integer().min(0).optional(),
  
  certifications: Joi.array().items(
    Joi.object({
      name: Joi.string(),
      issuedBy: Joi.string(),
      dateIssued: Joi.date(),
      expiryDate: Joi.date()
    })
  ).optional(),
  
  availability: Joi.object({
    monday: Joi.array().items(Joi.string()),
    tuesday: Joi.array().items(Joi.string()),
    wednesday: Joi.array().items(Joi.string()),
    thursday: Joi.array().items(Joi.string()),
    friday: Joi.array().items(Joi.string()),
    saturday: Joi.array().items(Joi.string()),
    sunday: Joi.array().items(Joi.string())
  }).optional(),
  
  contact: Joi.object({
    email: Joi.string().email(),
    phone: Joi.string()
  }).optional(),
  
  image: Joi.string().uri().optional(),
  
  rating: Joi.object({
    average: Joi.number().min(0).max(5).default(0),
    totalReviews: Joi.number().integer().min(0).default(0)
  }).optional(),
  
  isActive: Joi.boolean().default(true),
  joinedDate: Joi.date().optional()
});

// Sport validation schema
const sportSchema = Joi.object({
  name: Joi.string().min(2).max(50).required().messages({
    'string.base': 'Sport name must be a string',
    'string.min': 'Sport name must be at least 2 characters',
    'string.max': 'Sport name must be less than 50 characters',
    'any.required': 'Sport name is required'
  }),
  
  displayName: Joi.string().min(2).max(50).required().messages({
    'string.base': 'Display name must be a string',
    'string.min': 'Display name must be at least 2 characters',
    'string.max': 'Display name must be less than 50 characters',
    'any.required': 'Display name is required'
  }),
  
  description: Joi.string().min(10).max(1000).required().messages({
    'string.base': 'Description must be a string',
    'string.min': 'Description must be at least 10 characters',
    'string.max': 'Description must be less than 1000 characters',
    'any.required': 'Description is required'
  }),
  
  basePrice: Joi.number().min(0).default(20).messages({
    'number.base': 'Base price must be a number',
    'number.min': 'Base price must be 0 or greater'
  }),
  
  duration: Joi.number().integer().min(15).default(60).messages({
    'number.base': 'Duration must be a number',
    'number.integer': 'Duration must be an integer',
    'number.min': 'Duration must be at least 15 minutes'
  }),
  
  maxParticipants: Joi.number().integer().min(1).default(1).messages({
    'number.base': 'Max participants must be a number',
    'number.integer': 'Max participants must be an integer',
    'number.min': 'Max participants must be at least 1'
  }),
  
  equipment: Joi.array().items(
    Joi.object({
      name: Joi.string().required(),
      price: Joi.number().min(0).required(),
      description: Joi.string(),
      available: Joi.boolean().default(true)
    })
  ).optional(),
  
  facilities: Joi.array().items(
    Joi.object({
      name: Joi.string().required(),
      price: Joi.number().min(0).required(),
      description: Joi.string(),
      capacity: Joi.number().integer().min(1),
      available: Joi.boolean().default(true)
    })
  ).optional(),
  
  operatingHours: Joi.object({
    weekdays: Joi.object({
      start: Joi.string().default('06:00'),
      end: Joi.string().default('22:00')
    }),
    weekends: Joi.object({
      start: Joi.string().default('07:00'),
      end: Joi.string().default('21:00')
    })
  }).optional(),
  
  rules: Joi.array().items(Joi.string()).optional(),
  
  images: Joi.array().items(
    Joi.object({
      url: Joi.string().uri().required(),
      caption: Joi.string()
    })
  ).optional(),
  
  isActive: Joi.boolean().default(true)
});

// Validation middleware
export const validateBooking = (req, res, next) => {
  const { error } = bookingSchema.validate(req.body, { abortEarly: false });
  
  if (error) {
    return res.status(400).json({
      success: false,
      message: 'Validation error',
      errors: error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
      }))
    });
  }
  
  next();
};

export const validateCoach = (req, res, next) => {
  const { error } = coachSchema.validate(req.body, { abortEarly: false });
  
  if (error) {
    return res.status(400).json({
      success: false,
      message: 'Validation error',
      errors: error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
      }))
    });
  }
  
  next();
};

export const validateSport = (req, res, next) => {
  const { error } = sportSchema.validate(req.body, { abortEarly: false });
  
  if (error) {
    return res.status(400).json({
      success: false,
      message: 'Validation error',
      errors: error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
      }))
    });
  }
  
  next();
};