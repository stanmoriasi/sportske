# Advanced Sports Kenya - Setup Guide

## Quick Start

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (local installation or MongoDB Atlas)
- Git

### 1. Clone and Setup

```bash
# Clone the repository
git clone <your-repository-url>
cd advanced-sports-ke

# Install frontend dependencies
npm install

# Install backend dependencies
cd backend
npm install
```

### 2. Environment Configuration

Create a `.env` file in the backend directory:

```bash
cd backend
cp .env.example .env
```

Edit the `.env` file with your configuration:
- Set your MongoDB connection string
- Configure email settings for notifications
- Set a strong JWT secret for production

### 3. Database Setup

Start MongoDB and seed the database:

```bash
# Make sure MongoDB is running
# Then seed the database with sample data
npm run seed
```

### 4. Start the Application

```bash
# Terminal 1: Start the backend server
cd backend
npm run dev

# Terminal 2: Start the frontend development server
cd ../
npm run dev
```

The application will be available at:
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000

## Integration Guide

### Frontend-Backend Integration

The current frontend uses localStorage. To integrate with the backend API:

1. **Replace localStorage with API calls** in `src/pages/Booking.jsx`
2. **Update booking confirmation** in `src/pages/Home.jsx`
3. **Add error handling** and loading states

#### Example API Integration

Replace localStorage booking save with:

```javascript
// In Booking.jsx
const handleBookNow = async () => {
  try {
    const response = await fetch('http://localhost:5000/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(bookingData)
    });
    
    if (response.ok) {
      const booking = await response.json();
      navigate('/', { state: { bookingConfirmed: true, booking } });
    }
  } catch (error) {
    console.error('Booking failed:', error);
  }
};
```

### API Testing

Test the backend endpoints using curl or Postman:

```bash
# Get all sports
curl http://localhost:5000/api/sports

# Get tennis coaches
curl http://localhost:5000/api/coaches/sport/tennis

# Create a booking
curl -X POST http://localhost:5000/api/bookings \
  -H "Content-Type: application/json" \
  -d '{
    "sport": "tennis",
    "date": "2024-01-15",
    "time": "10:00",
    "customerInfo": {
      "firstName": "John",
      "lastName": "Doe",
      "email": "john@example.com",
      "phone": "+254-700-123-456"
    }
  }'
```

## Production Deployment

### Backend Deployment (Railway/Heroku)

1. **Environment Variables**: Set all required environment variables in your deployment platform
2. **Database**: Use MongoDB Atlas for production
3. **Email**: Configure production email service (SendGrid, Mailgun, etc.)

### Frontend Deployment (Vercel/Netlify)

1. **Update API URLs**: Change from localhost to your production API URL
2. **Environment Variables**: Set production API endpoints
3. **Build**: Ensure the build process includes the backend API URL

### Environment Variables for Production

Backend (.env):
```env
NODE_ENV=production
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/advanced-sports-ke
JWT_SECRET=your-production-jwt-secret
EMAIL_HOST=smtp.sendgrid.net
EMAIL_USER=apikey
EMAIL_PASS=your-sendgrid-api-key
```

Frontend:
```env
VITE_API_URL=https://your-backend-api.railway.app
```

## Development Workflow

### 1. Adding New Features

1. **Backend**: Add models, routes, and validation
2. **Frontend**: Create components and integrate with API
3. **Testing**: Test endpoints and UI functionality

### 2. Database Changes

1. **Update Models**: Modify Mongoose schemas
2. **Migration**: Create migration scripts if needed
3. **Seed Data**: Update seed scripts with new data

### 3. API Changes

1. **Update Routes**: Modify or add API endpoints
2. **Documentation**: Update API documentation
3. **Frontend**: Update API calls in React components

## Troubleshooting

### Common Issues

**MongoDB Connection Error**:
- Ensure MongoDB is running
- Check connection string in .env
- Verify network access for MongoDB Atlas

**Email Not Sending**:
- Check email configuration in .env
- Verify SMTP credentials
- Enable "Less secure app access" for Gmail (development only)

**CORS Errors**:
- Update CORS configuration in server.js
- Check frontend URL in backend CORS settings

**JWT Authentication Issues**:
- Verify JWT secret is set
- Check token expiration
- Ensure proper header format: "Bearer <token>"

### Logs and Debugging

**Backend Logs**:
```bash
cd backend
npm run dev  # Shows server logs
```

**Database Queries**:
Enable Mongoose debug mode in development:
```javascript
mongoose.set('debug', true);
```

**API Testing**:
Use the provided Postman collection or test with curl commands.

## Next Steps

1. **Authentication**: Implement user registration and login in frontend
2. **Payment Integration**: Add payment processing (Stripe, PayPal)
3. **Real-time Updates**: Implement WebSocket for live booking updates
4. **Mobile App**: Consider React Native for mobile application
5. **Analytics**: Add booking analytics and reporting
6. **Notifications**: Implement push notifications for booking reminders

## Support

For technical support:
- Check the README.md files
- Review API documentation
- Create GitHub issues for bugs
- Contact: support@advancedsports.ke