import nodemailer from 'nodemailer';

// Create email transporter
const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: process.env.EMAIL_PORT,
    secure: false, // true for 465, false for other ports
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });
};

// Send booking confirmation email
export const sendBookingConfirmation = async (email, booking) => {
  try {
    const transporter = createTransporter();

    const formatDate = (dateString) => {
      return new Date(dateString).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    };

    const formatTime = (timeString) => {
      const [hours, minutes] = timeString.split(':');
      const date = new Date();
      date.setHours(parseInt(hours), parseInt(minutes));
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
    };

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Booking Confirmation - Advanced Sports Kenya</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #d4af37; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .booking-details { background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0; }
          .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 5px 0; border-bottom: 1px solid #eee; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
          .confirmation-id { font-size: 18px; font-weight: bold; color: #d4af37; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🏆 Advanced Sports Kenya</h1>
            <h2>Booking Confirmation</h2>
          </div>
          
          <div class="content">
            <p>Dear ${booking.userInfo?.name || 'Valued Customer'},</p>
            <p>Your sports session has been successfully booked! Here are your booking details:</p>
            
            <div class="booking-details">
              <div class="detail-row">
                <span><strong>Confirmation ID:</strong></span>
                <span class="confirmation-id">${booking.confirmationId}</span>
              </div>
              <div class="detail-row">
                <span><strong>Sport:</strong></span>
                <span>${booking.sport.charAt(0).toUpperCase() + booking.sport.slice(1)}</span>
              </div>
              <div class="detail-row">
                <span><strong>Date:</strong></span>
                <span>${formatDate(booking.dateTime.date)}</span>
              </div>
              <div class="detail-row">
                <span><strong>Time:</strong></span>
                <span>${formatTime(booking.dateTime.time)}</span>
              </div>
              ${booking.tennis?.coach ? `
                <div class="detail-row">
                  <span><strong>Coach:</strong></span>
                  <span>${booking.tennis.coach.name} - ${booking.tennis.coach.specialty}</span>
                </div>
              ` : ''}
              ${booking.tennis?.extras?.rackets > 0 ? `
                <div class="detail-row">
                  <span><strong>Rackets:</strong></span>
                  <span>${booking.tennis.extras.rackets} x $5 = $${booking.tennis.extras.rackets * 5}</span>
                </div>
              ` : ''}
              ${booking.tennis?.extras?.courts > 0 ? `
                <div class="detail-row">
                  <span><strong>Courts:</strong></span>
                  <span>${booking.tennis.extras.courts} x $15 = $${booking.tennis.extras.courts * 15}</span>
                </div>
              ` : ''}
              <div class="detail-row" style="border-top: 2px solid #d4af37; font-weight: bold; margin-top: 15px;">
                <span>Total Cost:</span>
                <span>$${booking.pricing?.totalCost || 20}</span>
              </div>
            </div>
            
            <p><strong>Important Information:</strong></p>
            <ul>
              <li>Please arrive 15 minutes before your scheduled time</li>
              <li>Bring appropriate sports attire and footwear</li>
              <li>Cancellations must be made at least 24 hours in advance</li>
              <li>Save this confirmation email for your records</li>
            </ul>
            
            <p>If you have any questions or need to modify your booking, please contact us:</p>
            <p>📞 +1 (555) 123-4567<br>
               📧 booking@advancedsports.ke</p>
            
            <p>We look forward to seeing you at Advanced Sports Kenya!</p>
          </div>
          
          <div class="footer">
            <p>Advanced Sports Kenya - Excellence in Sports Training</p>
            <p>This is an automated email. Please do not reply directly to this message.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: `"Advanced Sports Kenya" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: `Booking Confirmation - ${booking.confirmationId}`,
      html: htmlContent,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('Booking confirmation email sent:', info.messageId);
    
    return info;
  } catch (error) {
    console.error('Error sending booking confirmation email:', error);
    throw error;
  }
};

// Send booking status update email
export const sendBookingStatusUpdate = async (email, booking, oldStatus, newStatus) => {
  try {
    const transporter = createTransporter();

    const formatDate = (dateString) => {
      return new Date(dateString).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    };

    const formatTime = (timeString) => {
      const [hours, minutes] = timeString.split(':');
      const date = new Date();
      date.setHours(parseInt(hours), parseInt(minutes));
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
    };

    const getStatusColor = (status) => {
      switch(status) {
        case 'confirmed': return '#28a745';
        case 'cancelled': return '#dc3545';
        case 'completed': return '#17a2b8';
        default: return '#ffc107';
      }
    };

    const getStatusMessage = (status) => {
      switch(status) {
        case 'confirmed': return 'Your booking has been confirmed! 🎉';
        case 'cancelled': return 'Your booking has been cancelled';
        case 'completed': return 'Thank you for your session! 🏆';
        case 'pending': return 'Your booking is pending confirmation';
        default: return `Your booking status has been updated to: ${status}`;
      }
    };

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Booking Status Update - Advanced Sports Kenya</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: ${getStatusColor(newStatus)}; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .booking-details { background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0; }
          .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 5px 0; border-bottom: 1px solid #eee; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
          .status-badge { padding: 5px 10px; border-radius: 15px; color: white; background-color: ${getStatusColor(newStatus)}; font-weight: bold; }
          .confirmation-id { font-size: 18px; font-weight: bold; color: #d4af37; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🏆 Advanced Sports Kenya</h1>
            <h2>Booking Status Update</h2>
          </div>
          
          <div class="content">
            <p>Dear ${booking.userInfo?.name || 'Valued Customer'},</p>
            <p>${getStatusMessage(newStatus)}</p>
            
            <div class="booking-details">
              <div class="detail-row">
                <span><strong>Confirmation ID:</strong></span>
                <span class="confirmation-id">${booking.confirmationId}</span>
              </div>
              <div class="detail-row">
                <span><strong>Status:</strong></span>
                <span class="status-badge">${newStatus.toUpperCase()}</span>
              </div>
              <div class="detail-row">
                <span><strong>Sport:</strong></span>
                <span>${booking.sport.charAt(0).toUpperCase() + booking.sport.slice(1)}</span>
              </div>
              <div class="detail-row">
                <span><strong>Date:</strong></span>
                <span>${formatDate(booking.dateTime.date)}</span>
              </div>
              <div class="detail-row">
                <span><strong>Time:</strong></span>
                <span>${formatTime(booking.dateTime.time)}</span>
              </div>
              ${booking.tennis?.coach ? `
                <div class="detail-row">
                  <span><strong>Coach:</strong></span>
                  <span>${booking.tennis.coach.name} - ${booking.tennis.coach.specialty}</span>
                </div>
              ` : ''}
            </div>
            
            ${newStatus === 'confirmed' ? `
              <div style="background-color: #d4edda; border: 1px solid #c3e6cb; padding: 15px; border-radius: 5px; margin: 15px 0;">
                <h4 style="color: #155724; margin-top: 0;">🎉 Booking Confirmed!</h4>
                <p style="color: #155724; margin-bottom: 0;">
                  Your session is confirmed! Please arrive 15 minutes early and bring appropriate sports attire.
                </p>
              </div>
            ` : ''}
            
            ${newStatus === 'cancelled' ? `
              <div style="background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; border-radius: 5px; margin: 15px 0;">
                <h4 style="color: #721c24; margin-top: 0;">Booking Cancelled</h4>
                <p style="color: #721c24; margin-bottom: 0;">
                  We're sorry to see your booking cancelled. You can make a new booking anytime through our website.
                </p>
              </div>
            ` : ''}
            
            ${newStatus === 'completed' ? `
              <div style="background-color: #d1ecf1; border: 1px solid #bee5eb; padding: 15px; border-radius: 5px; margin: 15px 0;">
                <h4 style="color: #0c5460; margin-top: 0;">🏆 Session Completed!</h4>
                <p style="color: #0c5460; margin-bottom: 0;">
                  Thank you for choosing Advanced Sports Kenya! We hope you had a great experience. Please consider leaving us a review!
                </p>
              </div>
            ` : ''}
            
            <p>If you have any questions, please contact us:</p>
            <p>📞 +1 (555) 123-4567<br>
               📧 booking@advancedsports.ke</p>
          </div>
          
          <div class="footer">
            <p>Advanced Sports Kenya - Excellence in Sports Training</p>
            <p>This is an automated email. Please do not reply directly to this message.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: `"Advanced Sports Kenya" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: `Booking ${newStatus.charAt(0).toUpperCase() + newStatus.slice(1)} - ${booking.confirmationId}`,
      html: htmlContent,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log(`Booking ${newStatus} email sent:`, info.messageId);
    
    return info;
  } catch (error) {
    console.error('Error sending booking status update email:', error);
    throw error;
  }
};

// Send booking cancellation email
export const sendBookingCancellation = async (email, booking) => {
  try {
    const transporter = createTransporter();

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Booking Cancellation - Advanced Sports Kenya</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #dc3545; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .booking-details { background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🏆 Advanced Sports Kenya</h1>
            <h2>Booking Cancellation</h2>
          </div>
          
          <div class="content">
            <p>Dear ${booking.userInfo?.name || 'Valued Customer'},</p>
            <p>We confirm that your booking (${booking.confirmationId}) has been cancelled successfully.</p>
            
            <div class="booking-details">
              <p><strong>Cancelled Booking Details:</strong></p>
              <p>Sport: ${booking.sport}<br>
                 Date: ${booking.dateTime.date}<br>
                 Time: ${booking.dateTime.time}</p>
            </div>
            
            <p>If you have any questions about this cancellation or would like to make a new booking, please contact us:</p>
            <p>📞 +1 (555) 123-4567<br>
               📧 booking@advancedsports.ke</p>
            
            <p>Thank you for choosing Advanced Sports Kenya!</p>
          </div>
          
          <div class="footer">
            <p>Advanced Sports Kenya - Excellence in Sports Training</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: `"Advanced Sports Kenya" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: `Booking Cancelled - ${booking.confirmationId}`,
      html: htmlContent,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('Booking cancellation email sent:', info.messageId);
    
    return info;
  } catch (error) {
    console.error('Error sending booking cancellation email:', error);
    throw error;
  }
};

// Send booking reminder email (24 hours before session)
export const sendBookingReminder = async (email, booking) => {
  try {
    const transporter = createTransporter();

    const formatDate = (dateString) => {
      return new Date(dateString).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    };

    const formatTime = (timeString) => {
      const [hours, minutes] = timeString.split(':');
      const date = new Date();
      date.setHours(parseInt(hours), parseInt(minutes));
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
    };

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Booking Reminder - Advanced Sports Kenya</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #007bff; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .booking-details { background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0; }
          .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 5px 0; border-bottom: 1px solid #eee; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
          .reminder-box { background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 15px 0; }
          .confirmation-id { font-size: 18px; font-weight: bold; color: #d4af37; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🏆 Advanced Sports Kenya</h1>
            <h2>⏰ Session Reminder</h2>
          </div>
          
          <div class="content">
            <p>Dear ${booking.userInfo?.name || 'Valued Customer'},</p>
            
            <div class="reminder-box">
              <h3 style="color: #856404; margin-top: 0;">🔔 Your session is tomorrow!</h3>
              <p style="color: #856404; margin-bottom: 0; font-weight: bold;">
                Don't forget about your upcoming sports session at Advanced Sports Kenya.
              </p>
            </div>
            
            <div class="booking-details">
              <div class="detail-row">
                <span><strong>Confirmation ID:</strong></span>
                <span class="confirmation-id">${booking.confirmationId}</span>
              </div>
              <div class="detail-row">
                <span><strong>Sport:</strong></span>
                <span>${booking.sport.charAt(0).toUpperCase() + booking.sport.slice(1)}</span>
              </div>
              <div class="detail-row">
                <span><strong>Date:</strong></span>
                <span>${formatDate(booking.dateTime.date)}</span>
              </div>
              <div class="detail-row">
                <span><strong>Time:</strong></span>
                <span>${formatTime(booking.dateTime.time)}</span>
              </div>
              ${booking.tennis?.coach ? `
                <div class="detail-row">
                  <span><strong>Coach:</strong></span>
                  <span>${booking.tennis.coach.name} - ${booking.tennis.coach.specialty}</span>
                </div>
              ` : ''}
            </div>
            
            <div style="background-color: #d4edda; border: 1px solid #c3e6cb; padding: 15px; border-radius: 5px; margin: 15px 0;">
              <h4 style="color: #155724; margin-top: 0;">📋 Pre-Session Checklist:</h4>
              <ul style="color: #155724; margin-bottom: 0;">
                <li>Arrive 15 minutes before your scheduled time</li>
                <li>Bring appropriate sports attire and footwear</li>
                <li>Bring water and a towel</li>
                <li>Have your confirmation ID ready</li>
                ${booking.tennis?.extras?.rackets === 0 ? '<li>Bring your own racket (or rent one at our facility)</li>' : ''}
              </ul>
            </div>
            
            <p><strong>Need to cancel or reschedule?</strong><br>
            Please contact us at least 24 hours in advance:</p>
            <p>📞 +1 (555) 123-4567<br>
               📧 booking@advancedsports.ke</p>
            
            <p>We're looking forward to seeing you tomorrow!</p>
          </div>
          
          <div class="footer">
            <p>Advanced Sports Kenya - Excellence in Sports Training</p>
            <p>This is an automated reminder. Please do not reply directly to this message.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: `"Advanced Sports Kenya" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: `⏰ Session Reminder Tomorrow - ${booking.confirmationId}`,
      html: htmlContent,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('Booking reminder email sent:', info.messageId);
    
    return info;
  } catch (error) {
    console.error('Error sending booking reminder email:', error);
    throw error;
  }
};

// Send coach notification email when a new booking is made
export const sendCoachBookingNotification = async (coachEmail, booking, coachInfo) => {
  try {
    const transporter = createTransporter();

    const formatDate = (dateString) => {
      return new Date(dateString).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    };

    const formatTime = (timeString) => {
      const [hours, minutes] = timeString.split(':');
      const date = new Date();
      date.setHours(parseInt(hours), parseInt(minutes));
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
    };

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>New Booking Notification - Advanced Sports Kenya</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #17a2b8; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .booking-details { background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0; border-left: 4px solid #17a2b8; }
          .client-details { background-color: #e8f4f8; padding: 15px; border-radius: 5px; margin: 15px 0; }
          .detail-row { display: flex; justify-content: space-between; margin: 10px 0; padding: 5px 0; border-bottom: 1px solid #eee; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
          .confirmation-id { font-size: 18px; font-weight: bold; color: #d4af37; }
          .new-booking-badge { background-color: #28a745; color: white; padding: 5px 10px; border-radius: 15px; font-weight: bold; }
          .coach-name { color: #17a2b8; font-weight: bold; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🏆 Advanced Sports Kenya</h1>
            <h2>📅 New Booking Alert</h2>
          </div>
          
          <div class="content">
            <p>Dear <span class="coach-name">${coachInfo?.name || 'Coach'}</span>,</p>
            
            <div style="background-color: #d4edda; border: 1px solid #c3e6cb; padding: 15px; border-radius: 5px; margin: 15px 0;">
              <h3 style="color: #155724; margin-top: 0;">🎉 You have a new booking!</h3>
              <p style="color: #155724; margin-bottom: 0;">
                A new client has booked a session with you. Please review the details below.
              </p>
            </div>

            <div class="booking-details">
              <h4 style="color: #17a2b8; margin-top: 0;">📋 Booking Details</h4>
              
              <div class="detail-row">
                <span><strong>Confirmation ID:</strong></span>
                <span class="confirmation-id">${booking.confirmationId}</span>
              </div>
              <div class="detail-row">
                <span><strong>Status:</strong></span>
                <span class="new-booking-badge">${booking.status.toUpperCase()}</span>
              </div>
              <div class="detail-row">
                <span><strong>Sport:</strong></span>
                <span>${booking.sport.charAt(0).toUpperCase() + booking.sport.slice(1)}</span>
              </div>
              <div class="detail-row">
                <span><strong>Date:</strong></span>
                <span>${formatDate(booking.dateTime.date)}</span>
              </div>
              <div class="detail-row">
                <span><strong>Time:</strong></span>
                <span>${formatTime(booking.dateTime.time)}</span>
              </div>
              <div class="detail-row">
                <span><strong>Session Duration:</strong></span>
                <span>1 hour</span>
              </div>
              ${booking.tennis?.extras?.rackets > 0 ? `
                <div class="detail-row">
                  <span><strong>Equipment Needed:</strong></span>
                  <span>${booking.tennis.extras.rackets} racket(s) requested</span>
                </div>
              ` : ''}
              ${booking.notes ? `
                <div class="detail-row">
                  <span><strong>Special Notes:</strong></span>
                  <span>${booking.notes}</span>
                </div>
              ` : ''}
            </div>

            <div class="client-details">
              <h4 style="color: #17a2b8; margin-top: 0;">👤 Client Information</h4>
              
              <div class="detail-row">
                <span><strong>Name:</strong></span>
                <span>${booking.userInfo?.name || 'Not provided'}</span>
              </div>
              <div class="detail-row">
                <span><strong>Email:</strong></span>
                <span>${booking.userInfo?.email || 'Not provided'}</span>
              </div>
              <div class="detail-row">
                <span><strong>Phone:</strong></span>
                <span>${booking.userInfo?.phone || 'Not provided'}</span>
              </div>
            </div>

            <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 15px 0;">
              <h4 style="color: #856404; margin-top: 0;">📝 Next Steps:</h4>
              <ul style="color: #856404; margin-bottom: 0;">
                <li><strong>Confirm your availability</strong> by logging into the coach portal</li>
                <li><strong>Prepare your equipment</strong> and lesson plan</li>
                <li><strong>Contact the client</strong> if you need to discuss anything specific</li>
                <li><strong>Arrive 10 minutes early</strong> to set up the session area</li>
                ${booking.status === 'pending' ? '<li><strong>Accept or decline</strong> this booking through the system</li>' : ''}
              </ul>
            </div>

            ${booking.status === 'pending' ? `
              <div style="text-align: center; margin: 20px 0;">
                <p style="margin-bottom: 15px;"><strong>Please respond to this booking:</strong></p>
                <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/coach-portal" 
                   style="background-color: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 0 10px;">
                  ✅ Accept Booking
                </a>
                <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/coach-portal" 
                   style="background-color: #dc3545; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 0 10px;">
                  ❌ Decline Booking
                </a>
              </div>
            ` : ''}

            <p><strong>Questions or concerns?</strong><br>
            Contact our support team:</p>
            <p>📞 +1 (555) 123-4567<br>
               📧 support@advancedsports.ke<br>
               💻 Coach Portal: <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/coach-portal">Login Here</a></p>
            
            <p>Thank you for being part of the Advanced Sports Kenya team!</p>
          </div>
          
          <div class="footer">
            <p>Advanced Sports Kenya - Excellence in Sports Training</p>
            <p>Coach Notification System | This email was sent automatically</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: `"Advanced Sports Kenya Bookings" <${process.env.EMAIL_USER}>`,
      to: coachEmail,
      subject: `🏆 New Booking: ${booking.sport} session on ${formatDate(booking.dateTime.date)} - ${booking.confirmationId}`,
      html: htmlContent,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log(`Coach notification email sent to ${coachEmail}:`, info.messageId);
    
    return info;
  } catch (error) {
    console.error('Error sending coach booking notification:', error);
    throw error;
  }
};