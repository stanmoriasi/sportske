import { useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router";

const NavLink = ({ href, children, active = false}) => {
  const [isHovered, setIsHovered] = useState(false);
  const navigate = useNavigate();

  return (
    <motion.button
      onClick={() => navigate(href)}
      className="relative inline-block px-2 py-3 text-white"
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      {children}
      <motion.span
        className="absolute block w-full left-0 bottom-0 h-1 bg-primary origin-left rounded"
        initial={{ scaleX: active ? 0.75 : 0 }}
        animate={{ scaleX: (active) || isHovered ? 0.75 : 0 }}
        transition={{ duration: 0.3 }}
      />
    </motion.button>
  );
};

export default NavLink;
