import express from 'express';
import Coach from '../models/Coach.js';

const router = express.Router();

// GET /api/coaches - Get all coaches
router.get('/', async (req, res) => {
  try {
    const { sport, active = true } = req.query;
    
    const filter = {};
    if (sport) filter.sport = sport.toLowerCase();
    if (active === 'true') filter.isActive = true;

    const coaches = await Coach.find(filter)
      .sort({ 'rating.average': -1, name: 1 });

    res.json({
      success: true,
      data: coaches,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching coaches',
      error: error.message,
    });
  }
});

// GET /api/coaches/:id - Get a specific coach
router.get('/:id', async (req, res) => {
  try {
    const coach = await Coach.findById(req.params.id);
    
    if (!coach) {
      return res.status(404).json({
        success: false,
        message: 'Coach not found',
      });
    }

    res.json({
      success: true,
      data: coach,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching coach',
      error: error.message,
    });
  }
});

// GET /api/coaches/sport/:sport - Get coaches by sport
router.get('/sport/:sport', async (req, res) => {
  try {
    const coaches = await Coach.findBySport(req.params.sport);

    res.json({
      success: true,
      data: coaches,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching coaches',
      error: error.message,
    });
  }
});

// POST /api/coaches - Create a new coach (Admin only)
router.post('/', async (req, res) => {
  try {
    const coach = new Coach(req.body);
    await coach.save();

    res.status(201).json({
      success: true,
      message: 'Coach created successfully',
      data: coach,
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors: Object.values(error.errors).map(err => err.message),
      });
    }

    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: 'Duplicate coach data detected',
      });
    }

    res.status(500).json({
      success: false,
      message: 'Error creating coach',
      error: error.message,
    });
  }
});

// PUT /api/coaches/:id - Update a coach
router.put('/:id', async (req, res) => {
  try {
    const coach = await Coach.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!coach) {
      return res.status(404).json({
        success: false,
        message: 'Coach not found',
      });
    }

    res.json({
      success: true,
      message: 'Coach updated successfully',
      data: coach,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating coach',
      error: error.message,
    });
  }
});

// DELETE /api/coaches/:id - Delete a coach (Admin only)
router.delete('/:id', async (req, res) => {
  try {
    // First, find the coach to get its _id for booking cleanup
    const coach = await Coach.findById(req.params.id);

    if (!coach) {
      return res.status(404).json({
        success: false,
        message: 'Coach not found',
      });
    }

    // Import Booking model for cleanup
    const { default: Booking } = await import('../models/Booking.js');
    
    // Count bookings that reference this coach
    const bookingCount = await Booking.countDocuments({ coachId: coach._id });
    
    // Remove coach references from bookings first
    const bookingUpdate = await Booking.updateMany(
      { coachId: coach._id },
      { 
        $unset: { coachId: 1 },
        $set: { updatedAt: new Date() }
      }
    );

    // Now delete the coach
    await Coach.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
      message: `Coach deleted successfully. Updated ${bookingUpdate.modifiedCount} booking(s) to remove coach assignment.`,
      data: {
        deletedCoach: coach.name,
        cleanedBookings: bookingUpdate.modifiedCount,
        totalBookingsFound: bookingCount
      }
    });
  } catch (error) {
    console.error('Error deleting coach:', error);
    res.status(500).json({
      success: false,
      message: 'Error deleting coach',
      error: error.message,
    });
  }
});

export default router;