import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import AuthForm from './AuthForm';

const ProtectedRoute = ({ children, requireAdmin = false }) => {
  const { user, loading, isAuthenticated, isAdmin, login } = useAuth();
  const [showAuthForm, setShowAuthForm] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated()) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-orange-500 mb-4">Access Restricted</h1>
            <p className="text-gray-400 text-lg mb-6">
              Please login to continue.
            </p>
            <button
              onClick={() => setShowAuthForm(true)}
              className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-300"
            >
              Login to Continue
            </button>
          </div>
        </div>

        {showAuthForm && (
          <AuthForm
            onAuthSuccess={(userData, token) => {
              login(userData, token);
              setShowAuthForm(false);
            }}
            onClose={() => setShowAuthForm(false)}
          />
        )}
      </div>
    );
  }

  if (requireAdmin && !isAdmin()) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-6">🚫</div>
          <h1 className="text-4xl font-bold text-red-500 mb-4">Access Denied</h1>
          <p className="text-gray-400 text-lg mb-4">
            Administrator privileges required to access this page.
          </p>
          <p className="text-gray-500 text-sm">
            Current user: {user?.name || user?.email} ({user?.role || 'user'})
          </p>
        </div>
      </div>
    );
  }

  return children;
};

export default ProtectedRoute;