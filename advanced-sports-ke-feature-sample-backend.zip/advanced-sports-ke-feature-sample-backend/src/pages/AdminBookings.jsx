import React, { useState, useEffect, useCallback } from 'react';

const AdminBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [coaches, setCoaches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingBooking, setEditingBooking] = useState(null);
  const [editForm, setEditForm] = useState({
    coachId: '',
    date: '',
    time: ''
  });
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [updating, setUpdating] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  
  // Filter states
  const [filters, setFilters] = useState({
    coach: '',
    dateFrom: '',
    dateTo: '',
    status: ''
  });
  const [filteredBookings, setFilteredBookings] = useState([]);

  // Helper functions for getting coach information
  const getCoachName = useCallback((booking) => {
    // Safety check for coaches array
    const coachesArray = coaches || [];
    
    // Priority 1: Check if coach is assigned at root level (coachId) - admin assignments
    if (booking.coachId && booking.coachId !== null) {
      const coach = coachesArray.find(c => c._id === booking.coachId);
      if (coach) {
        return `${coach.name} (${coach.specialty || 'Admin Assigned'})`;
      } else {
        // Coach was deleted or not found - show as no coach assigned
        return '⚠️ No coach assigned (coach deleted)';
      }
    }
    
    // Priority 2: Check if coach is in tennis.coach (frontend bookings)
    if (booking.tennis?.coach) {
      const coachInfo = booking.tennis.coach;
      return `${coachInfo.name} (${coachInfo.specialty || 'Frontend Assigned'})`;
    }
    
    return 'No coach assigned';
  }, [coaches]);

  const getCoachId = useCallback((booking) => {
    // Safety check for coaches array
    const coachesArray = coaches || [];
    
    // Check if coach is assigned at root level (coachId) - handle null case
    if (booking.coachId && booking.coachId !== null) {
      return booking.coachId;
    }
    
    // Check if coach is in tennis.coach and try to find matching coach by name or id
    if (booking.tennis?.coach) {
      const frontendCoach = booking.tennis.coach;
      // Try to find by id first
      const coach = coachesArray.find(c => c._id === frontendCoach.id);
      if (coach) {
        return coach._id;
      }
      // Try to find by name as fallback
      const coachByName = coachesArray.find(c => c.name === frontendCoach.name);
      if (coachByName) {
        return coachByName._id;
      }
    }
    
    return '';
  }, [coaches]);

  // Initial data fetch
  useEffect(() => {
    fetchBookings();
    fetchCoaches();
  }, []);

  // Filter bookings whenever bookings or filters change
  useEffect(() => {
    let filtered = [...bookings];

    // Filter by coach
    if (filters.coach) {
      filtered = filtered.filter(booking => {
        const coachName = getCoachName(booking);
        const coachId = getCoachId(booking);
        
        if (filters.coach === 'no-coach') {
          return coachName === 'No coach assigned' || coachName.includes('No coach assigned');
        }
        
        return coachId === filters.coach;
      });
    }

    // Filter by date range
    if (filters.dateFrom) {
      filtered = filtered.filter(booking => {
        const bookingDate = new Date(booking.dateTime.date);
        const fromDate = new Date(filters.dateFrom);
        return bookingDate >= fromDate;
      });
    }

    if (filters.dateTo) {
      filtered = filtered.filter(booking => {
        const bookingDate = new Date(booking.dateTime.date);
        const toDate = new Date(filters.dateTo);
        return bookingDate <= toDate;
      });
    }

    // Filter by status
    if (filters.status) {
      filtered = filtered.filter(booking => booking.status === filters.status);
    }

    setFilteredBookings(filtered);
  }, [bookings, filters, coaches, getCoachName, getCoachId]);

  // Listen for coach deletion events to refresh data
  useEffect(() => {
    const handleCoachDeleted = (event) => {
      const { coachName, cleanedBookings } = event.detail;
      
      // Show notification about coach deletion and booking cleanup
      if (cleanedBookings > 0) {
        setSuccessMessage(
          `Coach "${coachName}" deleted. ${cleanedBookings} booking(s) updated to "No coach assigned".`
        );
        setTimeout(() => setSuccessMessage(''), 5000);
      }
      
      // Refresh the data
      setRefreshTrigger(prev => prev + 1);
    };

    window.addEventListener('coachDeleted', handleCoachDeleted);
    
    return () => {
      window.removeEventListener('coachDeleted', handleCoachDeleted);
    };
  }, []);

  // Auto-refresh effect - triggers when refreshTrigger changes or every 2 minutes
  useEffect(() => {
    if (refreshTrigger === 0) return; // Skip the initial trigger

    const refreshData = async () => {
      if (!updating) {
        try {
          await Promise.all([
            fetchBookings(false),
            fetchCoaches()
          ]);
        } catch (err) {
          console.error('Auto-refresh failed:', err);
        }
      }
    };

    refreshData();
  }, [refreshTrigger, updating]);

  // Set up periodic auto-refresh every 2 minutes
  useEffect(() => {
    const autoRefreshInterval = setInterval(() => {
      if (!updating) {
        setRefreshTrigger(prev => prev + 1);
      }
    }, 120000); // 2 minutes
    
    return () => clearInterval(autoRefreshInterval);
  }, [updating]);

  // Refresh when page becomes visible again (user switches back to tab)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (!document.hidden && !updating) {
        setRefreshTrigger(prev => prev + 1);
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [updating]);

  const fetchBookings = async (showLoading = true) => {
    try {
      if (showLoading) setLoading(true);
      
      // Add cache-busting timestamp to ensure fresh data
      const timestamp = new Date().getTime();
      const response = await fetch(`http://localhost:5000/api/bookings?_t=${timestamp}`, {
        credentials: 'include',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await response.json();
      if (result.success) {
        setBookings(result.data);
        setError(''); // Clear any previous errors
        setLastRefresh(new Date());
      } else {
        setError('Failed to fetch bookings: ' + (result.message || 'Unknown error'));
      }
    } catch (err) {
      console.error('Error fetching bookings:', err);
      setError('Error loading bookings: ' + err.message);
    } finally {
      if (showLoading) setLoading(false);
    }
  };

  const fetchCoaches = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/coaches', {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await response.json();
      if (result.success) {
        setCoaches(result.data || []);
      } else {
        console.error('Failed to fetch coaches:', result.message);
        setCoaches([]);
      }
    } catch (err) {
      console.error('Error fetching coaches:', err);
      setCoaches([]);
      // Don't let coach fetching failure break the entire page
      setError('Warning: Could not load coaches list. You may not be able to assign coaches to bookings.');
    }
  };

  const startEdit = (booking) => {
    setEditingBooking(booking._id);
    const coachId = getCoachId(booking);
    setEditForm({
      coachId: coachId || '',
      date: booking.dateTime?.date || '',
      time: booking.dateTime?.time || ''
    });
    setError('');
    setSuccessMessage('');
    setUpdating(false);
  };

  const cancelEdit = () => {
    setEditingBooking(null);
    setEditForm({ coachId: '', date: '', time: '' });
    setError('');
    setUpdating(false);
  };

  const handleInputChange = (field, value) => {
    setEditForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleFilterChange = (field, value) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const clearFilters = () => {
    setFilters({
      coach: '',
      dateFrom: '',
      dateTo: '',
      status: ''
    });
  };

  const saveChanges = async () => {
    setUpdating(true);
    try {
      // Calculate the combined datetime from date and time
      const combinedDateTime = new Date(`${editForm.date}T${editForm.time}:00.000Z`);
      
      const updateData = {
        coachId: editForm.coachId,
        dateTime: {
          date: editForm.date,
          time: editForm.time,
          datetime: combinedDateTime.toISOString()
        }
      };

      const response = await fetch(`http://localhost:5000/api/bookings/${editingBooking}/admin`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(updateData)
      });

      const result = await response.json();
      
      // Check both HTTP status AND result.success
      if (response.ok && result.success) {
        // Verify the coach was actually assigned if coachId was provided
        if (editForm.coachId && result.data && result.data.coachId !== editForm.coachId) {
          setError('Coach assignment may not have been saved properly. Please verify the assignment.');
          return;
        }
        
        setSuccessMessage('Booking updated successfully!');
        setEditingBooking(null);
        setError(''); // Clear any previous errors
        
        // Trigger automatic refresh by updating the trigger
        setRefreshTrigger(prev => prev + 1);
        
        // Clear success message after 3 seconds
        setTimeout(() => setSuccessMessage(''), 3000);
      } else {
        // Handle both HTTP errors and application errors
        const errorMessage = result.message || `HTTP ${response.status}: ${response.statusText}` || 'Failed to update booking';
        setError(errorMessage);
        setSuccessMessage(''); // Clear any previous success messages
        
        console.error('Update failed:', {
          status: response.status,
          statusText: response.statusText,
          result: result
        });
      }
    } catch (err) {
      console.error('Error updating booking:', err);
      setError('Network error: Unable to update booking. Please check your connection and try again.');
      setSuccessMessage(''); // Clear any previous success messages
      
      // Trigger refresh to get latest state even after error
      setRefreshTrigger(prev => prev + 1);
    } finally {
      setUpdating(false);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatTime = (timeString) => {
    const [hours, minutes] = timeString.split(':');
    const date = new Date();
    date.setHours(parseInt(hours), parseInt(minutes));
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p>Loading bookings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-8 pt-24">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-orange-500 mb-2">Admin Bookings Management</h1>
          <p className="text-gray-400">Manage coach assignments and booking times</p>
        </div>

        {/* Filter Section */}
        <div className="mb-6 bg-gray-800 p-4 rounded-lg">
          <div className="flex flex-wrap gap-4 items-end">
            <div className="flex-1 min-w-48">
              <label className="block text-sm font-medium text-gray-300 mb-1">Filter by Coach</label>
              <select
                value={filters.coach}
                onChange={(e) => handleFilterChange('coach', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
              >
                <option value="">All Coaches</option>
                <option value="no-coach">No Coach Assigned</option>
                {Array.isArray(coaches) && coaches.length > 0 && coaches.map(coach => (
                  <option key={coach._id} value={coach._id}>
                    {coach.name} - {coach.specialty}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="flex-1 min-w-36">
              <label className="block text-sm font-medium text-gray-300 mb-1">From Date</label>
              <input
                type="date"
                value={filters.dateFrom}
                onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>
            
            <div className="flex-1 min-w-36">
              <label className="block text-sm font-medium text-gray-300 mb-1">To Date</label>
              <input
                type="date"
                value={filters.dateTo}
                onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>
            
            <div className="flex-1 min-w-32">
              <label className="block text-sm font-medium text-gray-300 mb-1">Status</label>
              <select
                value={filters.status}
                onChange={(e) => handleFilterChange('status', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
              >
                <option value="">All Status</option>
                <option value="confirmed">Confirmed</option>
                <option value="pending">Pending</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={clearFilters}
                className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded text-sm flex items-center gap-1 whitespace-nowrap"
                title="Clear all filters"
              >
                🗑️ Clear
              </button>
            </div>
          </div>
          
          {(filters.coach || filters.dateFrom || filters.dateTo || filters.status) && (
            <div className="mt-3 text-sm text-gray-400">
              <span className="mr-2">Active filters:</span>
              {filters.coach && (
                <span className="inline-block bg-orange-600 text-white px-2 py-1 rounded text-xs mr-1 mb-1">
                  Coach: {filters.coach === 'no-coach' ? 'No Coach' : coaches.find(c => c._id === filters.coach)?.name || 'Unknown'}
                </span>
              )}
              {filters.dateFrom && (
                <span className="inline-block bg-orange-600 text-white px-2 py-1 rounded text-xs mr-1 mb-1">
                  From: {new Date(filters.dateFrom).toLocaleDateString()}
                </span>
              )}
              {filters.dateTo && (
                <span className="inline-block bg-orange-600 text-white px-2 py-1 rounded text-xs mr-1 mb-1">
                  To: {new Date(filters.dateTo).toLocaleDateString()}
                </span>
              )}
              {filters.status && (
                <span className="inline-block bg-orange-600 text-white px-2 py-1 rounded text-xs mr-1 mb-1">
                  Status: {filters.status.charAt(0).toUpperCase() + filters.status.slice(1)}
                </span>
              )}
            </div>
          )}
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-900/30 border border-red-600 rounded text-red-400 text-sm">
            {error}
          </div>
        )}

        {successMessage && (
          <div className="mb-4 p-3 bg-green-900/30 border border-green-600 rounded text-green-400 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-green-400">✅</span>
              {successMessage}
            </div>
          </div>
        )}

        <div className="bg-gray-800 rounded-lg overflow-hidden">
          {/* Results counter */}
          <div className="px-4 py-3 border-b border-gray-700 bg-gray-750">
            <div className="flex justify-between items-center">
              <div className="text-sm text-gray-400">
                Showing {filteredBookings.length} of {bookings.length} bookings
                {filteredBookings.length !== bookings.length && (
                  <span className="ml-2 text-orange-400">(filtered)</span>
                )}
              </div>
              {(filters.coach || filters.dateFrom || filters.dateTo || filters.status) && (
                <button
                  onClick={clearFilters}
                  className="text-xs text-orange-500 hover:text-orange-400 underline"
                >
                  Clear all filters
                </button>
              )}
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-700">
                <tr>
                  <th className="px-4 py-3 text-left">Booking ID</th>
                  <th className="px-4 py-3 text-left">Client</th>
                  <th className="px-4 py-3 text-left">Sport</th>
                  <th className="px-4 py-3 text-left">Date</th>
                  <th className="px-4 py-3 text-left">Time</th>
                  <th className="px-4 py-3 text-left">Coach</th>
                  <th className="px-4 py-3 text-left">Status</th>
                  <th className="px-4 py-3 text-left">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {filteredBookings.map((booking) => (
                  <tr key={booking._id} className="hover:bg-gray-700/50">
                    <td className="px-4 py-3 font-mono text-xs">
                      {booking.confirmationId || booking._id.slice(-8)}
                    </td>
                    <td className="px-4 py-3">
                      <div>
                        <div className="font-medium">{booking.userInfo?.name || 'N/A'}</div>
                        <div className="text-gray-400 text-xs">{booking.userInfo?.email}</div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="capitalize">{booking.sport}</span>
                    </td>
                    <td className="px-4 py-3">
                      {editingBooking === booking._id ? (
                        <input
                          type="date"
                          value={editForm.date}
                          onChange={(e) => handleInputChange('date', e.target.value)}
                          className="bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm w-full"
                        />
                      ) : (
                        <div className="flex items-center gap-1">
                          📅
                          <span>{formatDate(booking.dateTime.date)}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      {editingBooking === booking._id ? (
                        <input
                          type="time"
                          value={editForm.time}
                          onChange={(e) => handleInputChange('time', e.target.value)}
                          className="bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm w-full"
                        />
                      ) : (
                        <div className="flex items-center gap-1">
                          🕒
                          <span>{formatTime(booking.dateTime.time)}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      {editingBooking === booking._id ? (
                        <select
                          value={editForm.coachId || ''}
                          onChange={(e) => handleInputChange('coachId', e.target.value)}
                          className="bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm w-full"
                        >
                          <option value="">No coach assigned</option>
                          {Array.isArray(coaches) && coaches.length > 0 ? (
                            coaches.map(coach => (
                              <option key={coach._id} value={coach._id}>
                                {coach.name} - {coach.specialty}
                              </option>
                            ))
                          ) : (
                            <option disabled>No coaches available</option>
                          )}
                        </select>
                      ) : (
                        <div className="flex items-center gap-1">
                          👤
                          <span>{getCoachName(booking)}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        booking.status === 'confirmed' ? 'bg-green-900/30 text-green-400' :
                        booking.status === 'pending' ? 'bg-yellow-900/30 text-yellow-400' :
                        booking.status === 'cancelled' ? 'bg-red-900/30 text-red-400' :
                        'bg-gray-700 text-gray-300'
                      }`}>
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {editingBooking === booking._id ? (
                        <div className="flex gap-2">
                          <button
                            onClick={saveChanges}
                            disabled={updating}
                            className="bg-green-600 hover:bg-green-700 disabled:bg-green-400 disabled:cursor-not-allowed text-white p-2 rounded text-xs flex items-center gap-1"
                            title="Save changes"
                          >
                            {updating ? '⏳' : '💾'}
                            {updating ? 'Saving...' : 'Save'}
                          </button>
                          <button
                            onClick={cancelEdit}
                            disabled={updating}
                            className="bg-gray-600 hover:bg-gray-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white p-2 rounded text-xs flex items-center gap-1"
                            title="Cancel editing"
                          >
                            ❌
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => startEdit(booking)}
                          className="bg-orange-600 hover:bg-orange-700 text-white p-2 rounded text-xs flex items-center gap-1"
                          title="Edit booking"
                        >
                          ✏️
                          Edit
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {filteredBookings.length === 0 && bookings.length > 0 && (
            <div className="p-8 text-center text-gray-400">
              <div className="mx-auto text-4xl mb-4">🔍</div>
              <p>No bookings match the current filters</p>
              <button
                onClick={clearFilters}
                className="mt-2 text-orange-500 hover:text-orange-400 text-sm underline"
              >
                Clear filters to see all bookings
              </button>
            </div>
          )}
          
          {bookings.length === 0 && (
            <div className="p-8 text-center text-gray-400">
              <div className="mx-auto text-4xl mb-4">📅</div>
              <p>No bookings found</p>
            </div>
          )}
        </div>

          <div className="mt-6 text-sm text-gray-400">
            <p>• Only coach assignment and booking times can be modified</p>
            <p>• Changes are saved immediately and data refreshes automatically</p>
            <p>• Use filters to narrow down bookings by coach, date range, or status</p>
            <p>• This page is only accessible to admin users</p>
            <p>• Last updated: {lastRefresh.toLocaleTimeString()} | Auto-refresh: Every 2 minutes & on tab focus</p>
          </div>
      </div>
    </div>
  );
};

export default AdminBookings;