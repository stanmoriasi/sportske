import mongoose from 'mongoose';

const coachSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Coach name is required'],
    trim: true,
  },
  
  specialty: {
    type: String,
    required: [true, 'Coach specialty is required'],
    trim: true,
  },
  
  rate: {
    type: String,
    required: [true, 'Coach rate is required'],
  },
  
  hourlyRate: {
    type: Number,
    required: true,
    min: 0,
  },
  
  sport: {
    type: String,
    required: true,
    enum: ['tennis', 'football', 'basketball', 'swimming'],
    lowercase: true,
  },
  
  bio: {
    type: String,
    maxlength: 1000,
  },
  
  experience: {
    type: Number, // years of experience
    min: 0,
  },
  
  certifications: [{
    name: String,
    issuedBy: String,
    dateIssued: Date,
    expiryDate: Date,
  }],
  
  availability: {
    // Weekly recurring schedule
    weekly: {
      monday: [String],
      tuesday: [String],
      wednesday: [String],
      thursday: [String],
      friday: [String],
      saturday: [String],
      sunday: [String],
    },
    
    // Date-specific overrides (format: "YYYY-MM-DD")
    dateSpecific: {
      type: Map,
      of: {
        available: {
          type: Boolean,
          default: true
        },
        times: [String] // Available time slots for this specific date
      },
      default: new Map()
    }
  },
  
  contact: {
    email: String,
    phone: String,
  },
  
  image: {
    type: String, // URL to coach's profile picture
  },
  
  rating: {
    average: {
      type: Number,
      default: 0,
      min: 0,
      max: 5,
    },
    totalReviews: {
      type: Number,
      default: 0,
    },
  },
  
  isActive: {
    type: Boolean,
    default: true,
  },
  
  joinedDate: {
    type: Date,
    default: Date.now,
  },
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

// Indexes
coachSchema.index({ sport: 1, isActive: 1 });
coachSchema.index({ 'rating.average': -1 });
coachSchema.index({ name: 'text', specialty: 'text' });

// Virtual for formatted rate display
coachSchema.virtual('formattedRate').get(function() {
  return `+$${this.hourlyRate}/hour`;
});

// Static method to find available coaches for a sport
coachSchema.statics.findBySport = function(sport) {
  return this.find({
    sport: sport.toLowerCase(),
    isActive: true,
  }).sort({ 'rating.average': -1, name: 1 });
};

// Static method to find highly rated coaches
coachSchema.statics.findTopRated = function(limit = 5) {
  return this.find({
    isActive: true,
    'rating.totalReviews': { $gte: 5 },
  })
  .sort({ 'rating.average': -1 })
  .limit(limit);
};

// Instance method to check if coach is available at a specific time
coachSchema.methods.isAvailableAt = function(dayOfWeek, time) {
  const daySchedule = this.availability[dayOfWeek.toLowerCase()];
  return daySchedule && daySchedule.includes(time);
};

// Instance method to update rating
coachSchema.methods.updateRating = function(newRating) {
  const totalRatings = this.rating.average * this.rating.totalReviews;
  this.rating.totalReviews += 1;
  this.rating.average = (totalRatings + newRating) / this.rating.totalReviews;
  
  return this.save();
};

// Pre-remove middleware to handle dependent bookings
coachSchema.pre('remove', async function(next) {
  try {
    // Import Booking model to avoid circular dependency
    const Booking = mongoose.model('Booking');
    
    // Update all bookings that reference this coach
    await Booking.updateMany(
      { coachId: this._id },
      { 
        $unset: { coachId: 1 },
        $set: { updatedAt: new Date() }
      }
    );
    
    console.log(`Removed coach references from bookings for coach: ${this.name}`);
    next();
  } catch (error) {
    next(error);
  }
});

// Pre-findOneAndDelete middleware to handle dependent bookings
coachSchema.pre('findOneAndDelete', async function(next) {
  try {
    // Get the coach document before deletion
    const coach = await this.model.findOne(this.getQuery());
    
    if (coach) {
      // Import Booking model to avoid circular dependency
      const Booking = mongoose.model('Booking');
      
      // Update all bookings that reference this coach
      await Booking.updateMany(
        { coachId: coach._id },
        { 
          $unset: { coachId: 1 },
          $set: { updatedAt: new Date() }
        }
      );
      
      console.log(`Removed coach references from bookings for coach: ${coach.name}`);
    }
    
    next();
  } catch (error) {
    next(error);
  }
});

const Coach = mongoose.model('Coach', coachSchema);

export default Coach;