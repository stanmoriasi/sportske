/**
 * Migration script to remove redundant 'id' field from existing Coach documents
 * Run this after updating the Coach model to remove the id field
 */

import mongoose from 'mongoose';
import Coach from '../models/Coach.js';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

async function cleanupCoachIds() {
  try {
    console.log('🚀 Starting Coach ID cleanup migration...');
    
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    // Check for and drop the old unique index on 'id' field
    try {
      const indexes = await Coach.collection.getIndexes();
      console.log('📋 Current indexes:', Object.keys(indexes));
      
      // Check if there's a unique index on 'id' field
      if (indexes.id_1) {
        console.log('🗑️  Dropping old unique index on "id" field...');
        await Coach.collection.dropIndex('id_1');
        console.log('✅ Old index dropped successfully');
      } else {
        console.log('ℹ️  No old "id" index found to drop');
      }
    } catch (indexError) {
      console.log('ℹ️  Index handling:', indexError.message);
    }

    // Find all coaches that still have the 'id' field
    const coachesWithId = await Coach.find({ id: { $exists: true } });
    console.log(`📊 Found ${coachesWithId.length} coaches with redundant 'id' field`);

    if (coachesWithId.length === 0) {
      console.log('✨ No cleanup needed - all coaches are already up to date!');
      return;
    }

    // Log the coaches that will be updated
    console.log('\n📋 Coaches to be updated:');
    coachesWithId.forEach((coach, index) => {
      console.log(`   ${index + 1}. ${coach.name} (id: ${coach.id})`);
    });

    // Remove the 'id' field from all Coach documents
    const result = await Coach.updateMany(
      { id: { $exists: true } },
      { $unset: { id: 1 } }
    );

    console.log(`\n✅ Migration completed successfully!`);
    console.log(`   - Documents updated: ${result.modifiedCount}`);
    console.log(`   - Documents matched: ${result.matchedCount}`);
    
    if (result.modifiedCount !== result.matchedCount) {
      console.log(`⚠️  Warning: ${result.matchedCount - result.modifiedCount} documents were matched but not modified`);
    }

    // Verify cleanup
    const remainingWithId = await Coach.countDocuments({ id: { $exists: true } });
    if (remainingWithId === 0) {
      console.log('✅ Verification passed: No coaches with redundant ID field remain');
    } else {
      console.log(`❌ Warning: ${remainingWithId} coaches still have the ID field`);
    }

  } catch (error) {
    console.error('❌ Migration failed:', error.message);
    throw error;
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Disconnected from MongoDB');
  }
}

// Run the migration
cleanupCoachIds()
  .then(() => {
    console.log('🎉 Migration completed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('💥 Migration failed:', error);
    process.exit(1);
  });