import express from 'express';
import Sport from '../models/Sport.js';

const router = express.Router();

// GET /api/sports - Get all sports
router.get('/', async (req, res) => {
  try {
    const { active = true } = req.query;
    
    const filter = active === 'true' ? { isActive: true } : {};
    const sports = await Sport.find(filter).sort({ popularityScore: -1, name: 1 });

    res.json({
      success: true,
      data: sports,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching sports',
      error: error.message,
    });
  }
});

// GET /api/sports/:id - Get a specific sport
router.get('/:id', async (req, res) => {
  try {
    const sport = await Sport.findById(req.params.id);
    
    if (!sport) {
      return res.status(404).json({
        success: false,
        message: 'Sport not found',
      });
    }

    res.json({
      success: true,
      data: sport,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching sport',
      error: error.message,
    });
  }
});

// GET /api/sports/name/:name - Get sport by name
router.get('/name/:name', async (req, res) => {
  try {
    const sport = await Sport.findOne({ 
      name: req.params.name.toLowerCase() 
    });
    
    if (!sport) {
      return res.status(404).json({
        success: false,
        message: 'Sport not found',
      });
    }

    res.json({
      success: true,
      data: sport,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching sport',
      error: error.message,
    });
  }
});

// POST /api/sports - Create a new sport (Admin only)
router.post('/', async (req, res) => {
  try {
    const sport = new Sport(req.body);
    await sport.save();

    res.status(201).json({
      success: true,
      message: 'Sport created successfully',
      data: sport,
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors: Object.values(error.errors).map(err => err.message),
      });
    }

    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: 'Sport with this name already exists',
      });
    }

    res.status(500).json({
      success: false,
      message: 'Error creating sport',
      error: error.message,
    });
  }
});

// PUT /api/sports/:id - Update a sport (Admin only)
router.put('/:id', async (req, res) => {
  try {
    const sport = await Sport.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!sport) {
      return res.status(404).json({
        success: false,
        message: 'Sport not found',
      });
    }

    res.json({
      success: true,
      message: 'Sport updated successfully',
      data: sport,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating sport',
      error: error.message,
    });
  }
});

// DELETE /api/sports/:id - Delete a sport (Admin only)
router.delete('/:id', async (req, res) => {
  try {
    const sport = await Sport.findByIdAndDelete(req.params.id);

    if (!sport) {
      return res.status(404).json({
        success: false,
        message: 'Sport not found',
      });
    }

    res.json({
      success: true,
      message: 'Sport deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting sport',
      error: error.message,
    });
  }
});

export default router;