import express from 'express';
import Booking from '../models/Booking.js';
import { validateBooking } from '../middleware/validation.js';
import { sendBookingConfirmation, sendBookingStatusUpdate, sendBookingCancellation, sendCoachBookingNotification } from '../utils/emailService.js';
import Coach from '../models/Coach.js';

const router = express.Router();

// GET /api/bookings - Get all bookings (with pagination and filters)
router.get('/', async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      sport,
      status,
      startDate,
      endDate,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = req.query;

    // Build filter object
    const filter = {};
    if (sport) filter.sport = sport;
    if (status) filter.status = status;
    if (startDate || endDate) {
      filter['dateTime.datetime'] = {};
      if (startDate) filter['dateTime.datetime'].$gte = new Date(startDate);
      if (endDate) filter['dateTime.datetime'].$lte = new Date(endDate);
    }

    // Calculate pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const sortObj = { [sortBy]: sortOrder === 'desc' ? -1 : 1 };

    // Get bookings with pagination
    const bookings = await Booking.find(filter)
      .sort(sortObj)
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    // Get total count for pagination
    const total = await Booking.countDocuments(filter);
    const totalPages = Math.ceil(total / parseInt(limit));

    res.json({
      success: true,
      data: bookings,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        total,
        hasNextPage: parseInt(page) < totalPages,
        hasPrevPage: parseInt(page) > 1,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching bookings',
      error: error.message,
    });
  }
});

// GET /api/bookings/:id - Get a specific booking
router.get('/:id', async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    
    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      });
    }

    res.json({
      success: true,
      data: booking,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching booking',
      error: error.message,
    });
  }
});

// GET /api/bookings/confirmation/:confirmationId - Get booking by confirmation ID
router.get('/confirmation/:confirmationId', async (req, res) => {
  try {
    const booking = await Booking.findOne({ 
      confirmationId: req.params.confirmationId 
    });
    
    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      });
    }

    res.json({
      success: true,
      data: booking,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching booking',
      error: error.message,
    });
  }
});

// POST /api/bookings - Create a new booking
router.post('/', validateBooking, async (req, res) => {
  try {
    // Generate confirmation ID if not provided
    if (!req.body.confirmationId) {
      req.body.confirmationId = `CONF-${Date.now()}`;
    }

    // Generate session ID if not provided
    if (!req.body.sessionId) {
      req.body.sessionId = `booking_${Date.now()}`;
    }

    // Calculate pricing
    const baseCost = 20; // Default base cost
    let extrasCost = 0;
    
    if (req.body.tennis && req.body.tennis.extras) {
      extrasCost = (req.body.tennis.extras.rackets * 5) + (req.body.tennis.extras.courts * 15);
    }

    req.body.pricing = {
      baseCost,
      extrasCost,
      totalCost: baseCost + extrasCost,
    };

    // Create the booking
    const booking = new Booking(req.body);
    await booking.save();

    // Send confirmation email (if email is provided)
    let emailSent = false;
    let coachEmailSent = false;
    
    if (req.body.userInfo && req.body.userInfo.email) {
      try {
        await sendBookingConfirmation(req.body.userInfo.email, booking);
        emailSent = true;
      } catch (emailError) {
        console.error('Email sending failed:', emailError);
        // Don't fail the booking if email fails
      }
    }

    // Send notification email to coach
    if (req.body.coachId) {
      try {
        const coach = await Coach.findById(req.body.coachId);
        if (coach && coach.email) {
          await sendCoachBookingNotification(coach.email, booking, {
            name: coach.name,
            specialization: coach.specialization
          });
          coachEmailSent = true;
        }
      } catch (coachEmailError) {
        console.error('Coach email notification failed:', coachEmailError);
        // Don't fail the booking if email fails
      }
    }

    res.status(201).json({
      success: true,
      message: 'Booking created successfully',
      data: booking,
      emailSent: emailSent,
      coachEmailSent: coachEmailSent,
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors: Object.values(error.errors).map(err => err.message),
      });
    }

    res.status(500).json({
      success: false,
      message: 'Error creating booking',
      error: error.message,
    });
  }
});

// PUT /api/bookings/:id - Update a booking
router.put('/:id', validateBooking, async (req, res) => {
  try {
    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      });
    }

    res.json({
      success: true,
      message: 'Booking updated successfully',
      data: booking,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating booking',
      error: error.message,
    });
  }
});

// PATCH /api/bookings/:id/admin - Update booking (admin only - coach and time fields)
router.patch('/:id/admin', async (req, res) => {
  try {
    const { coachId, dateTime } = req.body;
    
    // Build update object with only allowed admin fields
    const updateData = {};
    if (coachId !== undefined) {
      // Handle empty string by setting to null (removes coach assignment)
      updateData.coachId = coachId === "" ? null : coachId;
    }
    if (dateTime !== undefined) {
      updateData.dateTime = dateTime;
    }

    if (Object.keys(updateData).length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields to update. Only coachId and dateTime are allowed.',
      });
    }

    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true, runValidators: true }
    );

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      });
    }

    res.json({
      success: true,
      message: 'Booking updated successfully',
      data: booking,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating booking',
      error: error.message,
    });
  }
});

// PATCH /api/bookings/:id/status - Update booking status
router.patch('/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    
    if (!status || !['pending', 'confirmed', 'cancelled', 'completed'].includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Must be: pending, confirmed, cancelled, or completed',
      });
    }

    // Get the booking first to check old status and email
    const oldBooking = await Booking.findById(req.params.id);
    if (!oldBooking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      });
    }

    const oldStatus = oldBooking.status;

    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true, runValidators: true }
    );

    // Send email notification for status change (if email is provided)
    if (booking.userInfo && booking.userInfo.email && oldStatus !== status) {
      try {
        if (status === 'cancelled') {
          await sendBookingCancellation(booking.userInfo.email, booking);
        } else {
          await sendBookingStatusUpdate(booking.userInfo.email, booking, oldStatus, status);
        }
      } catch (emailError) {
        console.error('Email sending failed:', emailError);
        // Don't fail the status update if email fails
      }
    }

    res.json({
      success: true,
      message: `Booking ${status} successfully`,
      data: booking,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating booking status',
      error: error.message,
    });
  }
});

// DELETE /api/bookings/:id - Delete a booking
router.delete('/:id', async (req, res) => {
  try {
    const booking = await Booking.findByIdAndDelete(req.params.id);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      });
    }

    res.json({
      success: true,
      message: 'Booking deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting booking',
      error: error.message,
    });
  }
});

// GET /api/bookings/stats/overview - Get booking statistics
router.get('/stats/overview', async (req, res) => {
  try {
    const stats = await Booking.aggregate([
      {
        $group: {
          _id: null,
          totalBookings: { $sum: 1 },
          confirmedBookings: {
            $sum: { $cond: [{ $eq: ['$status', 'confirmed'] }, 1, 0] }
          },
          pendingBookings: {
            $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] }
          },
          cancelledBookings: {
            $sum: { $cond: [{ $eq: ['$status', 'cancelled'] }, 1, 0] }
          },
          totalRevenue: { $sum: '$pricing.totalCost' },
        }
      }
    ]);

    const sportStats = await Booking.aggregate([
      {
        $group: {
          _id: '$sport',
          count: { $sum: 1 },
          revenue: { $sum: '$pricing.totalCost' },
        }
      },
      { $sort: { count: -1 } }
    ]);

    res.json({
      success: true,
      data: {
        overview: stats[0] || {
          totalBookings: 0,
          confirmedBookings: 0,
          pendingBookings: 0,
          cancelledBookings: 0,
          totalRevenue: 0,
        },
        sportStats,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching booking statistics',
      error: error.message,
    });
  }
});

// POST /api/bookings/:id/send-reminder - Send booking reminder email
router.post('/:id/send-reminder', async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    
    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      });
    }

    if (!booking.userInfo || !booking.userInfo.email) {
      return res.status(400).json({
        success: false,
        message: 'No email address found for this booking',
      });
    }

    // Import the sendBookingReminder function
    const { sendBookingReminder } = await import('../utils/emailService.js');
    
    await sendBookingReminder(booking.userInfo.email, booking);

    res.json({
      success: true,
      message: 'Reminder email sent successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error sending reminder email',
      error: error.message,
    });
  }
});

// POST /api/bookings/:id/resend-confirmation - Resend booking confirmation email
router.post('/:id/resend-confirmation', async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    
    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      });
    }

    if (!booking.userInfo || !booking.userInfo.email) {
      return res.status(400).json({
        success: false,
        message: 'No email address found for this booking',
      });
    }

    await sendBookingConfirmation(booking.userInfo.email, booking);

    res.json({
      success: true,
      message: 'Confirmation email sent successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error sending confirmation email',
      error: error.message,
    });
  }
});

// GET /api/bookings/reminders/due - Get bookings that need reminder emails (24 hours before)
router.get('/reminders/due', async (req, res) => {
  try {
    // Calculate tomorrow's date
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowDateString = tomorrow.toISOString().split('T')[0];

    // Find confirmed bookings for tomorrow that have email addresses
    const bookings = await Booking.find({
      'dateTime.date': tomorrowDateString,
      status: 'confirmed',
      'userInfo.email': { $exists: true, $ne: '' }
    });

    res.json({
      success: true,
      data: bookings,
      message: `Found ${bookings.length} bookings that need reminder emails`,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching bookings for reminders',
      error: error.message,
    });
  }
});

// POST /api/bookings/:id/notify-coach - Send notification email to coach
router.post('/:id/notify-coach', async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      });
    }

    if (!booking.coachId) {
      return res.status(400).json({
        success: false,
        message: 'No coach assigned to this booking',
      });
    }

    // Find the coach
    const coach = await Coach.findById(booking.coachId);
    if (!coach) {
      return res.status(404).json({
        success: false,
        message: 'Coach not found',
      });
    }

    if (!coach.email) {
      return res.status(400).json({
        success: false,
        message: 'Coach does not have an email address',
      });
    }

    // Send the coach notification
    await sendCoachBookingNotification(coach.email, booking, {
      name: coach.name,
      specialization: coach.specialization
    });

    res.json({
      success: true,
      message: `Coach notification sent successfully to ${coach.email}`,
      coachInfo: {
        name: coach.name,
        email: coach.email,
        specialization: coach.specialization
      }
    });
  } catch (error) {
    console.error('Error sending coach notification:', error);
    res.status(500).json({
      success: false,
      message: 'Error sending coach notification email',
      error: error.message,
    });
  }
});

export default router;