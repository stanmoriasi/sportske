import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Booking from '../models/Booking.js';
import { sendBookingReminder } from '../utils/emailService.js';

// Load environment variables
dotenv.config();

const sendReminderEmails = async () => {
  try {
    console.log('🚀 Starting reminder email job...');
    
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    // Calculate tomorrow's date
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowDateString = tomorrow.toISOString().split('T')[0];

    console.log(`📅 Looking for bookings on: ${tomorrowDateString}`);

    // Find confirmed bookings for tomorrow that have email addresses
    const bookings = await Booking.find({
      'dateTime.date': tomorrowDateString,
      status: 'confirmed',
      'userInfo.email': { $exists: true, $ne: '' }
    });

    console.log(`📊 Found ${bookings.length} bookings that need reminder emails`);

    if (bookings.length === 0) {
      console.log('ℹ️  No reminder emails to send today');
      return;
    }

    let successCount = 0;
    let errorCount = 0;

    // Send reminder emails
    for (const booking of bookings) {
      try {
        console.log(`📧 Sending reminder to ${booking.userInfo.email} for booking ${booking.confirmationId}`);
        
        await sendBookingReminder(booking.userInfo.email, booking);
        successCount++;
        
        // Add a small delay to avoid overwhelming the email server
        await new Promise(resolve => setTimeout(resolve, 1000));
        
      } catch (error) {
        console.error(`❌ Failed to send reminder for booking ${booking.confirmationId}:`, error.message);
        errorCount++;
      }
    }

    console.log('📈 Reminder email job completed:');
    console.log(`   ✅ Successful emails: ${successCount}`);
    console.log(`   ❌ Failed emails: ${errorCount}`);
    console.log(`   📊 Total processed: ${bookings.length}`);

  } catch (error) {
    console.error('💥 Error in reminder email job:', error);
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Disconnected from MongoDB');
  }
};

// Run if called directly
if (process.argv[1] === new URL(import.meta.url).pathname) {
  sendReminderEmails().then(() => {
    console.log('🎉 Reminder email job finished');
    process.exit(0);
  }).catch((error) => {
    console.error('💥 Reminder email job failed:', error);
    process.exit(1);
  });
}

export default sendReminderEmails;