import mongoose from 'mongoose';

const pageVisitSchema = new mongoose.Schema({
  path: {
    type: String,
    required: true,
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  method: {
    type: String,
    default: 'GET',
  },
  referrer: {
    type: String,
    default: '',
  },
  duration: {
    type: Number, // Time spent on page in seconds
    default: 0,
  }
}, { _id: false });

const userSessionSchema = new mongoose.Schema({
  sessionId: {
    type: String,
    required: true,
    unique: true,
    index: true,
  },
  
  ipAddress: {
    type: String,
    required: true,
  },
  
  userAgent: {
    type: String,
    required: true,
  },
  
  // Parsed user agent information
  browser: {
    name: String,
    version: String,
    major: String,
  },
  
  os: {
    name: String,
    version: String,
  },
  
  device: {
    type: String,
    enum: ['desktop', 'mobile', 'tablet', 'unknown'],
    default: 'unknown',
  },
  
  // Geographic information (if available)
  location: {
    country: String,
    region: String,
    city: String,
    timezone: String,
  },
  
  // Session metadata
  startTime: {
    type: Date,
    default: Date.now,
  },
  
  lastActivity: {
    type: Date,
    default: Date.now,
  },
  
  endTime: {
    type: Date,
  },
  
  duration: {
    type: Number, // Session duration in minutes
    default: 0,
  },
  
  isActive: {
    type: Boolean,
    default: true,
  },
  
  // Pages visited during this session
  pagesVisited: [pageVisitSchema],
  
  // Session statistics
  totalPages: {
    type: Number,
    default: 0,
  },
  
  uniquePages: {
    type: Number,
    default: 0,
  },
  
  // User identification (if logged in)
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    sparse: true,
  },
  
  userEmail: {
    type: String,
    sparse: true,
  },
  
  // Landing and exit pages
  landingPage: {
    type: String,
  },
  
  exitPage: {
    type: String,
  },
  
  // Additional tracking data
  utmSource: String,
  utmMedium: String,
  utmCampaign: String,
  utmTerm: String,
  utmContent: String,
  
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

// Indexes for better query performance
userSessionSchema.index({ ipAddress: 1, startTime: -1 });
userSessionSchema.index({ userId: 1, startTime: -1 });
userSessionSchema.index({ startTime: -1 });
userSessionSchema.index({ lastActivity: -1 });
userSessionSchema.index({ isActive: 1, lastActivity: -1 });
userSessionSchema.index({ 'browser.name': 1 });
userSessionSchema.index({ 'os.name': 1 });
userSessionSchema.index({ device: 1 });

// Virtual for session duration in human readable format
userSessionSchema.virtual('formattedDuration').get(function() {
  if (this.duration < 60) {
    return `${this.duration} minutes`;
  }
  const hours = Math.floor(this.duration / 60);
  const minutes = this.duration % 60;
  return `${hours}h ${minutes}m`;
});

// Virtual for bounce rate (single page visit)
userSessionSchema.virtual('isBounce').get(function() {
  return this.totalPages <= 1;
});

// Static method to get active sessions
userSessionSchema.statics.getActiveSessions = function() {
  return this.find({
    isActive: true,
    lastActivity: { $gte: new Date(Date.now() - 30 * 60 * 1000) } // Last 30 minutes
  });
};

// Static method to get sessions by date range
userSessionSchema.statics.getSessionsByDateRange = function(startDate, endDate) {
  return this.find({
    startTime: {
      $gte: new Date(startDate),
      $lte: new Date(endDate)
    }
  }).sort({ startTime: -1 });
};

// Static method to get popular pages
userSessionSchema.statics.getPopularPages = function(limit = 10) {
  return this.aggregate([
    { $unwind: '$pagesVisited' },
    { $group: {
        _id: '$pagesVisited.path',
        visits: { $sum: 1 },
        uniqueVisitors: { $addToSet: '$sessionId' },
        avgDuration: { $avg: '$pagesVisited.duration' }
      }
    },
    { $addFields: {
        uniqueVisitors: { $size: '$uniqueVisitors' }
      }
    },
    { $sort: { visits: -1 } },
    { $limit: limit }
  ]);
};

// Instance method to add page visit
userSessionSchema.methods.addPageVisit = function(path, method = 'GET', referrer = '', duration = 0) {
  // Add the page visit
  this.pagesVisited.push({
    path,
    method,
    referrer,
    duration,
    timestamp: new Date()
  });
  
  // Update session metadata
  this.lastActivity = new Date();
  this.totalPages = this.pagesVisited.length;
  
  // Calculate unique pages
  const uniquePaths = [...new Set(this.pagesVisited.map(visit => visit.path))];
  this.uniquePages = uniquePaths.length;
  
  // Set landing page if this is the first visit
  if (this.totalPages === 1) {
    this.landingPage = path;
  }
  
  // Update exit page (last page visited)
  this.exitPage = path;
  
  return this.save();
};

// Instance method to end session
userSessionSchema.methods.endSession = function() {
  this.isActive = false;
  this.endTime = new Date();
  
  // Calculate session duration in minutes
  if (this.startTime && this.endTime) {
    this.duration = Math.round((this.endTime - this.startTime) / (1000 * 60));
  }
  
  return this.save();
};

// Pre-save middleware to update duration for active sessions
userSessionSchema.pre('save', function(next) {
  if (this.isActive && this.startTime && this.lastActivity) {
    this.duration = Math.round((this.lastActivity - this.startTime) / (1000 * 60));
  }
  next();
});

// Auto-expire old sessions (older than 24 hours without activity)
userSessionSchema.statics.cleanupOldSessions = async function() {
  const cutoffDate = new Date(Date.now() - 24 * 60 * 60 * 1000); // 24 hours ago
  
  const result = await this.updateMany(
    {
      isActive: true,
      lastActivity: { $lt: cutoffDate }
    },
    {
      $set: {
        isActive: false,
        endTime: new Date()
      }
    }
  );
  
  return result;
};

const UserSession = mongoose.model('UserSession', userSessionSchema);

export default UserSession;