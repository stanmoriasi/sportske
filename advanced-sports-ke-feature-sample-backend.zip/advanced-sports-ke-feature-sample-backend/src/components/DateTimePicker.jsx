import { useState, useEffect } from 'react';

const DateTimePicker = ({ 
  onDateTimeChange, 
  selectedDate = '', 
  selectedTime = '', 
  minDate = new Date().toISOString().split('T')[0],
  availableTimes = [
    '06:00', '07:00', '08:00', '09:00', '10:00', '11:00',
    '12:00', '13:00', '14:00', '15:00', '16:00', '17:00',
    '18:00', '19:00', '20:00', '21:00', '22:00'
  ],
  coachAvailability = null,
  selectedCoach = null,
  className = '',
  label = 'Select Date & Time'
}) => {
  const [localDate, setLocalDate] = useState(selectedDate);
  const [localTime, setLocalTime] = useState(selectedTime);

  // Get available times based on coach availability and selected date
  const getAvailableTimesForDate = (dateString) => {
    if (!dateString || !selectedCoach || !coachAvailability) {
      return availableTimes;
    }

    // Check for date-specific overrides first
    if (coachAvailability.dateSpecific && coachAvailability.dateSpecific[dateString]) {
      const dateConfig = coachAvailability.dateSpecific[dateString];
      
      // If the date is marked as unavailable, return empty array
      if (dateConfig.available === false) {
        return [];
      }
      
      // If custom times are set for this date, use them
      if (dateConfig.times && dateConfig.times.length > 0) {
        return availableTimes.filter(time => dateConfig.times.includes(time));
      }
    }

    // Fall back to weekly schedule
    const date = new Date(dateString);
    const dayName = date.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
    
    // Handle both old structure (direct availability) and new structure (availability.weekly)
    const weeklySchedule = coachAvailability.weekly || coachAvailability;
    const coachAvailableSlots = weeklySchedule[dayName] || [];

    // Filter general available times by coach's available slots
    return availableTimes.filter(time => {
      return coachAvailableSlots.includes(time);
    });
  };

  const currentAvailableTimes = getAvailableTimesForDate(localDate);

  // Effect to handle when coach selection changes and clear invalid times
  useEffect(() => {
    if (localDate && localTime && selectedCoach && coachAvailability) {
      // Use the same logic as getAvailableTimesForDate
      let availableForCurrentDate;
      
      // Check for date-specific overrides first
      if (coachAvailability.dateSpecific && coachAvailability.dateSpecific[localDate]) {
        const dateConfig = coachAvailability.dateSpecific[localDate];
        
        if (dateConfig.available === false) {
          availableForCurrentDate = [];
        } else if (dateConfig.times && dateConfig.times.length > 0) {
          availableForCurrentDate = availableTimes.filter(time => dateConfig.times.includes(time));
        } else {
          availableForCurrentDate = [];
        }
      } else {
        // Fall back to weekly schedule
        const date = new Date(localDate);
        const dayName = date.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
        const weeklySchedule = coachAvailability.weekly || coachAvailability;
        const coachAvailableSlots = weeklySchedule[dayName] || [];
        availableForCurrentDate = availableTimes.filter(time => coachAvailableSlots.includes(time));
      }
      
      // If current time is not available with the selected coach, clear it
      if (!availableForCurrentDate.includes(localTime)) {
        setLocalTime('');
        if (onDateTimeChange) {
          onDateTimeChange({
            date: localDate,
            time: '',
            datetime: null
          });
        }
      }
    }
  }, [selectedCoach, coachAvailability, localDate, localTime, onDateTimeChange, availableTimes]);

  const handleDateChange = (e) => {
    const newDate = e.target.value;
    setLocalDate(newDate);
    
    // Check if current time is still available for the new date with selected coach
    const availableForNewDate = getAvailableTimesForDate(newDate);
    let newTime = localTime;
    
    // If current time is not available for the new date, clear it
    if (localTime && !availableForNewDate.includes(localTime)) {
      newTime = '';
      setLocalTime('');
    }
    
    if (onDateTimeChange) {
      onDateTimeChange({
        date: newDate,
        time: newTime,
        datetime: newDate && newTime ? `${newDate}T${newTime}` : null
      });
    }
  };

  const handleTimeChange = (e) => {
    const newTime = e.target.value;
    setLocalTime(newTime);
    
    if (onDateTimeChange) {
      onDateTimeChange({
        date: localDate,
        time: newTime,
        datetime: localDate && newTime ? `${localDate}T${newTime}` : null
      });
    }
  };

  const formatDateForDisplay = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTimeForDisplay = (timeString) => {
    if (!timeString) return '';
    const [hours, minutes] = timeString.split(':');
    const date = new Date();
    date.setHours(parseInt(hours), parseInt(minutes));
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {label && (
        <h3 className="text-xl font-semibold text-orange-500 mb-4">{label}</h3>
      )}
      
      {/* Date Selection */}
      <div className="space-y-3">
        <label className="block text-lg font-medium text-white">
          Select Date
        </label>
        <input
          type="date"
          value={localDate}
          min={minDate}
          onChange={handleDateChange}
          className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white text-lg 
                   focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 
                   cursor-pointer [&::-webkit-calendar-picker-indicator]:invert 
                   [&::-webkit-calendar-picker-indicator]:opacity-70 
                   [&::-webkit-calendar-picker-indicator]:hover:opacity-100"
        />
        {localDate && (
          <p className="text-sm text-gray-400 mt-1">
            📅 {formatDateForDisplay(localDate)}
          </p>
        )}
      </div>

      {/* Time Selection */}
      <div className="space-y-3">
        <label className="block text-lg font-medium text-white">
          Select Time
          {selectedCoach && (
            <span className="text-sm text-orange-400 ml-2">
              (Showing {selectedCoach.name}'s availability)
            </span>
          )}
        </label>
        <select
          value={localTime}
          onChange={handleTimeChange}
          disabled={!localDate}
          className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white text-lg 
                   focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 
                   cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <option value="">
            {!localDate 
              ? 'Please select a date first'
              : currentAvailableTimes.length === 0 
                ? 'No available times for this date'
                : 'Select a time...'
            }
          </option>
          {currentAvailableTimes.map((time) => (
            <option key={time} value={time}>
              {formatTimeForDisplay(time)}
            </option>
          ))}
        </select>
        {localTime && (
          <p className="text-sm text-gray-400 mt-1">
            🕐 {formatTimeForDisplay(localTime)}
          </p>
        )}
        
        {/* Coach Availability Info */}
        {selectedCoach && coachAvailability && localDate && (
          <div className="mt-3 p-3 bg-gray-700 rounded-lg border border-orange-500/30">
            <div className="text-sm">
              <div className="flex items-center gap-2 mb-2">
                <p className="text-orange-400 font-semibold">Coach Availability for {
                  new Date(localDate).toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })
                }:</p>
                {coachAvailability.dateSpecific && coachAvailability.dateSpecific[localDate] && (
                  <span className="px-2 py-1 bg-blue-900/30 text-blue-400 rounded text-xs">
                    {coachAvailability.dateSpecific[localDate].available === false ? 'Override: Unavailable' : 'Override: Custom'}
                  </span>
                )}
              </div>
              {currentAvailableTimes.length > 0 ? (
                <div className="grid grid-cols-4 gap-2">
                  {currentAvailableTimes.map((time) => (
                    <span 
                      key={time} 
                      className={`text-xs px-2 py-1 rounded ${
                        time === localTime 
                          ? 'bg-orange-500 text-white' 
                          : 'bg-gray-600 text-gray-300'
                      }`}
                    >
                      {formatTimeForDisplay(time)}
                    </span>
                  ))}
                </div>
              ) : (
                <div>
                  <p className="text-red-400 text-sm">Coach not available on this day</p>
                  {coachAvailability.dateSpecific && coachAvailability.dateSpecific[localDate] && coachAvailability.dateSpecific[localDate].available === false && (
                    <p className="text-xs text-gray-500 mt-1">This date has been specifically marked as unavailable</p>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Selected DateTime Summary */}
      {localDate && localTime && (
        <div className="mt-6 p-4 bg-gray-800 border border-orange-500 rounded-lg">
          <h4 className="text-lg font-semibold text-orange-500 mb-2">
            Selected Appointment
          </h4>
          <div className="space-y-1 text-gray-300">
            <p>📅 <span className="font-medium">{formatDateForDisplay(localDate)}</span></p>
            <p>🕐 <span className="font-medium">{formatTimeForDisplay(localTime)}</span></p>
          </div>
        </div>
      )}
    </div>
  );
};

export default DateTimePicker;