import mongoose from 'mongoose';

const bookingSchema = new mongoose.Schema({
  // Basic booking information
  sport: {
    type: String,
    required: [true, 'Sport is required'],
    enum: ['football', 'basketball', 'tennis', 'swimming'],
    lowercase: true,
  },
  
  // Date and time information
  dateTime: {
    date: {
      type: String,
      required: [true, 'Date is required'],
    },
    time: {
      type: String,
      required: [true, 'Time is required'],
    },
    datetime: {
      type: Date,
      required: [true, 'Full datetime is required'],
    },
  },

  // Booking status and IDs
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'cancelled', 'completed'],
    default: 'pending',
  },
  
  confirmationId: {
    type: String,
    unique: true,
    required: true,
  },
  
  sessionId: {
    type: String,
    required: true,
  },

  // User information (for future user authentication)
  userInfo: {
    name: String,
    email: String,
    phone: String,
  },

  // Coach assignment (for admin management)
  coachId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Coach',
  },

  // Tennis-specific information
  tennis: {
    coach: {
      id: String,
      name: String,
      specialty: String,
      rate: String,
    },
    extras: {
      rackets: {
        type: Number,
        default: 0,
        min: 0,
      },
      courts: {
        type: Number,
        default: 0,
        min: 0,
      },
    },
    totalExtrasCost: {
      type: Number,
      default: 0,
      min: 0,
    },
  },

  // Pricing information
  pricing: {
    baseCost: {
      type: Number,
      required: true,
      default: 20,
    },
    extrasCost: {
      type: Number,
      default: 0,
    },
    totalCost: {
      type: Number,
      required: true,
    },
  },

  // Additional notes
  notes: {
    type: String,
    maxlength: 500,
  },

  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now,
  },
  
  updatedAt: {
    type: Date,
    default: Date.now,
  },
  
  confirmedAt: Date,
  cancelledAt: Date,
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

// Indexes for better query performance
bookingSchema.index({ sport: 1, 'dateTime.date': 1 });
bookingSchema.index({ status: 1 });
bookingSchema.index({ createdAt: -1 });

// Virtual for formatted date
bookingSchema.virtual('formattedDate').get(function() {
  if (this.dateTime && this.dateTime.datetime) {
    return new Date(this.dateTime.datetime).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }
  return null;
});

// Virtual for formatted time
bookingSchema.virtual('formattedTime').get(function() {
  if (this.dateTime && this.dateTime.time) {
    const [hours, minutes] = this.dateTime.time.split(':');
    const date = new Date();
    date.setHours(parseInt(hours), parseInt(minutes));
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  }
  return null;
});

// Pre-save middleware to update timestamps
bookingSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  
  // Calculate total cost
  if (this.pricing) {
    this.pricing.totalCost = this.pricing.baseCost + (this.pricing.extrasCost || 0);
  }
  
  // Set confirmed timestamp when status changes to confirmed
  if (this.status === 'confirmed' && !this.confirmedAt) {
    this.confirmedAt = new Date();
  }
  
  // Set cancelled timestamp when status changes to cancelled
  if (this.status === 'cancelled' && !this.cancelledAt) {
    this.cancelledAt = new Date();
  }
  
  next();
});

// Static method to find bookings by date range
bookingSchema.statics.findByDateRange = function(startDate, endDate) {
  return this.find({
    'dateTime.datetime': {
      $gte: new Date(startDate),
      $lte: new Date(endDate),
    },
  });
};

// Static method to find available slots
bookingSchema.statics.findAvailableSlots = function(sport, date) {
  return this.find({
    sport,
    'dateTime.date': date,
    status: { $in: ['confirmed', 'pending'] },
  }).select('dateTime.time');
};

// Instance method to check if booking can be cancelled
bookingSchema.methods.canBeCancelled = function() {
  const bookingDateTime = new Date(this.dateTime.datetime);
  const now = new Date();
  const hoursUntilBooking = (bookingDateTime - now) / (1000 * 60 * 60);
  
  return hoursUntilBooking > 24 && this.status === 'confirmed';
};

const Booking = mongoose.model('Booking', bookingSchema);

export default Booking;