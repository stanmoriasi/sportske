import { useState, useEffect, useCallback } from 'react';
import { BiEdit, BiTrash, BiPlus, BiSave, BiX } from 'react-icons/bi';
import CoachNotificationModal from './CoachNotificationModal';

const CoachManagement = () => {
  const [coaches, setCoaches] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingCoach, setEditingCoach] = useState(null);
  const [notification, setNotification] = useState({
    isOpen: false,
    type: '',
    coachName: '',
    operation: '',
    message: '',
    confirmAction: null,
    isConfirmModal: false
  });
  const [formData, setFormData] = useState({
    name: '',
    specialty: '',
    rate: '',
    hourlyRate: 0,
    sport: 'tennis',
    bio: '',
    experience: 0,
    email: '',
    phone: '',
    isActive: true,
    availability: {
      weekly: {
        monday: [],
        tuesday: [],
        wednesday: [],
        thursday: [],
        friday: [],
        saturday: [],
        sunday: []
      },
      dateSpecific: {} // Format: { "2025-12-25": { available: false }, "2025-12-24": { times: ["10:00", "11:00"] } }
    }
  });

  // Helper function to show notification
  const showNotification = useCallback((type, coachName, operation, message) => {
    setNotification({
      isOpen: true,
      type,
      coachName,
      operation,
      message,
      confirmAction: null,
      isConfirmModal: false
    });
  }, []);

  // Helper function to show confirmation modal
  const showConfirmation = useCallback((coachName, confirmAction) => {
    setNotification({
      isOpen: true,
      type: 'delete',
      coachName,
      operation: '',
      message: '',
      confirmAction,
      isConfirmModal: true
    });
  }, []);

  // Close notification modal
  const closeNotification = useCallback(() => {
    setNotification(prev => ({
      ...prev,
      isOpen: false
    }));
  }, []);

  // Fetch all coaches
  const fetchCoaches = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch('http://localhost:5000/api/coaches');
      if (response.ok) {
        const result = await response.json();
        setCoaches(result.data || []);
      } else {
        console.error('Failed to fetch coaches');
        showNotification('error', '', '', 'Failed to fetch coaches. Please try again.');
      }
    } catch (error) {
      console.error('Error fetching coaches:', error);
      showNotification('error', '', '', 'Network error while fetching coaches. Please check your connection.');
    } finally {
      setLoading(false);
    }
  }, [showNotification]);

  // Load coaches on component mount
  useEffect(() => {
    fetchCoaches();
  }, [fetchCoaches]);

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : type === 'number' ? parseFloat(value) || 0 : value
    }));
  };

  // Handle weekly availability changes
  const handleWeeklyAvailabilityChange = (day, timeSlot) => {
    setFormData(prev => ({
      ...prev,
      availability: {
        ...prev.availability,
        weekly: {
          ...prev.availability.weekly,
          [day]: prev.availability.weekly[day].includes(timeSlot)
            ? prev.availability.weekly[day].filter(t => t !== timeSlot)
            : [...prev.availability.weekly[day], timeSlot].sort()
        }
      }
    }));
  };

  // Handle date-specific availability changes
  const handleDateSpecificChange = (date, timeSlots, isAvailable = true) => {
    setFormData(prev => ({
      ...prev,
      availability: {
        ...prev.availability,
        dateSpecific: {
          ...prev.availability.dateSpecific,
          [date]: isAvailable 
            ? { times: timeSlots, available: true }
            : { available: false }
        }
      }
    }));
  };

  // Remove date-specific override
  const removeDateSpecific = (date) => {
    setFormData(prev => {
      const newDateSpecific = { ...prev.availability.dateSpecific };
      delete newDateSpecific[date];
      return {
        ...prev,
        availability: {
          ...prev.availability,
          dateSpecific: newDateSpecific
        }
      };
    });
  };

  // Available time slots
  const timeSlots = [
    '06:00', '07:00', '08:00', '09:00', '10:00', '11:00',
    '12:00', '13:00', '14:00', '15:00', '16:00', '17:00',
    '18:00', '19:00', '20:00', '21:00', '22:00'
  ];

  const daysOfWeek = [
    { key: 'monday', label: 'Monday' },
    { key: 'tuesday', label: 'Tuesday' },
    { key: 'wednesday', label: 'Wednesday' },
    { key: 'thursday', label: 'Thursday' },
    { key: 'friday', label: 'Friday' },
    { key: 'saturday', label: 'Saturday' },
    { key: 'sunday', label: 'Sunday' }
  ];

  // Reset form
  const resetForm = () => {
    setFormData({
      name: '',
      specialty: '',
      rate: '',
      hourlyRate: 0,
      sport: 'tennis',
      bio: '',
      experience: 0,
      email: '',
      phone: '',
      isActive: true,
      availability: {
        weekly: {
          monday: [],
          tuesday: [],
          wednesday: [],
          thursday: [],
          friday: [],
          saturday: [],
          sunday: []
        },
        dateSpecific: {}
      }
    });
    setEditingCoach(null);
    setShowAddForm(false);
  };

  // Handle create/update coach
  const handleSaveCoach = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name || !formData.specialty || (!formData.rate && formData.hourlyRate <= 0)) {
      showNotification('error', '', '', 'Please fill in all required fields (Name, Specialty, and Rate/Hourly Rate)');
      return;
    }

    // Structure data properly (MongoDB will generate _id automatically)
    const hourlyRate = formData.hourlyRate || 0;
    const coachData = {
      name: formData.name,
      specialty: formData.specialty,
      rate: formData.rate || `+$${hourlyRate}/hour`,
      hourlyRate: hourlyRate,
      sport: formData.sport,
      bio: formData.bio || '',
      experience: formData.experience || 0,
      availability: formData.availability,
      contact: {
        email: formData.email || '',
        phone: formData.phone || ''
      },
      isActive: formData.isActive !== undefined ? formData.isActive : true
    };

    setLoading(true);
    try {
      const url = editingCoach 
        ? `http://localhost:5000/api/coaches/${editingCoach._id}` 
        : 'http://localhost:5000/api/coaches';
      
      const method = editingCoach ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(coachData)
      });

      if (response.ok) {
        await response.json(); // Consume response
        
        const operation = editingCoach ? 'updated' : 'created';
        showNotification('success', formData.name, operation);
        
        // Refresh coaches list
        await fetchCoaches();
        resetForm();
      } else {
        const error = await response.json();
        console.error('Save failed:', error);
        
        // Show detailed validation errors if available
        if (error.errors && Array.isArray(error.errors)) {
          showNotification('error', formData.name, '', `Validation errors: ${error.errors.join(', ')}`);
        } else {
          showNotification('error', formData.name, '', `Failed to save coach: ${error.message || 'Unknown error'}`);
        }
      }
    } catch (error) {
      console.error('Network error:', error);
      showNotification('error', formData.name, '', 'Network error. Please check your connection and try again.');
    } finally {
      setLoading(false);
    }
  };

  // Handle edit coach
  const handleEditCoach = (coach) => {
    setFormData({
      name: coach.name || '',
      specialty: coach.specialty || '',
      rate: coach.rate || '',
      hourlyRate: coach.hourlyRate || 0,
      sport: coach.sport || 'tennis',
      bio: coach.bio || '',
      experience: coach.experience || 0,
      email: coach.contact?.email || '',
      phone: coach.contact?.phone || '',
      isActive: coach.isActive !== undefined ? coach.isActive : true,
      availability: coach.availability || {
        weekly: {
          monday: [],
          tuesday: [],
          wednesday: [],
          thursday: [],
          friday: [],
          saturday: [],
          sunday: []
        },
        dateSpecific: {}
      }
    });
    setEditingCoach(coach);
    setShowAddForm(true);
  };

  // Handle delete coach
  const handleDeleteCoach = (coach) => {
    const confirmDelete = async () => {
      setLoading(true);
      closeNotification(); // Close the confirmation modal
      
      try {
        const response = await fetch(`http://localhost:5000/api/coaches/${coach._id}`, {
          method: 'DELETE'
        });

        if (response.ok) {
          const result = await response.json();
          
          // Dispatch event to notify other components about coach deletion
          const coachDeletedEvent = new CustomEvent('coachDeleted', {
            detail: {
              coachId: coach._id,
              coachName: coach.name,
              cleanedBookings: result.data?.cleanedBookings || 0
            }
          });
          window.dispatchEvent(coachDeletedEvent);
          
          showNotification('success', coach.name, 'deleted', 
            result.data?.cleanedBookings > 0 
              ? `Coach deleted and ${result.data.cleanedBookings} booking(s) updated.`
              : undefined
          );
          await fetchCoaches();
        } else {
          const error = await response.json();
          console.error('Delete failed:', error);
          showNotification('error', coach.name, '', `Failed to delete coach: ${error.message || 'Unknown error'}`);
        }
      } catch (error) {
        console.error('Network error:', error);
        showNotification('error', coach.name, '', 'Network error. Please check your connection and try again.');
      } finally {
        setLoading(false);
      }
    };

    // Show confirmation modal
    showConfirmation(coach.name, confirmDelete);
  };

  return (
    <div className="min-h-screen bg-black text-white p-6 pt-24">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="text-center mb-6">
            <h1 className="text-4xl font-bold text-orange-500 mb-2">Coach Management</h1>
            <p className="text-gray-300">Manage tennis coaches and their information</p>
          </div>
          <div className="flex justify-end">
            <button
              onClick={() => setShowAddForm(true)}
              disabled={loading}
              className="bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white px-6 py-3 rounded-lg flex items-center gap-2 transition-colors"
            >
              <BiPlus size={20} />
              Add New Coach
            </button>
          </div>
        </div>

        {/* Add/Edit Form */}
        {showAddForm && (
          <div className="bg-gray-900 rounded-lg p-6 mb-8 border border-gray-700">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold text-orange-500">
                {editingCoach ? 'Edit Coach' : 'Add New Coach'}
              </h2>
              <button
                onClick={resetForm}
                className="text-gray-400 hover:text-white"
              >
                <BiX size={24} />
              </button>
            </div>

            <form onSubmit={handleSaveCoach} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Basic Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-orange-400">Basic Information</h3>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="Enter coach name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Specialty *
                  </label>
                  <input
                    type="text"
                    name="specialty"
                    value={formData.specialty}
                    onChange={handleInputChange}
                    required
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="e.g., Beginner Specialist, Advanced Training"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Sport
                  </label>
                  <select
                    name="sport"
                    value={formData.sport}
                    onChange={handleInputChange}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="tennis">Tennis</option>
                    <option value="football">Football</option>
                    <option value="basketball">Basketball</option>
                    <option value="swimming">Swimming</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Hourly Rate (USD) *
                  </label>
                  <input
                    type="number"
                    name="hourlyRate"
                    value={formData.hourlyRate}
                    onChange={handleInputChange}
                    required
                    min="0"
                    step="0.01"
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="25.00"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Experience (Years)
                  </label>
                  <input
                    type="number"
                    name="experience"
                    value={formData.experience}
                    onChange={handleInputChange}
                    min="0"
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="5"
                  />
                </div>
              </div>

              {/* Contact & Additional Info */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-orange-400">Contact & Additional Info</h3>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="coach@advancedsports.ke"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Phone
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="+254-700-123-456"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Bio
                  </label>
                  <textarea
                    name="bio"
                    value={formData.bio}
                    onChange={handleInputChange}
                    rows="4"
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="Brief description of the coach's background and expertise..."
                  />
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    name="isActive"
                    checked={formData.isActive}
                    onChange={handleInputChange}
                    className="mr-2 h-4 w-4 text-orange-500 focus:ring-orange-500 border-gray-300 rounded"
                  />
                  <label className="text-sm text-gray-300">
                    Active (available for booking)
                  </label>
                </div>
              </div>

              {/* Availability Schedule */}
              <div className="md:col-span-2">
                <h3 className="text-lg font-medium text-orange-400 mb-4">Weekly Availability Schedule</h3>
                <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                  <p className="text-sm text-gray-400 mb-4">
                    Select the time slots when this coach is available for each day of the week.
                  </p>
                  
                  <div className="space-y-6">
                    {daysOfWeek.map(({ key, label }) => (
                      <div key={key} className="border-b border-gray-700 pb-4 last:border-b-0">
                        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                          <div className="sm:w-24 flex-shrink-0">
                            <label className="text-sm font-medium text-gray-300">
                              {label}
                            </label>
                          </div>
                          
                          <div className="flex-1">
                            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2">
                              {timeSlots.map((timeSlot) => {
                                const isSelected = formData.availability.weekly[key]?.includes(timeSlot);
                                return (
                                  <button
                                    key={timeSlot}
                                    type="button"
                                    onClick={() => handleWeeklyAvailabilityChange(key, timeSlot)}
                                    className={`px-2 py-1 text-xs rounded border transition-colors ${
                                      isSelected
                                        ? 'bg-orange-500 border-orange-500 text-white'
                                        : 'bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600 hover:border-gray-500'
                                    }`}
                                  >
                                    {new Date(`2000-01-01T${timeSlot}`).toLocaleTimeString('en-US', {
                                      hour: 'numeric',
                                      hour12: true
                                    })}
                                  </button>
                                );
                              })}
                            </div>
                            
                            {formData.availability.weekly[key]?.length > 0 && (
                              <div className="mt-2">
                                <p className="text-xs text-gray-500">
                                  Selected: {formData.availability.weekly[key].length} time slots
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Quick Actions */}
                  <div className="mt-6 pt-4 border-t border-gray-700">
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          // Select business hours (9 AM - 6 PM) for weekdays
                          const businessHours = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
                          setFormData(prev => ({
                            ...prev,
                            availability: {
                              ...prev.availability,
                              weekly: {
                                monday: businessHours,
                                tuesday: businessHours,
                                wednesday: businessHours,
                                thursday: businessHours,
                                friday: businessHours,
                                saturday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
                                sunday: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00']
                              }
                            }
                          }));
                        }}
                        className="px-3 py-1 text-xs bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                      >
                        Business Hours
                      </button>
                      
                      <button
                        type="button"
                        onClick={() => {
                          // Select all time slots for all days
                          const allSlots = [...timeSlots];
                          setFormData(prev => ({
                            ...prev,
                            availability: {
                              ...prev.availability,
                              weekly: {
                                monday: allSlots,
                                tuesday: allSlots,
                                wednesday: allSlots,
                                thursday: allSlots,
                                friday: allSlots,
                                saturday: allSlots,
                                sunday: allSlots
                              }
                            }
                          }));
                        }}
                        className="px-3 py-1 text-xs bg-green-600 hover:bg-green-700 text-white rounded transition-colors"
                      >
                        Select All
                      </button>
                      
                      <button
                        type="button"
                        onClick={() => {
                          // Clear all selections
                          setFormData(prev => ({
                            ...prev,
                            availability: {
                              ...prev.availability,
                              weekly: {
                                monday: [],
                                tuesday: [],
                                wednesday: [],
                                thursday: [],
                                friday: [],
                                saturday: [],
                                sunday: []
                              }
                            }
                          }));
                        }}
                        className="px-3 py-1 text-xs bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
                      >
                        Clear All
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Date-Specific Availability Overrides */}
              <div className="md:col-span-2">
                <h3 className="text-lg font-medium text-orange-400 mb-4">Date-Specific Availability</h3>
                <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                  <p className="text-sm text-gray-400 mb-4">
                    Override weekly schedule for specific dates (holidays, vacations, special events).
                  </p>
                  
                  {/* Add New Date Override */}
                  <div className="mb-6 p-4 bg-gray-700 rounded-lg">
                    <h4 className="text-sm font-medium text-gray-300 mb-3">Add Date Override</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">Select Date</label>
                        <input
                          type="date"
                          id="dateSpecificDate"
                          min={new Date().toISOString().split('T')[0]}
                          className="w-full p-2 bg-gray-800 border border-gray-600 rounded text-white text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">Availability Type</label>
                        <select
                          id="availabilityType"
                          className="w-full p-2 bg-gray-800 border border-gray-600 rounded text-white text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
                        >
                          <option value="custom">Custom Times</option>
                          <option value="unavailable">Unavailable</option>
                        </select>
                      </div>
                      
                      <div>
                        <button
                          type="button"
                          onClick={() => {
                            const dateInput = document.getElementById('dateSpecificDate');
                            const typeInput = document.getElementById('availabilityType');
                            const date = dateInput.value;
                            const type = typeInput.value;
                            
                            if (!date) {
                              alert('Please select a date');
                              return;
                            }
                            
                            if (formData.availability.dateSpecific[date]) {
                              alert('Override already exists for this date');
                              return;
                            }
                            
                            if (type === 'unavailable') {
                              handleDateSpecificChange(date, [], false);
                            } else {
                              // Start with empty custom times - user can add them below
                              handleDateSpecificChange(date, [], true);
                            }
                            
                            // Clear inputs
                            dateInput.value = '';
                            typeInput.value = 'custom';
                          }}
                          className="w-full bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded text-sm transition-colors"
                        >
                          Add Override
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Existing Date Overrides */}
                  <div className="space-y-4">
                    {Object.entries(formData.availability.dateSpecific).length === 0 ? (
                      <p className="text-sm text-gray-500 italic text-center py-4">
                        No date-specific overrides. Weekly schedule will be used for all dates.
                      </p>
                    ) : (
                      Object.entries(formData.availability.dateSpecific).map(([date, config]) => (
                        <div key={date} className="border border-gray-600 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-3">
                              <h4 className="text-sm font-medium text-white">
                                {new Date(date).toLocaleDateString('en-US', {
                                  weekday: 'long',
                                  year: 'numeric',
                                  month: 'long',
                                  day: 'numeric'
                                })}
                              </h4>
                              <span className={`px-2 py-1 rounded text-xs ${
                                config.available === false 
                                  ? 'bg-red-900/30 text-red-400' 
                                  : 'bg-green-900/30 text-green-400'
                              }`}>
                                {config.available === false ? 'Unavailable' : 'Custom Times'}
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() => removeDateSpecific(date)}
                              className="text-red-400 hover:text-red-300 text-sm"
                            >
                              Remove
                            </button>
                          </div>
                          
                          {config.available !== false && (
                            <div>
                              <p className="text-xs text-gray-400 mb-2">Available time slots:</p>
                              <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
                                {timeSlots.map((timeSlot) => {
                                  const isSelected = config.times?.includes(timeSlot);
                                  return (
                                    <button
                                      key={timeSlot}
                                      type="button"
                                      onClick={() => {
                                        const currentTimes = config.times || [];
                                        const newTimes = isSelected
                                          ? currentTimes.filter(t => t !== timeSlot)
                                          : [...currentTimes, timeSlot].sort();
                                        handleDateSpecificChange(date, newTimes, true);
                                      }}
                                      className={`px-2 py-1 text-xs rounded border transition-colors ${
                                        isSelected
                                          ? 'bg-orange-500 border-orange-500 text-white'
                                          : 'bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600'
                                      }`}
                                    >
                                      {new Date(`2000-01-01T${timeSlot}`).toLocaleTimeString('en-US', {
                                        hour: 'numeric',
                                        hour12: true
                                      })}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Form Actions */}
              <div className="md:col-span-2 flex gap-4 pt-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white px-6 py-3 rounded-lg flex items-center gap-2 transition-colors"
                >
                  <BiSave size={20} />
                  {loading ? 'Saving...' : (editingCoach ? 'Update Coach' : 'Add Coach')}
                </button>
                
                <button
                  type="button"
                  onClick={resetForm}
                  className="bg-gray-600 hover:bg-gray-700 text-white px-6 py-3 rounded-lg transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Coaches List */}
        <div className="bg-gray-900 rounded-lg border border-gray-700">
          <div className="p-6 border-b border-gray-700">
            <h2 className="text-2xl font-semibold text-orange-500">Current Coaches</h2>
            <p className="text-gray-300 mt-1">
              {coaches.length} coach{coaches.length !== 1 ? 'es' : ''} registered
            </p>
          </div>

          {loading && (
            <div className="p-8 text-center">
              <div className="text-gray-400">Loading coaches...</div>
            </div>
          )}

          {!loading && coaches.length === 0 && (
            <div className="p-8 text-center">
              <div className="text-gray-400">No coaches found. Add your first coach!</div>
            </div>
          )}

          {!loading && coaches.length > 0 && (
            <div className="divide-y divide-gray-700">
              {coaches.map((coach) => (
                <div key={coach._id} className="p-6 hover:bg-gray-800 transition-colors">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-4 mb-2">
                        <h3 className="text-xl font-semibold text-white">{coach.name}</h3>
                        <span className="px-3 py-1 bg-orange-500/20 text-orange-400 rounded-full text-sm">
                          {coach.sport}
                        </span>
                        {!coach.isActive && (
                          <span className="px-3 py-1 bg-gray-500/20 text-gray-400 rounded-full text-sm">
                            Inactive
                          </span>
                        )}
                      </div>
                      
                      <p className="text-gray-300 mb-2">{coach.specialty}</p>
                      <p className="text-orange-400 font-semibold mb-2">{coach.rate}</p>
                      
                      {coach.bio && (
                        <p className="text-gray-400 text-sm mb-2 max-w-2xl">{coach.bio}</p>
                      )}
                      
                      <div className="flex flex-wrap gap-4 text-sm text-gray-400">
                        {coach.experience && (
                          <span>📅 {coach.experience} years experience</span>
                        )}
                        {coach.contact?.email && (
                          <span>📧 {coach.contact.email}</span>
                        )}
                        {coach.contact?.phone && (
                          <span>📞 {coach.contact.phone}</span>
                        )}
                        {coach.rating && (
                          <span>⭐ {coach.rating.average}/5 ({coach.rating.totalReviews} reviews)</span>
                        )}
                      </div>
                      
                      {/* Availability Summary */}
                      {coach.availability && (
                        <div className="mt-3 pt-3 border-t border-gray-700">
                          <h4 className="text-sm font-medium text-orange-400 mb-2">Availability:</h4>
                          
                          {/* Weekly Schedule */}
                          <div className="mb-3">
                            <p className="text-xs text-gray-500 mb-1">Weekly Schedule:</p>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 text-xs">
                              {Object.entries(coach.availability.weekly || coach.availability).map(([day, times]) => {
                                const dayLabel = day.charAt(0).toUpperCase() + day.slice(1);
                                const timeCount = times?.length || 0;
                                
                                return (
                                  <div key={day} className="flex justify-between items-center">
                                    <span className="text-gray-400 font-medium">{dayLabel}:</span>
                                    <span className={`px-2 py-1 rounded text-xs ${
                                      timeCount > 0 
                                        ? 'bg-green-900/30 text-green-400' 
                                        : 'bg-red-900/30 text-red-400'
                                    }`}>
                                      {timeCount > 0 ? `${timeCount} slots` : 'Unavailable'}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                          
                          {/* Date-Specific Overrides */}
                          {coach.availability.dateSpecific && Object.keys(coach.availability.dateSpecific).length > 0 && (
                            <div>
                              <p className="text-xs text-gray-500 mb-1">Date Overrides:</p>
                              <div className="flex flex-wrap gap-1">
                                {Object.entries(coach.availability.dateSpecific).map(([date, config]) => (
                                  <span 
                                    key={date}
                                    className={`px-2 py-1 rounded text-xs ${
                                      config.available === false 
                                        ? 'bg-red-900/30 text-red-400' 
                                        : 'bg-blue-900/30 text-blue-400'
                                    }`}
                                    title={`${date}: ${config.available === false ? 'Unavailable' : `${config.times?.length || 0} slots`}`}
                                  >
                                    {new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <button
                        onClick={() => handleEditCoach(coach)}
                        className="p-2 text-blue-400 hover:text-blue-300 hover:bg-blue-400/20 rounded-lg transition-colors"
                        title="Edit coach"
                      >
                        <BiEdit size={20} />
                      </button>
                      
                      <button
                        onClick={() => handleDeleteCoach(coach)}
                        className="p-2 text-red-400 hover:text-red-300 hover:bg-red-400/20 rounded-lg transition-colors"
                        title="Delete coach"
                      >
                        <BiTrash size={20} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Notification Modal */}
      <CoachNotificationModal
        isOpen={notification.isOpen}
        onClose={closeNotification}
        type={notification.type}
        coachName={notification.coachName}
        operation={notification.operation}
        message={notification.message}
        confirmAction={notification.confirmAction}
        isConfirmModal={notification.isConfirmModal}
      />
    </div>
  );
};

export default CoachManagement;